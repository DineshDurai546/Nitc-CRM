import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {  ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { emailValidatorService } from 'src/app/common/Services/gsxService/email.validator';
import * as glob from 'src/app/config/global';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private dynamicService: DynamicService,
    private ngxSpinner: NgxSpinnerService,
    private emailValidator: emailValidatorService,
    private toastMessage: ToastrService
  ) {}
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: [
        '',
        [Validators.required, Validators.pattern(/^[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/), Validators.minLength(5)]
      ]
    });
  }
  get f() {
    return this.loginForm.controls;
  }
  onSubmit() {

    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    } else {
      // this.router.navigate(['/dashboard/main']);
      // debugger
      const shouldContinue = confirm("Are you sure, you want to continue?")
      if (shouldContinue == false) 
      {
        return
      }
      else {
        // this.validateemail()
        this.checkEmailID() 
      }
    }
  }

  
  checkEmailID() {
    // Get UserName from Local Storage
    let userName = localStorage.getItem(glob.GLOBALVARIABLE.USERNAME);
    console.log("Get UserName:- ", userName)
    const email = this.loginForm.controls['email'].value

    // Call an API to get the user email Id:- using Guest Controller
    return
    this.dynamicService.getGuestEmail(email).subscribe({
      next: (value) =>{
        console.log("After UserObject SP:-", value);
        let response = JSON.parse(value.toString());

        if(response.ReturnCode == '0'){
          let ExtraData = response.ExtraData;
          // Will get a GUID/Token and a Key to Validate the Login and send it into the Queryparams to Reset-Password Component
          console.log("Extradata is :-",response.ExtraData)
          this.toastMessage.success("Reset Password Link sent in your Email")
          this.router.navigate(['/reset-password'], { queryParams: {userGUID: ExtraData.token, user: ExtraData.UserName} });       
        
        }

      },
      error: (err) => {
        console.log("Error:- ", err);
      }
    })

  }

  
  // validateemail(){
  //   // this.ngxSpinner.show()
  //   debugger
  //   var emailid=this.loginForm.controls["email"].value
  //   this.emailValidator.validateEmail(emailid).subscribe(
  //     {
  //       next: (value:any) => {
  //         if(value.ReturnValue==true)
  //         {
  //           this.toastMessage.success("password reset link has been sent to your email");
  //         }
  //         else{
  //           this.loginForm.controls["email"].setErrors({ "Invalid": true, "Message": "Invalid Email Id" });
  //           this.toastMessage.error("In-valid Email Id");
  //         }
  //         this.ngxSpinner.hide();
  //       }
  //     });
  // }



}
