import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RazorPayGetwayComponent } from './razor-pay-getway.component';

describe('RazorPayGetwayComponent', () => {
  let component: RazorPayGetwayComponent;
  let fixture: ComponentFixture<RazorPayGetwayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RazorPayGetwayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RazorPayGetwayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
