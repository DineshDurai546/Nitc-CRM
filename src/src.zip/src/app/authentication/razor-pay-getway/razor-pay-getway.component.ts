import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-razor-pay-getway',
  templateUrl: './razor-pay-getway.component.html',
  styleUrls: ['./razor-pay-getway.component.sass']
})
export class RazorPayGetwayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
