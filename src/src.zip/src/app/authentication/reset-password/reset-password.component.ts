import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import {  ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { emailValidatorService } from 'src/app/common/Services/gsxService/email.validator';
import * as glob from 'src/app/config/global';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import xml2js from 'xml2js';


@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {


    resetForm: FormGroup;
    submitted = false;
    showPassword = false;
    showconfirmPassword = false;
    params: any;
    isExpired = false;
    userName = ''
    errorMessage = '';

    constructor(
      private formBuilder: FormBuilder,
      private activatedRoute: ActivatedRoute,
      private router: Router,
      private dynamicService: DynamicService,
      private ngxSpinner: NgxSpinnerService,
      private emailValidator: emailValidatorService,
      private toastMessage: ToastrService,

    ) {}
    ngOnInit() {
      debugger
      this.params = this.activatedRoute.snapshot.queryParams;
      if (this.params.userGUID != null || this.params.userGUID != undefined ) {
        // check the Token and write a function to get the Username using this Token 
        // And based on this Token and Username set the password 
        console.log("Token is:- ", this.params.userGUID);
        // If token expired then show Link expired Page 
        var strRequestData = {
          "Token": this.params.token,
          "UserName": this.params.un
        }
        return
        this.dynamicService.getGuestEmailDetails(strRequestData).subscribe({
          next: (value)=>{
            console.log("After GuestEmail Api SP:- ", value);
            // Set the UserName based on the guest email Service and check if Token expired then return
            // If its not expired and succes then allow user to create a new password
            
          },
          error: (error)=>{
            console.log("Error in Service", error);
          }
        })
   
      }
      else{
        this.toastMessage.error("Access denied")
        // this.router.navigate(['/authentication/reset-password']);
        // this.router.navigate(['/authentication/signin']);
      }

      this.resetForm = this.formBuilder.group({
        newPassword: [
          '',
          [Validators.required
          , Validators.minLength(8)
          , Validators.maxLength(20)
          , Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{8,20}$/)
          ]
        ],
        confirmPassword: [ '', Validators.required ]
      },
      { validator: this.passwordMatchValidator }
      );
    }




    passwordMatchValidator( group: FormGroup ) {
      const newPassword = group.controls.newPassword.value;
      const confirmPassword = group.controls.confirmPassword.value;
      
      console.log("Password Mismatch:- ", newPassword,"\n", confirmPassword, "\n", newPassword == confirmPassword);
      if ( confirmPassword == '' ) {
        return group.controls.confirmPassword.setErrors({ required : true })
      }
      else{
        return newPassword == confirmPassword ? null  : group.controls.confirmPassword.setErrors({ passwordMismatch: true })
      }
    }


    get f() {
      return this.resetForm.controls;
    }

    onSubmit() {
      debugger
      this.submitted = true;
      // stop here if form is invalid
      if (this.resetForm.invalid) {
        return;
      }
      else {
        // debugger
        // this.validateemail()
        // New unction will take the username and password a nd call a  new Api Service that qwill change the password
        var strRequestData ={
          "Token": this.params.token,
          "UserName": this.userName,
          "Password": this.resetForm.controls['newPassword'].value
        }
        
        // return
        this.dynamicService.changePassword(strRequestData).subscribe({
          next:(value) =>{
            let response = JSON.parse(value.toString());
            if (response.ReturnCode == '0') {
              this.toastMessage.success("Password reset successfully, login again");
              this.router.navigate(['/authentication/signin']);
            }
            else {
              this.errorMessage = response.ReturnMessage;
              const parser = new xml2js.Parser({ strict: false, trim: true });
              parser.parseString(response.ErrorMessage, (err, result) => {
                response['errorMessageJson'] = result;
              });
            }
          },
          error: (err) =>{
            console.log("Error in changing Password", err)
          }
        })
      }
    }
  
    
    // checkEmailID() {
    //   // Get UserName from Local Storage
    //   let userName = localStorage.getItem(glob.GLOBALVARIABLE.USERNAME);
    //   console.log("Get UserName:- ", userName)
  
    //   // Call an API to get the user email Id:- using Guest Controller
    //   this.dynamicService.getDynamicDetaildata(userName).subscribe({
    //     next: (value) =>{
    //       console.log("After UserObject SP:-", value);
    //       let response = JSON.parse(value.toString());
  
    //       if(response.ReturnCode == '0'){
    //         console.log("Extradata is :-",response.ExtraData)
    //         this.router.navigate(['/company']);
    //       }
  
    //     },
    //     error: (err) => {
    //       console.log("Error:- ", err);
    //     }
    //   })
    // }

    // togglePasswordVisibility(){
    //   console.log("Password:- ", this.showPassword)
    //   this.showPassword != this.showPassword;
    // }
  
  
  }
  