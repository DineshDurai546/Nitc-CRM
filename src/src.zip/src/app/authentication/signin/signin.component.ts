import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/core/service/auth.service';
import { UnsubscribeOnDestroyAdapter } from 'src/app/shared/UnsubscribeOnDestroyAdapter';
import { CommonMessage, GLOBALVARIABLE } from 'src/app/config/global';
import { forkJoin } from 'rxjs';
import { AppInitService } from 'src/app/core/service/app.init.service';
import { EncryptDecryptService } from 'src/app/core/service/encrypt-decrypt.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  error = '';
  images = [];
  hide = true;
  showPassword: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private appInitService: AppInitService,
    private encryptDecryptService: EncryptDecryptService,
    private messageService: ToastrService,
  ) {
    super();
    //localStorage.clear();
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: [
        '',
        [Validators.required, Validators.email, Validators.minLength(5)]
      ],
      password: ['', Validators.required]
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  onSubmit() {
    this.error = '';
    if (this.loginForm.invalid) {
      this.error = 'Username and Password not valid !';
      return;
    } else {
      this.submitted = true;
      //let password = this.encryptDecryptService.encrypt(this.f.password.value);
      this.subs.sink = this.authService.login(this.f.email.value, this.f.password.value)
        .subscribe((data: any) => {
          if (data.isValid == true) {
            localStorage.setItem(GLOBALVARIABLE.USERNAME, this.f.email.value);
            localStorage.setItem(GLOBALVARIABLE.TOKEN, data.token);
            localStorage.setItem(GLOBALVARIABLE.REFRESHTOKEN, data.refreshToken);
            this.getRequiredData();

          }
          else {
            this.submitted = false;
            this.error = "User Name or Password is not correct!"
          }
          // if (res) {
          //   const token = this.authService.currentUserValue.token;
          //   if (token) {
          //     this.router.navigate(['/dashboard/main']);
          //   }
          // } else {
          //   this.error = 'Invalid Login';
          // }
        },
          (error) => {
            this.error = error;
            this.submitted = false;
          }
        );
    }
  }

  getRequiredData = () => {
    let userName = localStorage.getItem(GLOBALVARIABLE.USERNAME);
    forkJoin({
      MenuDetail: this.authService.getMenu(userName),
      //ProfileDetail: this.authService.getProfileModuleList(),
      FieldDetails: this.authService.getFieldDetail(),
      GridDetails: this.authService.getGridDetail(),
      AllRouting: this.authService.getAllRouting(),
      Actions: this.authService.getModulections(),
      UserPermission: this.authService.getUserPermission(userName)
    }).subscribe((data: any) => {
      console.log("Menu Data");
      console.log(data.MenuDetail);
      data.MenuDetail[0].push({
        HeadingId: 1,
        HeadingLogo: "fas fa-tachometer-alt",
        HeadingName: "Repair Process\r\n",
        MenuGroupId: 1,
        MenuLevelId: 0,
        ModuleId: 1,
        ModuleLogo: "",
        ModuleName: "Repair Process",
        SubHeadingId: 0,
        SubHeadingLogo: "",
        SubHeadingName: "",
        Url: "/repair-process",
      });
      localStorage.setItem('MenuDetail', JSON.stringify(data.MenuDetail));
      //localStorage.setItem('ModuleEntityField', JSON.stringify(data.ProfileDetail));
      localStorage.setItem('FieldDetail', JSON.stringify(data.FieldDetails));
      localStorage.setItem('GridModuleDetail', JSON.stringify(data.GridDetails));
      localStorage.setItem('AllRouting', JSON.stringify(data.AllRouting));
      localStorage.setItem('ModuleAction', JSON.stringify(data.Actions));
      localStorage.setItem('UserPermission', JSON.stringify(data.UserPermission));
      localStorage.removeItem('selectedMenu');

      this.appInitService.init();
      this.router.navigate(['/company']);
    },
      error => {
        this.messageService.error(CommonMessage.ErrorMessge);
        this.submitted = false;
      });
  }


}
