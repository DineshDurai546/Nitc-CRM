import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverDashboardGridComponent } from './approver-dashboard-grid.component';

describe('ApproverDashboardGridComponent', () => {
  let component: ApproverDashboardGridComponent;
  let fixture: ComponentFixture<ApproverDashboardGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApproverDashboardGridComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverDashboardGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
