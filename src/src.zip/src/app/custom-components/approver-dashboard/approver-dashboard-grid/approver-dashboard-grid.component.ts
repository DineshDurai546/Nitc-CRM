import { Component, Input, OnInit } from '@angular/core';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Observable } from 'rxjs/internal/Observable';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { Columns } from 'src/app/models/column.metadata';
import { PaginationMetaData } from 'src/app/models/pagination.metadata';
import * as glob from "../../../config/global";
import { Filter } from '../../call-login-dashboard/filter.meta';
import { DropDownType } from '../../call-login/metadata/request.metadata';
import { ToastrService } from 'ngx-toastr';
import { ReportService } from 'src/app/common/Services/gsxService/report.service';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-approver-dashboard-grid',
  templateUrl: './approver-dashboard-grid.component.html',
  styleUrls: ['./approver-dashboard-grid.component.css']
})
export class ApproverDashboardGridComponent implements OnInit {

  caseid = "";
  firstname = "";
  phonenumber = "";
  Emailid = "";
  Serialno = "";
  callType: any;
  JobStatustype: any;
  JobStatusTitle: any;
  filterList: any[]=[]
  jobPagination: PaginationMetaData;
  JobList: any[];
  JobColumns: Columns[] = [];
  actionDetails: any[] = [];
  @Input() filters: Observable<Filter[]>;
  callForm: DropDownValue = DropDownValue.getBlankObject();
  JobStatus: DropDownValue = DropDownValue.getBlankObject();
  JobDetail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  jobListHideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);

  constructor(
    private dynamicService: DynamicService,
    private router: Router,
    private toaster: ToastrService,
    private dropdownDataService: DropdownDataService,
    private reportService:ReportService,
    private ngxSpinner : NgxSpinnerService
  ) { }

  ngOnInit(): void {
    this.injobTable();
    this.filters.subscribe({
      next: (value) => {
        this.filterList = value;
        for (let filter of this.filterList) {
          console.log("fileted Data",filter)
          if (filter.title == "Walk-In" || filter.title == "Pick-up") {
            this.callType = filter.value
          }
          else {
            this.JobStatustype = filter.value;
          }
        }
        this.getJobDetail(this.caseid, this.firstname, this.phonenumber, this.Emailid, this.Serialno, this.callType, this.JobStatustype);
      },
      error: (error) => {
        console.log(error)
      }
    });
    this.onJobType({ term: "", item: null });
    this.onJobStatus({ term: "", item: null })
  }



  injobTable() {
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Case Id", "CaseId"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "First Name", "FirstName"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "MOBILE NO", "MobileNo"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "EmailId", "EmailId"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Material Code", "MaterialCode"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Serial No", "SerialNo1"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Material Desc", "productDescription"));;
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Remark", "Remark"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Fault Description", "ComplainDesc"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Job Status", "JobStatus"));
    this.JobColumns.push(this.dynamicService.getColumn("STRING", "Job Type", "JobType"));
    this.actionDetails.push({ code: 'Approval', icon: 'remove_red_eye',"title": "Approval" });
    // this.actionDetails.push({"code": "Downloadpdf", icon: "picture_as_pdf","title": "Download PDF"})
   
  }
  

  SearchCallLogin() {
    this.getJobDetail(this.caseid, this.firstname, this.phonenumber, this.Emailid, this.Serialno, this.callType, this.JobStatustype);

  }

  getJobDetail(caseid, firstname, phonenumber, Emailid, Serialno, callType, JobStatustype) {
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetJobDetails"
    });
    requestData.push({
      "Key": "CaseId",
      "Value": caseid
    });
    requestData.push({
      "Key": "SerialNo",
      "Value": Serialno
    });
    requestData.push({
      "Key": "FirstName",
      "Value": firstname
    });
    requestData.push({
      "Key": "MobileNo",
      "Value": phonenumber
    });
    requestData.push({
      "Key": "EmailId",
      "Value": this.Emailid
    });

    requestData.push({
      "Key": "JobStatus",
      "Value": JobStatustype
    });
    requestData.push({
      "Key": "JobType",
      "Value": callType
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "PageNo",
      "Value": "1"
    });
    requestData.push({
      "Key": "PageSize",
      "Value": "10"
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {

          try {
            let response = JSON.parse(Value.toString());
            console.log(response)
            if (response.ReturnCode == '0') {
              response['ExtraDataJSON'] = JSON.parse(response.ExtraData);
              let jobListData = response['ExtraDataJSON']['JobList']['JobData']
              var JobFindData: any = [];
              this.toaster.success("RECORD FOUND IN"+" "+JobStatustype)
              if (Array.isArray(jobListData)) {
                JobFindData = jobListData;
              }
              else {
                JobFindData.push(jobListData)
              }
              this.JobDetail.next({ totalRecord: jobListData.length, Data: JobFindData });
            }
            else {
              this.toaster.error(response)
            }
          } catch (ext) {
            console.log(ext);
            this.JobList = [];
            this.toaster.warning("NO RECORD FOUND"+" "+JobStatustype)
            this.JobDetail.next({ totalRecord: this.JobList.length, Data: this.JobList });
          }
        },
        error: err => {
          
          console.log(err);
          this.JobList = [];
          this.JobDetail.next({ totalRecord: this.JobList.length, Data: this.JobList });
        }
      }
    );
  }

  

  onJobType($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.callForm, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.callForm = value;
        }
      },
      error: (err) => {
        this.callForm = DropDownValue.getBlankObject();
      }

    });
  }

  onJobStatus($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.JobStatus, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.JobStatus = value;
          console.log("Job Status ", this.JobStatus)
          this.JobStatus.Data = this.JobStatus.Data.filter( job =>  job.Id == 'S04' || job.Id == 'S05' || job.Id == 'S06')
          console.log("Job Status ", this.JobStatus)
        }
      },
      error: (err) => {
        this.JobStatus = DropDownValue.getBlankObject();
      }
    });
  }
  strdata:any;
  actionEmit(event) {
    if(event.action == 'Downloadpdf'){
      this.strdata = event.row.CaseGUID
      this.CallingFunctio()
    }
    if(event.action == 'Approval'){
      this.router.navigate(['/auth/' + glob.getCompanyCode() + '/repair-parts-approval'], { queryParams: { caseguid: event.row.CaseGUID } });
    }
  }
  CallingFunctio(){
  let reportType:String='SERVICE'
  let PdfData = [];
  PdfData.push({
    "Key": "ApiType",
    "Value": "GetJobObject4Print",
  });
  PdfData.push({
    "Key": "CaseGuid",
    "Value": this.strdata
  });
  console.log("Data Print:",PdfData)


  let pdfRequestData = JSON.stringify(PdfData);
  let contentRequest =
  {
    "content": pdfRequestData
  };
  this.reportService.downloadServiceReport(reportType,contentRequest).subscribe(
    {
      next: (value) => {
        let response = JSON.parse(value.toString());
        const byteArray = new Uint8Array(atob(response.FileContents).split('').map(char => char.charCodeAt(0)));
        var blob = new Blob([byteArray], { type: 'application/pdf' });
        var url = URL.createObjectURL(blob);
        window.open(url);
        this.ngxSpinner.hide();
      },
      error: err => {
        console.log(err);
        this.ngxSpinner.hide();
      }
    });
}

  jobLoadPageData(details) {
    setTimeout(() => { this.jobListHideSpinnerEvent.next(); }, 1);
  }

  onAssignTechnician() {
    this.router.navigate(['/auth/' + glob.getCompanyCode() + '/assign-technician']);
  }

}
