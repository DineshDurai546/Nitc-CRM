export class Customer {

    CustomerAccountGroup: any;
    GSTRegistration: String;
    CustomerName: String;
    firstname:String;
    AlternateNo: Number;
    Address1: String;
    Address2: String;
    PhoneNo: Number;
    DoGST: Boolean;
    Email: String;
    City: String;
    Pincode: any;
    gstNo: String;
    Country: string;
    State: any;

}