import { AddCustomerComponent } from '../create-customer/add-customer/add-customer.component';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { PaginationMetaData } from 'src/app/models/pagination.metadata';
import { ToastrService } from 'ngx-toastr';
import { Filter } from '../call-login-dashboard/filter.meta';
import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, BehaviorSubject } from 'rxjs';
import { Columns } from 'src/app/models/column.metadata';
import * as glob from "../../config/global";
import { ACTIONENUM } from 'src/app/config/comman.const';
import { NgxSpinnerService } from 'ngx-spinner';
import { DropDownType } from '../call-login/metadata/request.metadata';
import xml2js from 'xml2js';


@Component({
  selector: 'app-create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.css']
})


export class CreateCustomerComponent implements OnInit {

  firstname="";
  phonenumber="";
  gmail="";
  
  form: FormGroup = new FormGroup({}); 

  // SelectedCounter;
  // selectedLocationCode;
  // email: string = '';
   customercode: string = '';
  // customerfirstname: string = '';
  // mobilenumber: string = '';
   CustomerCode: string
  // VisitPurpose: string;
  // Phonenumbersearched = ""
  // typeSelected = 'ball-clip-rotate';
  // CounterData: any = ['C1', 'C2'];
  // EnquiryList: any = [] = []
   showAddCustomer: boolean = false; 
  // isSelectToken: boolean = false;
  // isGridShow: boolean = false;
  // isEnquiryGridShow: boolean = false;
   isCustomerView: boolean = false
   isCreateJobShow: boolean = false;
   isAddCustomerShow: boolean = false

  tokendata1:string;
  addCustomer:boolean;
  editCustomer:boolean;
  
  isEnquiryForm: boolean = false;
  isNextBtn: boolean = true;
  isSelectBtn: boolean = true;
  isCloseBtn: boolean = true;
  isNoShowBtn: boolean = true;
  isOtpVerification: boolean=false;
  isChoose: boolean = false;

  phoneNumber: string;

 

 
  // jobCreate(event){
  //   alert(event.action)
  //   if(event.action == true){
  //     alert('add')
  //     this.route.navigate(['/auth/'+glob.getCompanyCode()+'/add-customer-master'], { queryParams: { cc: event.row.CompanyCode, customercode:event.row.CustomerCode } })
  //   }
  // }

  //for mobile number 
  restrictNonNumeric(event: KeyboardEvent) {
    const keyCode = event.keyCode || event.which;
    const keyValue = String.fromCharCode(keyCode);
  
    // Allow special keys like backspace, delete, arrows, etc.
    if (
      keyCode === 8 || // Backspace
      keyCode === 9 || // Tab
      keyCode === 27 || // Esc
      keyCode === 46 || // Delete
      (keyCode >= 35 && keyCode <= 40) // Home, End, Left, Right, Down, Up
    ) {
      return;
    }
  
    // Prevent input if the key value is not a number
    if (!/^\d+$/.test(keyValue)) {
      event.preventDefault();
    }
  }


  //space and special character not allow
  // onInputChange(event: any) {
  //   const input = event.target.value;
  //   const sanitizedInput = input.replace(/[^a-zA-Z]/g,); // Remove special characters and space using a regular expression
  //   event.target.value = sanitizedInput;
  // }

  emailInputChange(event: any) {
    const input = event.target.value;
    const sanitizedInput = input.replace(/[^a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/, ''); // Remove special characters using a regular expression
    event.target.value = sanitizedInput;
  }

  


  



  OpenCall: number
  pagination: PaginationMetaData;
  jobPagination: PaginationMetaData;
  JobList: any[];
  CustomerObject: any[];
  tokendata: any = [];
  searchForm: FormGroup;
  JobColumns: Columns[] = [];
  JobColumnsEnquiry: Columns[] = [];
  toolBarAction: any[] = [];
  
  selectedCallForm: any;
  currentStatus;
  TokenFirstName;
  emailID;
  TokenLastName;
  TokenNumber;
  TokenCreatedDate;
  CounterNumber;
  caseid = "";
  // firstname = "";
  // phonenumber = "";
  Emailid = "";
  Serialno = "";
  callType: any;
  JobStatustype: any;
  errorMessage: any;
  isGridshow:boolean;

  LocationForJob: DropDownValue = DropDownValue.getBlankObject();
  @Input() filters: Observable<Filter[]>;
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  JobDetail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  JobDetailEnquriy: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  jobListHideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  // LocationForJob: DropDownValue = DropDownValue.getBlankObject();
 



  constructor(
    private dynamicService: DynamicService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private toastmeassge: ToastrService,
    private modalService: NgbModal,
    private ngxservice: NgxSpinnerService,
    private dropdownDataService: DropdownDataService,
    private fb: FormBuilder
  ) {
    this.pagination = new PaginationMetaData();
    this.activatedRoute.data.subscribe((data: any) => {
      this.jobPagination = new PaginationMetaData();
      this.toolBarAction.push({ code: "ADD", icon: "add_circle_outline", title: "Add" });
    })

    
  }
  actionDetails: any[]=[
    {"code": "EDIT","icon": "edit","title": "Edit"},
  ];
  
  submit(){  
    console.log("---------------",this.form.value);  
  }  
  
  ngOnInit() {
    this.isGridshow=false;
    this.onLocationSearch({term: "" , item:[]})
  //  this.loadPageData12(event);
  // this.GetCustomerList('','','')
    // this.injobTable();
    //  this.injobTableEnquiry(); 
    this.CustomerObject = [] 
  }

  validatedOTP($event){
    this.iscreateJob = $event 
    // this.route.navigate(['/auth/'+glob.getCompanyCode()+'/create-jobsheet'],{ queryParams:{cc:this.customerCode}})
    if(this.iscreateJob != '' || this.iscreateJob != undefined || this.iscreateJob != null ){ 
      this.route.navigate(['/auth/'+glob.getCompanyCode()+'/create-jobsheet'],{ queryParams:{cc:this.customerCode}})
      //  this.route.navigate(['/auth/' + glob.getCompanyCode() + '/create-job-customer'], { queryParams: { cc: glob.getCompanyCode(), nc: this.CustomerCode, tc:this.TokenNumber, td:this.TokenCreatedDate, cn:this.CounterNumber ,lc:this.selectedLocationCode } })
    }
   
  }
 
  jobLoadPageData(details) {
    setTimeout(() => { this.jobListHideSpinnerEvent.next(); }, 1);
  }

  search() { 
    this.GetCustomerList(this.firstname, this.phonenumber,this.gmail );
    
  }
  locationCode:string;
  customerDetails:any;
  customerCode:any;

  isCustomerEvent(event){  
    if(this.locationCode == undefined || this.locationCode == null)
    {
      this.toastmeassge.error('Please Select Location Code')
      return
    } 
    
    this.customerDetails=event;
    console.log("---====----",this.customerDetails)
    this.isOtpVerification=true;
    this.customerCode=event.CustomerCode;
   // this.route.navigate(['/auth/'+glob.getCompanyCode()+'/create-jobsheet'],{ queryParams:{cc:event.CustomerCode}})
  }


  GetCustomerList(firstname, phonenumber, gmail) {
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetCustomerList4Job"
    });
    requestData.push({
      "Key": "CustomerCode",
      "Value": ""
    });
    requestData.push({
      "Key": "CustomerName",
      "Value": firstname
    });
  
    requestData.push({
      "Key": "MobileNo",
      "Value": phonenumber
    });
    requestData.push({
      "Key": "EmailId",
      "Value": gmail
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "GSTNO",
      "Value": ''
    });
    requestData.push({
      "Key": "PageNo",
      "Value": "1"
    });
    requestData.push({
      "Key": "PageSize",
      "Value": "10"
    }); 
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
  
       next: (Value) => {
        console.log("Data123456:",Value)
          try {
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              this.isGridshow=true;
              let data = JSON.parse(response?.ExtraData);
              var custlist = [];
              if (Array.isArray(data?.CustomerList?.Customer)) {
                custlist = data?.CustomerList?.Customer;
              }
              else {
                custlist.push(data?.CustomerList?.Customer);
              }
             this.detail.next({ totalRecord: data?.Totalrecords, Data: custlist });
             
            }
          } catch (ext) {
            
          }
         
        },
        error: err => {
        }
  
      }
    );
  }

  

  

  


  onLocationSearch($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.Location, $event.term, {
      CompanyCode: glob.getCompanyCode().toString()
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.LocationForJob = value;
        }
      },
      error: (err) => {
        this.LocationForJob = DropDownValue.getBlankObject();
      }
    });
  }


  customeradded($event){
    console.log("Data", $event)
    this.isCreateJobShow = true;
    this.CustomerCode = $event.CustomerCode
    this.CustomerObject.push($event)
    this.showAddCustomer = false;
    this.isCustomerView = true
  }

  TokenStatusChange() {
    let RequestStatus = [];

    RequestStatus.push({
      "Key": "APIType",
      "Value": "SaveTokenStatus"
    });

    RequestStatus.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });

    RequestStatus.push({
      "Key": "TokenCode",
      "Value": this.tokendata.TokenCode
    });

    RequestStatus.push({
      "Key": "TokenStatus",
      "Value": ""
    });
    let requestdataObj = JSON.stringify(RequestStatus);

    let requstDataStringfy =
    {
      "content": requestdataObj
    }
    this.dynamicService.getDynamicDetaildata(requstDataStringfy).subscribe(
      {
        next: (Value) => {
        }
      })
  }


  // Validation() {
  //   if (this.SelectedCounter == '' || this.SelectedCounter == undefined || this.SelectedCounter == undefined) {
  //     this.toastmeassge.error("Select counter")
  //     return false
  //   }

  //   if (this.selectedLocationCode == '' || this.selectedLocationCode == undefined || this.selectedLocationCode == undefined) {
  //     this.toastmeassge.error("Select Location Code")
  //     return false
  //   }
  //   return true;

  // }

  isAddCustomer(event) {
    this.addCustomer=event;
    if (this.isAddCustomerShow == true) {
      this.isAddCustomerShow = false;
    } else {
      this.isAddCustomerShow = true;
    }

  }

 
 

 
  columns: Columns[] =
  [
    { datatype: "STRING", field: "CustomerCode", title: "Customer Code" },
    { datatype: "STRING", field: "FirstName", title: "FirstName" },
    { datatype: "STRING", field: "LastName", title: "LastName" },
    { datatype: "STRING", field: "EmailID", title: "EmailID" },
    { datatype: "STRING", field: "MobileNo", title: "MobileNo" },
    { datatype: "STRING", field: "OPENCalls", title: "OPENCalls" },
    { datatype: "STRING", field: "CloseCalls", title: "CloseCalls" },
    { datatype: "button", field: "Action", title: "Action" },
  ];
 




  // injobTable() {
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "Case Id", "CaseId"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "First Name", "FirstName"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "MOBILE NO", "MobileNo"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "EmailId", "EmailId"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "Serial No", "SerialNo1"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "Material Desc", "productDescription"));;
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "Remark", "Remark"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "Fault Description", "ComplainDesc"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "Job Status", "JobStatus"));
  //   this.JobColumns.push(this.dynamicService.getColumn("STRING", "Job Type", "JobType"));
  //   this.actionDetails.push({ code: 'Repair', icon: 'build_circle' });
  // }

  // injobTableEnquiry() {
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("STRING", "Customer Code", "CustomerCode"));
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("STRING", "First Name", "FirstName"));
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("STRING", "Last Name", "LastName"));
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("STRING", "MOBILE NO", "MobileNo"));
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("STRING", "EmailId", "EmailID"));
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("STRING", "Disposition Type", "DispositionType"));
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("STRING", "Remark", "Remark"));
  //   this.JobColumnsEnquiry.push(this.dynamicService.getColumn("Button", "Button", "Button"));
  //   this.actionDetails.push({ code: 'Repair', icon: 'build_circle' });
  // }

  // selectToken(){
  //   if(this.isSelectToken == true){
  //     this.isSelectToken = false;

  //   }else{
  //     this.isSelectToken = true;
  //   }
  // }

 
  // CloseSelectedToken($event){
  //   this.isSelectToken = $event
  // }


  getEnquiryList(customercode, customerfirstname, phonenumber, email) {
   
    let requestData = [];
    debugger
    requestData.push({
      "Key": "APIType",
      "Value": "GetEnquiryLists"
    });
    requestData.push({
      "Key": "CustomerCode",
      "Value": customercode
    });
    requestData.push({
      "Key": "CustomerName",
      "Value": customerfirstname
    });

    requestData.push({
      "Key": "MobileNo",
      "Value": phonenumber
    });
    requestData.push({
      "Key": "EmailId",
      "Value": email
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "PageNo",
      "Value": "1"
    });
    requestData.push({
      "Key": "PageSize",
      "Value": "5"
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          debugger
          try {
            let response = JSON.parse(Value.toString());
            console.log(response)
            if (response.ReturnCode == '0') {
              response['ExtraDataJSON'] = JSON.parse(response.ExtraData);
              let EnquiryListData = response['ExtraDataJSON']['EnquiryList']['Enquiry']
              var EnquiryFindData: any = [];
              if (Array.isArray(EnquiryListData)) {
                EnquiryFindData = EnquiryListData;
              }
              else {
                EnquiryFindData.push(EnquiryListData)
              } 
              this.JobDetailEnquriy.next({ totalRecord: EnquiryListData.length, Data: EnquiryFindData });
            }
            else {
              this.toastmeassge.error(response)
            }
          } catch (ext) { 
            console.log(ext);
          //  this.EnquiryList = [];
          //  this.JobDetailEnquriy.next({ totalRecord: this.EnquiryList.length, Data: this.EnquiryList });
          }
        },
        error: err => { 
          console.log(err);
        //  this.EnquiryList = [];
         // this.JobDetailEnquriy.next({ totalRecord: this.EnquiryList.length, Data: this.EnquiryList });
        }
      }
    );
  }

  SearchCallLogin() {
    this.getJobDetail(this.caseid, this.firstname, this.phonenumber, this.Emailid, this.Serialno, this.callType, this.JobStatustype);
  }

  getJobDetail(caseid, firstname, phonenumber, Emailid, Serialno, callType, JobStatustype) {
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetJobDetails"
    });
    requestData.push({
      "Key": "CaseId",
      "Value": caseid
    });
    requestData.push({
      "Key": "SerialNo",
      "Value": Serialno
    });
    requestData.push({
      "Key": "FirstName",
      "Value": firstname
    });
    requestData.push({
      "Key": "MobileNo",
      "Value": phonenumber
    });
    requestData.push({
      "Key": "EmailId",
      "Value": this.Emailid
    });

    requestData.push({
      "Key": "JobStatus",
      "Value": JobStatustype
    });
    requestData.push({
      "Key": "JobType",
      "Value": callType
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "PageNo",
      "Value": "1"
    });
    requestData.push({
      "Key": "PageSize",
      "Value": "5"
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {

          try {
            let response = JSON.parse(Value.toString());
            console.log(response)
            if (response.ReturnCode == '0') {
              response['ExtraDataJSON'] = JSON.parse(response.ExtraData);
              let jobListData = response['ExtraDataJSON']['JobList']['JobData']
              var JobFindData: any = [];
              if (Array.isArray(jobListData)) {
                JobFindData = jobListData;
              }
              else {
                JobFindData.push(jobListData)
              }
              this.JobDetail.next({ totalRecord: jobListData.length, Data: JobFindData });
            }
            else {
              this.toastmeassge.error(response)
            }
          } catch (ext) {
            console.log(ext);
            this.JobList = [];
            this.JobDetail.next({ totalRecord: this.JobList.length, Data: this.JobList });
          }
        },
        error: err => {
          
          console.log(err);
          this.JobList = [];
          this.JobDetail.next({ totalRecord: this.JobList.length, Data: this.JobList });
        }
      }
    );
  }

  // createNewJob(){
  //   this.isOtpVerification=true;
  // }

  // createNewJobWithout(){
  //   this.route.navigate(['/auth/' + glob.getCompanyCode() + '/create-job-customer'], { queryParams: { cc: glob.getCompanyCode(), nc: this.CustomerCode, tc:this.TokenNumber, td:this.TokenCreatedDate, cn:this.CounterNumber ,lc:this.selectedLocationCode } })
  // }

  iscreateJob:string;
 


  
  closeAddCustomer($event){
  this.isAddCustomerShow = $event
  }
 


  closePopUp(event)
  {
    this.isAddCustomerShow=event;
  }
  // customer list page load 
loadPageData(event){
  switch(event.eventType){
    case "PageChange":
      this.jobPagination.PageNumber  = event.eventDetail.pageIndex + 1;
      let requestData =[];

      requestData.push({
        "Key":"APIType",
        "Value": "GetCustomerList4Job"
      });
      requestData.push({
        "Key":"CompanyCode",
        "Value": glob.getCompanyCode()
      });
      requestData.push({
        "Key":"PageNo",
        "Value": event.eventDetail.pageIndex + 1 
      });
      requestData.push({
        "Key":"PageSize",
        "Value": event.eventDetail.pageSize
      }); 

      let strRequestData = JSON.stringify(requestData);
      let contentRequest =
      {
        "content" : strRequestData
      };    
      this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
        {
          next : (Value) =>
          {
            try{
              let response = JSON.parse(Value.toString());
              if(response.ReturnCode =='0')
              {
                let data = JSON.parse(response?.ExtraData);
                this.detail.next({totalRecord:data?.Totalrecords , Data: data?.CustomerList?.Customer });
              }
            }catch(ext){
              console.log(ext);
            }
          },
          error : err =>
          {
            console.log(err);
          }
        }
      );
      break;
  }  
  setTimeout(()=>{  this.hideSpinnerEvent.next(); }, 1);
}

// customerCode(event)
// {
//   this.route.navigate(['/auth/'+glob.getCompanyCode()+'/app-create-jobsheet'], { queryParams: { cc: event } })
// }

// isCustomerEvent(event){ 
//   this.route.navigate(['/auth/'+glob.getCompanyCode()+'/create-jobsheet'],{ queryParams:{cc:event}})
// }

actionEmit(event){  
 
  if(event.action == 'EDIT'){
    this.isAddCustomerShow=true;
    this.editCustomer=false;
    this.tokendata1=event.row.CustomerCode

  //  this.route.navigate(['/auth/'+glob.getCompanyCode()+'/add-customer-master'], { queryParams: { cc: event.row.CompanyCode, customercode:event.row.CustomerCode } })
  }
}



}
