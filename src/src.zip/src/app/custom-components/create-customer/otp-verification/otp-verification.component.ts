import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { ToastrService } from 'ngx-toastr';
import * as glob from "../../../config/global";
import { NgxSpinnerService } from 'ngx-spinner';
import xml2js from 'xml2js';
import { Subscription, interval } from 'rxjs';
import { v4 as uuidv4, parse } from 'uuid'; 
import { CaseDetail } from 'src/app/transaction/repair-process/repair-process.metadata';
// import { CaseDetail } from '../repair-process.metadata';

@Component({
  selector: 'app-otp-verification',
  templateUrl: './otp-verification.component.html',
  styleUrls: ['./otp-verification.component.css']
})
export class OtpVerificationComponent implements OnInit {

  isdiabled:boolean=false;

  @Input() Data;
  @Input()repa;
  
  

  @Input() LocationCode;
  @Input() TransactionType;

  @Output() openCreateJob = new EventEmitter<any>();
  @Output() CancelBtn = new EventEmitter<any>();
  @Output() handOverCheck = new EventEmitter<any>();
  @Output() OTPsubmit =new EventEmitter<any>();
  @ViewChild('minutes', { static: true }) minutes: ElementRef;
  @ViewChild('seconds', { static: true }) seconds: ElementRef;
  @Input() repaObj : CaseDetail;



  min: number = 2;
  secondsRemaining: number = this.min * 60;
  subscription: Subscription;
  otpinput: string
  OTPVerification: String
  errorMessage: any;
  resendOtp:boolean=true;
  istimerShow:boolean=false;
  @Input() dataObject;
  @Output() otpCancel =new EventEmitter();
  otpguid: string;
  OTPData: any
  constructor(
    private dynamicService : DynamicService,
    private spinner : NgxSpinnerService,
    private toaster: ToastrService
  ) { }


  
  ngOnInit() {
    this.isdiabled =true  
 
  }

  timeCounter()
  { 
    this.isdiabled=false; 
    
    if (this.subscription) {
      this.subscription.unsubscribe();
    }

      this.seconds.nativeElement.innerText= '00'
      this.minutes.nativeElement.innerText ='02'
    
    const source = interval(1000);
    this.subscription = source.subscribe(() => {

      this.secondsRemaining--;
      if (this.secondsRemaining < 0) {
        this.secondsRemaining = 0;
        this.isdiabled=  true
      }
      this.minutes.nativeElement.innerText = Math.floor(this.secondsRemaining / 60);
      this.seconds.nativeElement.innerText = ('0' + (this.secondsRemaining % 60)).slice(-2);
    });
  

  }

  submitType(){
    if(this.TransactionType == 'Handover'){ 
      this.submitOTPforHandover()
    }
    else if(this.TransactionType == 'CreateJob'){ 
   
      this.submitOTPforJob()
    }
  }

 
  submitOTPforJob(){ 
    console.log("====--===",this.Data)
    this.OTPVerification = this.otpinput
    if(this.OTPVerification != null || this.OTPVerification != undefined ){
        let otpguid=uuidv4()
        let requestData = []
        requestData.push({
          "Key":"APIType",
          "Value":"SaveOTPData"
        })
        requestData.push({
          "Key":"OTPVerificationGUID",
          "Value":this.OTPData?.OTP?.GUID
        })
        requestData.push({
          "Key":"OTPVerificationStatus",
          "Value":"VERIFIED"
        })
        requestData.push({
          "Key":"CustomerCode",
          "Value": this.Data.CustomerCode
        })
        requestData.push({
          "Key":"LocationCode",
          "Value": this.LocationCode
        })
        requestData.push({
          "Key":"OtpEntered",
          "Value":this.otpinput
        })
     
        requestData.push({
          "Key":"MobileNo",
          "Value":this.Data.MobileNo
        })
        
        let strRequestData = JSON.stringify(requestData);
        let contentRequest =
        {
          "content": strRequestData
        };

        // console.log("===-====-===",strRequestData)
       
        this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
          {
            next: (Value) => {
              try {
                let response = JSON.parse(Value.toString());
               
                if (response.ReturnCode == '0') { 

                  this.openCreateJob.emit(otpguid)
                  this.handOverCheck.emit(true)
                  let data = JSON.parse(response?.ExtraData);
                 // console.log("saved token status",data)
                } 
                else {
                  // console.log("Messages : " ,response)
                  this.errorMessage = response?.ErrorMessage;
                  console.log("Messages : " ,this.errorMessage)
                  const parser = new DOMParser();
                  const xmlDoc = parser.parseFromString(this.errorMessage, 'text/xml');
                  const errorMessages = xmlDoc.getElementsByTagName('ErrorMessage');
                  for (let i = 0; i < errorMessages.length; i++) {
                    const errorMsg = errorMessages[i].textContent;
                    this.toaster.error(errorMsg); // Display only the error message
                  }    
                }
              } 
              catch (ext) {
              }
            },
            error: err => { 
              console.log(err)
            }
    
          }
        );
    }else{
      this.toaster.error("Enter OTP First")
    }
    
  }
  submitOTPforHandover(){
   this.OTPsubmit.emit({ 'OTP' : this.otpinput,
                          'OTPGUID':this.otpguid})
  }
  
  limitInputLength(event: any) {
    const maxLength = 6;
    if (event.target.value.length > maxLength) {
      event.target.value = event.target.value.slice(0, maxLength);
      this.otpinput = event.target.value;
    }
  }
 
  cancle: boolean;
  CancelBtn1(){
    this.cancle = false; 
    this.CancelBtn.emit(this.cancle)  
  }
  
  GenerateOTP(){ 
    this.secondsRemaining = this.min * 60;
    this.istimerShow=true;
    this.timeCounter();
        let requestData = [];
        requestData.push({
          "Key": "ApiType",
          "Value": "SaveOTP"
        });
        requestData.push({
          "Key": "CompanyCode",
          "Value": glob.getCompanyCode()
        });
         requestData.push({
          "Key": "EmailId",
          "Value": this.Data.EmailID != undefined ? this.Data.EmailID : this.repa.CUSTOMER.EmailID
        });
        requestData.push({
          "Key": "LocationCode",
          "Value": this.LocationCode
        });
        requestData.push({
          "Key": "MobileNo",
          "Value": this.Data.MobileNo != undefined || this.Data.MobileNo != null ? this.Data.MobileNo :this.repa.CUSTOMER.MobileNo
        });
        // requestData.push({
        //   "Key": "TokenDate",
        //   "Value": this.Data.TokenDate != undefined || this.Data.TokenDate != null ? this.Data.TokenDate :this.repa.TokenDate
        // });
        // requestData.push({
        //   "Key": "TokenCode",
        //   "Value": this.Data.TokenCode != undefined  || this.Data.TokenCode != null ? this.Data.TokenCode : this.repa.TokenNumber
        // });   
        let strRequestData = JSON.stringify(requestData);
        
        let contentRequest = {
          "content": strRequestData
        };
       // console.log(contentRequest);
        this.spinner.show();
        this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
          {
            next: (value) => {
              this.spinner.hide();
              let response = JSON.parse(value.toString());
              if (response.ReturnCode == '0') {
                let data = JSON.parse(response?.ExtraData);
                this.OTPData = data
                console.log("data===",data)
                this.otpguid = this.OTPData?.OTP?.GUID
                alert(this.OTPData?.OTP?.OTP)
                //this.toaster.info(this.OTPData.OTP.OTP)
              }
              else {              
                this.spinner.hide();
                this.errorMessage = response.ReturnMessage;
                const parser = new xml2js.Parser({ strict: false, trim: true });
                parser.parseString(response.ErrorMessage, (err, result) => {
                  response['errorMessageJson'] = result;
                });
              }
  
            },
            error: err => {
              this.spinner.hide();
              console.log(err);
            }
          });

          //After 2min otp resend otp
          setTimeout(() => {
            this.resendOtp = false;
          }, 120000);
      } 

     
      
       

}