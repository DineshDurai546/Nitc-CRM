export class AddProduct {
  JobType: String;
  ServiceType: String;
  CustomerVoice: String;
  CREVoice: String;
  ProductTypeValues: String;
  SerialNo: String;
  coverageStartDate: string
  JobWarranty: String;
  ImageUrl: String;
  GsxWarrantyStatusCode: String;
  GsxWarrantyStatusDescription: String;
  ConfigCode: String;
  ConfigDescription: String;
  PurchaseDate: Date;
  ProductVersion: String;
  OnsiteCoverage: String;
  LaborCovered: string;
  PartCovered: String;
  DeviceCoverageDetails: String;
  Imei: String;
  Meid: String;
  ProductDescription: String;
  RetailCustomerCode: String;
  locationcode: String;
  ConfigurationCode: String;
  ConfigurationDescription: String;
  SoldToName: String;
  FirstActivationDate: String;
  PopDate: String;

  ElsStatus: String;
  ComplainDesc: String;
  Remark: String;
  AttachmentList: any;
  JobStatus: String;
  PurchaseCountryCode: String;
  PurchaseCountryDesc: String;
  TestingSroringData: any;
  BillingOptionX: String;
  BillingOptions: String;
  LocationCode: any;
  ChecklistE:any;
  ChecklistDescription: any
  checklistTotalvalues: any[]
  Condition: String
  DetailCondition: String
  ServiceType1:any;
  MaterialCode:any;
  MaterialName:any;
  WarrantyStatus:any;

  testData:any;
  MaterialTypeCode:any


  CoverageStartDate: String;
  CoverageEndDate: String;
  // SelectedProduct:String
}