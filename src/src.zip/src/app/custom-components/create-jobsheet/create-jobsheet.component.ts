import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validator,FormGroup, Validators,FormControl } from '@angular/forms';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DropDownType } from '../call-login/metadata/request.metadata';
import * as glob from 'src/app/config/global';
import { ToastrService } from 'ngx-toastr';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { AddProduct } from './AddProduct.metadata';
import { Product } from '../call-login/metadata/product.metadata';
import { v4 as uuidv4 } from 'uuid';
import { NgxSpinnerService } from 'ngx-spinner';
import xml2js from 'xml2js';
import { DatePipe } from '@angular/common';
import { ReportService } from 'src/app/common/Services/gsxService/report.service';

@Component({
  selector: 'app-create-jobsheet',
  templateUrl: './create-jobsheet.component.html',
  styleUrls: ['./create-jobsheet.component.css']
})
export class CreateJobsheetComponent implements OnInit {
  answer=''
  selectedbrand:any=['Iphone','Vivo']
  // =======================True & False =================================
  isDisabledProductable:Boolean=false;
  isDisabledSubmitBtn:boolean=false;
  isAddProductButtonShow: boolean = false;
  isjobverificationpop:boolean=false;
  IsEditproduct:boolean=false;
  isdisabledsearchbtn:boolean=false;
  dynamicColumnSize: boolean = false;
// ===========================Declare Variables===========================
  GetAuthSignatureimge;
  GetCustomerSignatureimge;
  currentId: number = 1;
  // CallTypeId="";
  // LocationId="";
  // BradId="";
  params:any;
  selectedCallForm: any;
  partCover = "";
  laborCover = "";
  onSiteCoverage = "";
  product: AddProduct;
  CustomerCode1;
  EmailID;
  MobileNo;
  CountryCode;
  CustomerName;
  FirstName;
  // LastName;
  Address1;
  // locationCode1="";
  
// =====================Declare Array & Object =================================
CustomerRecords:any=[];
  MultiProductData:any[]=[];
  products: Product[] = [];
  // checklistTotalvalues:any = [];
  TempFileList: any[]= [];
  // TempCheckList: any[]= []
  ServicetTypeArrya=[];
  checklistTotalvalues = [];
  selectCallType: DropDownValue = DropDownValue.getBlankObject();
  ProductType1: DropDownValue = this.getBlankObject();
  selectcalltype: DropDownValue = DropDownValue.getBlankObject();
  selectproducttype: DropDownValue = DropDownValue.getBlankObject();
  selectbillingoption: DropDownValue = DropDownValue.getBlankObject();
  selectlocation: DropDownValue = DropDownValue.getBlankObject();
  ELSStatusType:DropDownValue = DropDownValue.getBlankObject();
  callForm: DropDownValue = DropDownValue.getBlankObject();
  selectrepairtype:DropDownValue = DropDownValue.getBlankObject();
  selectMeteialCode:DropDownValue = DropDownValue.getBlankObject();
  isFrontIcon: boolean = true;

// =============================CustomerDetail Form Validation================================================
  customerdetailForm = this.formBuilder.group({
  servicetype:[null,Validators.required],
  location:[null,Validators.required],
  brand:[null,Validators.required],
  purchagedate:[]
});

// =============================ProductDetail Form Validation================================================
  addProductDetails = this.formBuilder.group({
    SerialNo:[null,Validators.required],
    ProductTypeValues:[null,Validators.required],
    BillingOption:[null,Validators.required],
    ElsStatus:[null,Validators.required],
    crevoice:[null,Validators.required],
    SelectedProduct:[null,Validators.required],
    SelectedDate:[null,Validators.required],
    Condition:[null,Validators.required],
    date:[null,Validators.required],
    customervoice:[null,Validators.required],
    uploadimage:[null,Validators.required],
    image:[null,Validators.required],
    repairtype:[null,Validators.required],
    materialcode:[null,Validators.required],
    InvoiceAmount:[null,Validators.required],
    Amount:[null,Validators.required],
    InvoiceNumber:[null,Validators.required],
  })  


  // =====================constructor (Inject)================================== 
  constructor( 
    private formBuilder: FormBuilder,
    private dropdownDataService:DropdownDataService,
    private dynamicService:DynamicService,
    private activatedRoute:ActivatedRoute,
    private router:Router,
    private toastrService: ToastrService,
    private spinner:NgxSpinnerService,
    private datePipe: DatePipe,
    private reportService:ReportService) {}



    // ========increasing  ItemNo================================
    generateId(): number {
      return this.currentId++;
    }

// =====================Customer Page Validadtion========================================
  CustomerDetails(){
    if(this.customerdetailForm.controls["servicetype"].value == null ||
     this.customerdetailForm.controls["servicetype"].value == undefined ||
      this.customerdetailForm.controls["servicetype"].value == "" ){
      this.toastrService.error("Please Select Call Type");
      return false;
    }
    if(this.customerdetailForm.controls["location"].value == null || 
    this.customerdetailForm.controls["location"].value == undefined || 
    this.customerdetailForm.controls["location"].value == "" ){
      this.toastrService.error("Please Select Location");
      return false;
    }
    if(this.customerdetailForm.controls["brand"].value == null || 
    this.customerdetailForm.controls["brand"].value == undefined || 
    this.customerdetailForm.controls["brand"].value == "" ){
      this.toastrService.error("Please Select  Brand");
      return false;
    }
    else{
  const ServiceTypeObj={
  "CallType":this.customerdetailForm.controls["servicetype"].value,
  "Location":this.customerdetailForm.controls["location"].value,
  "Brand":this.customerdetailForm.controls["brand"].value}
   this.ServicetTypeArrya.push(ServiceTypeObj);}
    }
    // selectedDate: Date = new Date();
PopDateFormate: string;
GetCustomerCode:any;
CurrentDate:any;
  ngOnInit(): void {
    const currentDate = new Date();
    this.CurrentDate = this.datePipe.transform(currentDate, 'dd-MM-yyyy');
    console.log("curret Date:",this.CurrentDate);
    this.getData();
    this.product = new AddProduct();
    this.params = this.activatedRoute.snapshot.queryParams;
    if(this.params.cc != null || this.params.cc != undefined){
    this.getCustomerDetails();}
    this.onProductType({ term: "", items: [] });
    this.onBillingOptionSearch({ term: "", items: [] });
    this.onLocationSearch({ term: "", item: [] });
    this.onELSStatusSearch({ term: "", items: [] });
    this.onCallTypeSearch({ term: "", item: null });
    this.onBrandSearch({ term: "", items: null });
    this.onRepiarTypeSearch({ term: "", items: null });
    this.JobSheetGUID = uuidv4 ();
    this.onSearchMaterailCode({ term: "", items: null });
    this.onSearchNonSerializedMaterailCode({ term: "", items: null})
  }

  getData() {
    let params = this.activatedRoute.snapshot.queryParams;
    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "GetCustomerCodeObj"
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "CustomerCode",
      "Value": params.cc
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (value) => {
          let response = JSON.parse(value.toString());
          if (response.ReturnCode == '0') {
            let data = JSON.parse(response.ExtraData).Customer;
            this.CustomerCode1 = data.CustomerCode,
            this.CustomerName = data?.CustomerName,
            this.FirstName = data?.FirstName
            this.EmailID = data?.EmailID,
            this.MobileNo = data?.MobileNo,
            this.CountryCode = data?.CountryCode,
            this.Address1 = data?.Address1,
            this.addProductDetails.patchValue({})}
          else {console.log("error");}
        },
        error: err => {console.log(err); }});
  }
  calltypevalue:any;


  // =============CALL TYPE DROPDOWN =================
    onCallTypeSearch($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.callForm, $event.term,{
    }).subscribe({
      next: (value) => {
        if (value != null) {
          console.log(value)
          this.selectCallType = value;
          this.calltypevalue = value.Data
        }
      },
      error: (err) => {
        this.selectCallType = DropDownValue.getBlankObject();
      }
    });
  }

  // =================================Get MaterialCode=====================
  onSearchMaterailCode($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.MaterialItemCode, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          console.log(value)
          this.selectMeteialCode = value;
          console.log("extra Data of selected materials:",this.selectMeteialCode)
        }
      },
      error: (err) => {
        this.selectMeteialCode = DropDownValue.getBlankObject();
      }
    });
  }
  
  // ================================= NonSerialized=====================
onSearchNonSerializedMaterailCode($event: { term: string; items: any[] }) {
  this.dropdownDataService.fetchDropDownData(DropDownType.bindnonserialized, $event.term, {
  }).subscribe({
    next: (value) => {
      if (value != null) {
        console.log(value)       
      }
    },
    error: (err) => {
      this.selectMeteialCode = DropDownValue.getBlankObject();
    }
  });
}

  CallTypeCode:any;
  locationcode:any;
  
  // =================================Get CallTypeID And TEXT=====================
  ServiceTypeEvent(event){
    for(let item of this.calltypevalue){
      if(item.Id == this.customerdetailForm.controls["servicetype"].value){
        // this.CallTypeCode = item.Id
        this.product.JobType = item.Id
      }
    }    
  }
  S_locationcode:any
    // =================================Get Location ID And TEXT=====================
  onchangelocation(event){
    for(let item of this.storelocationData){
      console.log("Location Id:",item)
      console.log("LocationId1:",this.customerdetailForm.controls["location"].value)
      if(item.TEXT == this.customerdetailForm.controls["location"].value){
        // this.S_locationcode = item.Id
        this.product.locationcode = item.Id
        console.log("Location Name:", this.product.locationcode)
      }
    }
  }

  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  BillingOptionText:any;

  // ===============BILLING OPTION DROPDOWN=============
  onBillingOptionSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.BillingOption, $event.term).subscribe({
      next: (value) => {
        if (value != null) {
          this.selectbillingoption = value;
          this.BillingOptionText =  value.Data

        }
      },
      error: (err) => {
        this.selectbillingoption = this.getBlankObject();
      }
    });
  }
  // =================BRAND DROPDOWN====================
  onBrandSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.bindbrand, $event.term).subscribe({
      next: (value) => {
        if (value != null) {
          this.selectedbrand = value;
        }
      },
      error: (err) => {
        this.selectedbrand = this.getBlankObject();
      }
    });
  }

storelocationData:any;
  // ================LOCATION DROPDOWN====================
  onLocationSearch($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.Location, $event.term, {
      CompanyCode: glob.getCompanyCode().toString(),
      JobType: this.selectedCallForm
    }).subscribe({
      next: (value) => {
        if (value != null) {
        this.selectlocation = value;
        this.storelocationData = value.Data
        }
      },
      error: (err) => {
        this.selectlocation = DropDownValue.getBlankObject();
      }
    });
  }
  // =============ELSE STATUS DROPDOWN=======================
  onELSStatusSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.ELSStatus, $event.term, {
      JobType: this.selectcalltype.toString(),
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.ELSStatusType = value;
        }
      },
      error: (err) => {
        this.ELSStatusType = this.getBlankObject();
      }
    });
  }
  // ===============REPAIR Type===============================
  onRepiarTypeSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.RepairType, $event.term, {
      JobType: this.selectcalltype.toString(),
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.selectrepairtype = value;
        }
      },
      error: (err) => {
        this.selectrepairtype = this.getBlankObject();
      }
    });
  }
  // ================PRODUCT TYPEDROPDOWN===============
  onProductType($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.ProductType, $event.term).subscribe({
      next: (value) => {
        if (value != null) {
          this.ProductType1 = value;
          
          console.log(":VALUE",value)
        }
      },
      error: (err) => {
        this.ProductType1 = this.getBlankObject();
      }
    });
  }   isEditable = false;

  // =============BIND SERIAL NUMBER==============
  Set_Non_Serialised(event) { 
    if(this.product.ProductTypeValues == "SERIALIZED"){
      this.Checklist_Master();
      this.isdiabledserialheader=false;
      this.dynamicColumnSize = !this.dynamicColumnSize;
      this.addProductDetails.get('materialcode').setValue('');
      this.isdiabledpopDate=false;
    }
    if (this.product.ProductTypeValues == "NONSERIALIZED") {
      console.log("Non:",event)
      this.Checklist_Master();
      this.NOn_SerialedMaterail();
      this.isdiabledpopDate=false;
    } 
    else { 
      this.product.SerialNo = "" 
      this.product.PurchaseCountryDesc = ""
      this.onSiteCoverage = ""
      this.partCover = ""
      this.laborCover = ""
      this.product.GsxWarrantyStatusDescription = ""
      this.product.ProductDescription = ""
      this.product.ConfigDescription = ""
    }
  }
  Biilong:any;
  BillingOptionEvent(event){
    for(let item of this.BillingOptionText){
      console.log("items:",item)
      console.log("LocationCode1:",this.addProductDetails.controls["BillingOption"].value)
      if(item.TEXT == this.addProductDetails.controls["BillingOption"].value){
        this.Biilong = item.TEXT
        console.log("biling Name:", this.Biilong)
      }
    }

  }


// FinalQuestionAnswes:any[]=[];
  // QuestionAnsers:any[]=[];
  FinalFileList=[]
  JobSheetGUID:any;
  // questionArray: any[] = [];
  FinalQuestionAnswes:any[]=[];
// ===================ADD PRODUCT OBJECT===============
  AddProduct(){
    let DateFormate = this.addProductDetails.controls['date'].value
    this.PopDateFormate = this.datePipe.transform(DateFormate, 'yyy-MM-dd');

      let AddProductObj={
        "JobSheetGUID":this.JobSheetGUID ,
        "BlackSerialNumber":"",
        "ProductType":this.addProductDetails.controls["ProductTypeValues"].value,
        "ProductTypeText":this.addProductDetails.controls["ProductTypeValues"].value,
        "BillingOption":this.addProductDetails.controls["BillingOption"].value,
        "SerialNo":this.addProductDetails.controls["SerialNo"].value,
        "ElsStatus":this.addProductDetails.controls["ElsStatus"].value,        
        "ProductName":this.product.MaterialName ,
         "CustomerVoice":this.addProductDetails.controls["customervoice"].value,
         "CREVoice":this.addProductDetails.controls["crevoice"].value,
         "RepairType":this.addProductDetails.controls["repairtype"].value,
         "MaterialCode": this.addProductDetails.controls["ProductTypeValues"].value == 'SERIALIZED' ? this.product.MaterialCode : this.addProductDetails.controls["materialcode"].value,
         "POPDate":this.PopDateFormate,
         "ItemNo":this.generateId(),
         "CompanyCode": glob.getCompanyCode(),
         "LocationCode":this.product.locationcode,
         "CallType":this.product.JobType,
         "InvoiceNumber":this.addProductDetails.controls["InvoiceNumber"].value,
         "Amount":this.addProductDetails.controls["Amount"].value,
         "InvoiceAmount":this.addProductDetails.controls["InvoiceAmount"].value
        }
        console.log("Objrct:",AddProductObj)
      
      // for(let item of DDList ){
      //   let text = this.getTextFromId(item.DDValue , item.DDname)
      //   AddProductObj = {...AddProductObj , text }
      // }

    for(let item of this.IsComponentArrya){
      const ComponentObj={
      "ComponentCode":item.Components,
      "IssueCode":item.Issues,
      "Productibility":item.Productibility,
      "CaseGuid":this.JobSheetGUID 
    }
    this.ComponetIssuesData.push(ComponentObj)
    for(let item of this.checklistTotalvalues){
      this.FinalQuestionAnswes.push({
        "answer":item.answer,
        "question":item.ChecklistDescription,
        "CaseGuid":this.JobSheetGUID
      })
    }

  }


 
    //   const ComponentObj={
    //   "ComponentCode":event.Components,
    //   "IssueCode":event.Issues,
    //   "Productibility":event.Productibility,
    //   "CaseGuid":this.JobSheetGUID 
    // }
    // console.log("Push Object Data:",ComponentObj);
      this.MultiProductData.push(AddProductObj);
      console.log("Product Data:",this.MultiProductData)
      for(let item of this.TempFileList){
        this.FinalFileList.push({
          "AttachmentFile" : item.AttachmentFile,
          "filename": item.filename,
          "src":item.src,
          "CaseGuid":this.JobSheetGUID 
        });
      }

  this.TempFileList = [];
  this.checklistTotalvalues = []
  this.IsComponentArrya=[];
  this.addProductDetails.reset();
  // this.ComponetIssuesData=[]
  this.JobSheetGUID = uuidv4 ();
  }

  getTextFromId(dd: DropDownValue , ddType: string ){
    const ddItem =  this.ELSStatusType.Data.find(  item => { item.Id == this.addProductDetails.value.ddType})
    return ddItem.TEXT
  }

AddedProductImage:any[]=[];
checkQuestionAnser:any=[];


    // ====DELETE PRODUCT==========
    deleteProduct(item: any) {
      const index = this.MultiProductData.indexOf(item);
      if (index !== -1) {
        this.MultiProductData.splice(index, 1);
      }
    }
// ===============DELETE IMAGE=================
  removerightImage(item) {
    console.log("Item Of")
    let UploadedImageIndex = this.TempFileList.indexOf(item);
    this.TempFileList.splice(UploadedImageIndex, 1);
    this.TempFileList =[]
  }

  // ===========EDIT PRODUCT DETAILS=================
  patchproduct(item: any, index: number) {
    let GUID = item.JobSheetGUID;
    this.IsEditproduct=true;
    this.addProductDetails.patchValue({
    ProductTypeValues: item.ProductType,
    SerialNo: item.SerialNo,
    ElsStatus:item.ElsStatus,
    BillingOption:item.BillingOption,
    customervoice:item.CustomerVoice,
    crevoice:item.CREVoice
    });
    let matchingFileRows = this.FinalFileList.filter((row) => row.CaseGuid === GUID);
    // let matchingCLRows = this.FinalQuestionAnswes.filter((row) => row.CaseGuid === GUID);
    console.log("Files Temp :- ", matchingFileRows)
    this.TempFileList.push(...matchingFileRows);
 
    this.MultiProductData.splice(index,1)
  }
  EditProduct(){
    this.IsEditproduct = false;
  }

// ============GET CUSTOMER DETAIL RECORDS==============

  getCustomerDetails(){
    let CustRequest=[];
    CustRequest.push({
      "Key":"APIType",
      "Value":"GetRtlCustomerObject"
    });
    CustRequest.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    }); 
    CustRequest.push({
      "Key":"CustomerCode", 
      "Value":this.params.cc
    });
    let CustRequestJson = JSON.stringify(CustRequest);
    let contentRequest={
      "content":CustRequestJson
    }
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
      next:(value)=>{
        let Response = JSON.parse(value.toString())
        if(Response.ReturnCode == '0'){
          let data = JSON.parse(Response?.ExtraData);
          this.CustomerRecords.push(data.Customer);
          console.log("Customer Data*******************:",this.CustomerRecords)
        }
        for(let item of this.CustomerRecords){
          this.GetCustomerCode=item.CustomerCode}
      }
    })
  }

  // =================PRODUCT DETAIL VALIDATION=====================
saveProduct()
{
    if(this.addProductDetails.controls["ProductTypeValues"].value == null ||
     this.addProductDetails.controls["ProductTypeValues"].value==undefined || 
     this.addProductDetails.controls["ProductTypeValues"].value ==""){
      this.toastrService.error("Please Select Product Type");
      return false;
    }
    if(this.addProductDetails.controls["ProductTypeValues"].value == 'SERIALIZED' ){
      if(this.addProductDetails.controls["SerialNo"].value == null || 
      this.addProductDetails.controls["SerialNo"].value==undefined || 
      this.addProductDetails.controls["SerialNo"].value ==""){
        this.toastrService.error("Please Enter SerialNo");
        return false;
      }
  }
    
    if(this.addProductDetails.controls["BillingOption"].value == null || 
    this.addProductDetails.controls["BillingOption"].value==undefined || 
    this.addProductDetails.controls["BillingOption"].value ==""){
      this.toastrService.error("Please Select Billing Option");
      return false;
    }
    if(this.addProductDetails.controls["ElsStatus"].value == null ||
    this.addProductDetails.controls["ElsStatus"].value==undefined || 
    this.addProductDetails.controls["ElsStatus"].value ==""){
      this.toastrService.error("Please Select ELS Status");
      return false
    }
    if(this.addProductDetails.controls["date"].value == null ||
     this.addProductDetails.controls["date"].value==undefined || 
     this.addProductDetails.controls["date"].value ==""){
      this.toastrService.error("Please Select POP Date");
      return false;
    }
    if(this.addProductDetails.controls["customervoice"].value == null ||
     this.addProductDetails.controls["customervoice"].value==undefined ||
      this.addProductDetails.controls["customervoice"].value ==""){
      this.toastrService.error("Please Enter Customer Voice");
      return false;
    }
    if(this.addProductDetails.controls["repairtype"].value == null ||
    this.addProductDetails.controls["repairtype"].value==undefined ||
     this.addProductDetails.controls["repairtype"].value ==""){
     this.toastrService.error("Please Select Repair Type");
     return false;
   }
   if(this.addProductDetails.controls["ProductTypeValues"].value == 'NONSERIALIZED' ){
   if(this.addProductDetails.controls["materialcode"].value == null ||
   this.addProductDetails.controls["materialcode"].value==undefined ||
    this.addProductDetails.controls["materialcode"].value ==""){
    this.toastrService.error("Please Select Material Code");
    return false;
  }
}
    if(this.addProductDetails.controls["crevoice"].value == null || 
    this.addProductDetails.controls["crevoice"].value==undefined || 
    this.addProductDetails.controls["crevoice"].value ==""){
      this.toastrService.error("Please Enter CCE Voice");
      return false;
    }

    if(this.TempFileList.length<=0){
      this.toastrService.error("Please Upload Image File");
      return false;
    }
    if(this.IsComponentArrya.length<=0){
      this.toastrService.error("Plese Select Component And  Issue");
      return false;
    }

    for(let item of this.checklistTotalvalues){
      if(item?.answer == ""){
      this.toastrService.error("Plase Select Answers for",item.ChecklistDescription)
      return
      }
    }

   
  const newSerialNo = this.addProductDetails.get('SerialNo').value 
  let inputProduct = true
  for ( let item of this.MultiProductData){
    if( item.ProductType == 'SERIALIZED' && item.SerialNo == newSerialNo){
      this.toastrService.error('Serial No already exists. Please choose a different Serial No.')
      inputProduct = false ;
    }
  }
  if( inputProduct == true){
    this.isDisabledProductable=true;
    this.isDisabledSubmitBtn=true;
    this.AddProduct();
    this.addProductDetails.reset();
  }

}

    // ===========Image Upload==============
    imageUpload(event: any) {
      for (var i = 0; i <= event.target.files.length - 1; i++) {
        let fileToUpload = <File>event.target.files[0];
        if( fileToUpload.type.match(/\/jpg|\/jpeg|\/png|\/pdf/) == null ){
          this.toastrService.error("Please select a jpg, jpeg, png or pdf file type");
          return;
        }
        const formData = new FormData();
        var filename = uuidv4() + "_" + fileToUpload.name;
        formData.append('file', fileToUpload, filename);
        this.dynamicService.uploadimagefile(formData).subscribe(
          {
            next: (value) => {
              let uploadedimage: any;
              uploadedimage = value;
              this.TempFileList.push({
                "AttachmentFile": uploadedimage?.dbPath,
                "src": glob.GLOBALVARIABLE.SERVER_LINK + uploadedimage?.dbPath,
                "filename": fileToUpload.name,
              })
              this.isFrontIcon = false;
            }
          });
      }
    }

    SetAuthSignature:any;
    SetCustomerSignature:any
    GetAuthSignature(event){
      this.SetAuthSignature = event
    }
    GetCustomerSignature(event){
      this.SetCustomerSignature = event
    }

  uploadedimageXML(){
    let rawData = {
      "rows": []
    }
    for (let item of this.FinalFileList) {
      rawData.rows.push({
        "row": {
          "CaseGuid":item.CaseGuid,
          "AttachmentOriginType": item.AttachmentFile,
          "AttachmentFile":this.SetCustomerSignature,
          "AttachmentType":this.SetAuthSignature,
        }
      })
    }
    var builder = new xml2js.Builder();
    var xml = builder.buildObject(rawData);
    xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
    xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
    return xml;
  }

  ComponentIssuesXml(){
    let rawData = {
      "rows": []
    }

    // "row": {
    //   "CaseGuid":item.CaseGuid,
    //   "ComponentCode":item.Components,
    //   "ComponentDesc":item.Components,
    //   "IssueCode":item.Issues,
    //   "IssueDesc":item.Issues,
    // }
    for (let item of this.ComponetIssuesData) {
      console.log("Compoenet IssuesCode:",item)
      rawData.rows.push({
        "row": {
          "CaseGuid":item.CaseGuid,
          "ComponentCode":item.ComponentCode,
          "ComponentDesc":item.ComponentCode,
          "IssueCode":item.IssueCode,
          "IssueDesc":item.IssueCode,
        }
      })
    }
    var builder = new xml2js.Builder();
    var xml = builder.buildObject(rawData);
    xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
    xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
    return xml;

  }

  productdetailXML(){
    let rawData = {
      "rows": []
    }
    for (let item of this.MultiProductData) {
      rawData.rows.push({
      "row": {
    "CaseGuid":item.JobSheetGUID,
    "ItemNo":item.ItemNo,
    "SerialNo1": item.SerialNo ,
    "MaterialCode":item.MaterialCode,
    "CaseId":"",
    "JobType":item.CallType,
    "LocationCode":item.LocationCode,
    "CompanyCode":item.CompanyCode,
    "imei":"",
    "meid":"",
    "Brand":this.customerdetailForm.controls["brand"].value,
    "ProductType":item.ProductType,
    "productDescription":item.ProductName,
    "POPDate":item.POPDate,
    "soldToName":"REDINGTON LIMITED",
    "ActivationDate":"2023-08-06",
    "CoverageStartdate":"2023-08-06",
    "CoverageEndDate":"2023-09-14",
    "ElsStatus":item.ElsStatus,
    "ProductImageURL":"",
    "ComplainDesc":item.CREVoice,
    "Remark":item.CustomerVoice,
    "JobStatus":"S01",
    "BillingOption":item.BillingOption,
    "WarrantyStatus":"Under Warranty",
    "InvoiceAmount":item.InvoiceAmount,
    "Amount":item.Amount,
    "InvoiceNumber":item.InvoiceNumber,
    "PartCovered":"1",
    "LaborCovered":"1",
        }
      })
    }
    var builder = new xml2js.Builder();
    var xml = builder.buildObject(rawData);
    xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
    xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
    return xml;

  }
  cancePopUpbtn(){
    this.isjobverificationpop=false;
  }
  OpenJobSheetPopUp(){
    this.isjobverificationpop=true;
  }

    SubmitCustomerForm() {
      let requestCust = [];
      requestCust.push({
        "Key": "APIType",
        "Value":"SaveJobDetails"
      });
      requestCust.push({
        "Key": "JOBHeaderGUID",
       "Value": uuidv4()
      });
      requestCust.push({
        "Key": "CompanyCode",
       "Value": glob.getCompanyCode()
      });
      requestCust.push({
        "Key": "JOBType",
       "Value": this.product.JobType
      });
      requestCust.push({
        "Key": "JobDocCode",
       "Value": "IND22305300006"
      });
      requestCust.push({
        "Key": "JobDocDate",
       "Value": "2023-05-30"
      });
      requestCust.push({
        "Key": "LocationCode",
        "Value": this.product.locationcode
      });
      requestCust.push({
        "Key": "RetailCustomerCode",
       "Value": this.GetCustomerCode
      });
      requestCust.push({
        "Key": "Brand",
        "Value":this.customerdetailForm.controls["brand"].value
      });
      requestCust.push({
        "Key": "JobDocStatus",
       "Value":"OPEN"
      });
      requestCust.push({
        "Key": "RefDocType",
       "Value": ""
      });
      requestCust.push({
        "Key": "Remark",
       "Value":""
      });
      requestCust.push({
        "Key": "RefDocGUID",
       "Value":"00000000-0000-0000-0000-000000000000"
      });
      requestCust.push({
        "Key": "Attachment",
        "Value": this.uploadedimageXML()
      });
      requestCust.push({
        "Key": "ComponentIssue",
        "Value":this.ComponentIssuesXml()
      });
      requestCust.push({
        "Key": "ChecklistDetail",
        "Value":this.checklistXML1()
      });
      requestCust.push({
        "Key": "ProductDetails",
        "Value": this.productdetailXML()
      });
      console.log("All Array Data:",requestCust)
      let productRequet = JSON.stringify(requestCust);
  
      let requestContent={
        "content":productRequet
      }
      this.dynamicService.getDynamicDetaildata(requestContent).subscribe({
        next:(value)=>{
          console.log("Values Saved:",value)
          let response = JSON.parse(value.toString())
          if(response.ReturnCode=='0'){
            this.toastrService.success("JobSheet Created SuceessFully");
            this.router.navigate(['/auth/'+glob.getCompanyCode()+'/dashboard'])
          }
          else{
            console.log("Error is:",response)
            this.toastrService.error(" JobSheet Already Created ")
          }

        }
      })
    }

    GetCustomerData(){
      for(let item of this.TempFileList){
        console.log("Uploaded Image",item)
      }
    }
    GenarteRandomNumber(){
      const originalString = "upload/workorder/d35b7223-5eae-44a0-a402-11946285b33e_signature.png";
      const modifiedString = originalString.replace("upload/workorder/", "");
      console.log("FinalOutPut",modifiedString); // Output: d35b7223-5eae-44a0-a402-11946285b33e_signature.png 
    }
    TotalSerialNO:any[]=[];
    isdiabledserialheader:boolean=false;
    strSerialData:any;


    // warrantyDurationInDays: number = 365; 
    // purchaseDate: Date = new Date('1-1-2021');
  //  currentDate = Date = new Date('1-1-2021');
  WarrantyStatus:string;
  isdiabledpopDate:boolean=false;
    SearchSerialNo(){

      let GetSerialNo = [];
      GetSerialNo.push({
        "Key":"APIType",
        "Value":"GetProductSerialNo"
      })
      GetSerialNo.push({
        "Key":"SerialNo",
        "Value":this.addProductDetails.controls["SerialNo"].value
      })
      GetSerialNo.push({
        "Key":"PageNo",
        "Value":"1"
      })
      GetSerialNo.push({
        "Key":"PageSize",
        "Value":"100"
      })
      console.log("Serial Nu,ber Array Data:",GetSerialNo)
      let GetSerialNoRespose = JSON.stringify(GetSerialNo);
      let SerialRequest={
        "content":GetSerialNoRespose
      }
      this.dynamicService.getDynamicDetaildata(SerialRequest).subscribe({
        next:(value)=>{
          let response = JSON.parse(value.toString())
          let extraserialnumber = JSON.parse(response?.ExtraData);
          if(extraserialnumber.Totalrecords=='1'){
         
            this.toastrService.success("Serial Number Founds")
            console.log("Coverage ",extraserialnumber?.SerialNo?.Data?.CoverageStartDate)
           
            this.isdiabledserialheader=true;
            this.strSerialData = extraserialnumber;
            this.product.Imei = extraserialnumber?.SerialNo?.Data?.imei,
            this.product.Meid = extraserialnumber?.SerialNo?.Data?.meid,
            this.product.SoldToName = extraserialnumber?.SerialNo?.Data?.soldToName,
            this.product.CoverageEndDate = extraserialnumber?.SerialNo?.Data?.CoverageEndDate,
            this.product.LaborCovered = extraserialnumber?.SerialNo?.Data?.LaborCovered,
            this.product.PartCovered = extraserialnumber?.SerialNo?.Data?.PartCovered
            this.product.CoverageStartDate =  extraserialnumber?.SerialNo?.Data?.CoverageStartDate
            this.product.MaterialCode = extraserialnumber?.SerialNo?.Data?.MaterialCode[0 ]
            this.product.MaterialName = extraserialnumber?.SerialNo?.Data?.MaterialName
          const CoverageStartDate = extraserialnumber?.SerialNo?.Data?.CoverageStartDate;
          const CoverageEndDate = extraserialnumber?.SerialNo?.Data?.CoverageEndDate;
          const currentDate = new Date();
          const year = currentDate.getFullYear();
         const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Adding 1 because months are zero-based
         const day = String(currentDate.getDate()).padStart(2, '0');
         const CurrectDateformate = `${year}-${month}-${day}`;
         if(extraserialnumber?.SerialNo?.Data?.CoverageStartDate == null || extraserialnumber?.SerialNo?.Data?.CoverageStartDate == undefined ){
          this.isdiabledpopDate=true;
          this.product.WarrantyStatus="*****************";
          }
          else if (CurrectDateformate >= CoverageStartDate && CurrectDateformate <= CoverageEndDate) {
            this.product.WarrantyStatus="Under Warranty";
            this.isdiabledpopDate=false;
            } 
          else{     
              this.product.WarrantyStatus="Out Of Warranty";
              this.isdiabledpopDate=false;
                }
          }
          else{
           
            this.toastrService.error("Not Found Serial No")
          }
        }
      })
    }


  iscomponentpopup:boolean=false;
  OpenComponent(){
    this.iscomponentpopup = true;
  }
  ComponentPopUpColse(event){ 
    this.iscomponentpopup=false;
  }
  ComponetIssuesData:any=[];
  IsComponentArrya:any[]=[];
  ComponentObj(event){
    this.IsComponentArrya.push(event)
    console.log("Component Issues Code:",event)
    // this.ComponetIssuesData.push(event)
    // console.log("Component Code:",event)
    // const ComponentObj={
    //   "ComponentCode":event.Components,
    //   "IssueCode":event.Issues,
    //   "Productibility":event.Productibility,
    //   "CaseGuid":this.JobSheetGUID 
    // }
    // console.log("Push Object Data:",ComponentObj);
    // this.ComponetIssuesData.push(ComponentObj);
    // console.log("Array Data:",this.ComponetIssuesData)
    }
    CompoenetIssuea:any=[];
    removeComponentIssue(item){
  
      let UploadedImageIndex = this.IsComponentArrya.indexOf(item);
      this.IsComponentArrya.splice(UploadedImageIndex, 1);
    }
    NOn_SerialedMaterail(){
      let ReqNonSerialed=[];
      ReqNonSerialed.push({
        "Key":"APIType",
        "Value":"GetNonSerialized"
      })
      ReqNonSerialed.push({
        "Key":"PageNo",
        "Value":"1"
      })
      ReqNonSerialed.push({
        "Key":"PageSize",
        "Value":"10"
      })
    let requestJson = JSON.stringify(ReqNonSerialed)
    let requestContent = {
      "content":requestJson
    }
    this.dynamicService.getDynamicDetaildata(requestContent).subscribe({
      next:(value)=>{
        console.log("Values:",value)
        let response = JSON.parse(value.toString())
        if(response.ReturnCode == '0'){
          let Data = JSON.parse(response.ExtraData);
          this.product.MaterialTypeCode = Data.materialdetail.MaterialData.MaterialTypeCode
          console.log("Material TypeCode:", Data)
        }
      }
    })
    }
    MaterialChangeEvent(event){
      this.isdiabledserialheader=true;
      this.product.MaterialName = event.extraDataJson.Data.MaterialName[0]
      this.product.WarrantyStatus = "******************";
      this.isdiabledpopDate=true;
    }


    // Get CheckList
    Checklist_Master() {
      let strQuestion = [];
      strQuestion.push({
        "Key": "ApiType",
        "Value": "GetCheckListDetails"
      });
      strQuestion.push({
        "Key": "Stage",
        "Value": "JOBCREATE"
      });
      strQuestion.push({
        "Key": "ProductName",
        "Value":"iPhone 12 Pro"
      });
      let strRequestData = JSON.stringify(strQuestion);
      let contentRequest = {
        "content": strRequestData
      };
      this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
        next: (value) => {
          this.spinner.show()
          setTimeout(() => {
            this.spinner.hide();
          }, 2000);
          let response = JSON.parse(value.toString());
          if (response.ReturnCode == '0') {
            let checklistdata = JSON.parse(response.ExtraData);
            this.checklistTotalvalues = [];
            if (Array.isArray(checklistdata.CheckListDetails.CheckList)) {
              this.checklistTotalvalues = checklistdata.CheckListDetails.CheckList;
            }
            else {
              this.checklistTotalvalues.push(checklistdata.CheckListDetails.CheckList);
            }
            var Cnt = 0;
            for (let item of this.checklistTotalvalues) {
              console.log("Checklist QuestAndAswers:",item)
              item.formControlName = "Question" + Cnt.toString();
              item.arrFldValue = this.splitAndformat(item.FldValue);
              item.defaultvalue = item.DefaultValue.trim();
              item.answer = ''
  
              var iscontrolexists = this.ChecklistForm.controls[item.formControlName] == undefined ? 0 : 1;
              if (iscontrolexists == 0) {
                this.ChecklistForm.addControl(item.formControlName, new FormControl());
              }
              Cnt = Cnt + 1;
              this.spinner.hide()
            }
          } 
        },
      });
    }
    checklistvaluechange(item, item1) {
      console.log(item1)
      item.answer = item1.value;
      
    }
    DyanamicValidation(){
      for (let item of this.checklistTotalvalues) {
        var questions = item.ChecklistDescription
        var answer = item.answer;
        this.questionArray.push(item);
        if (answer == null || answer == undefined || answer == "") {
          this.toastrService.error("Checklist " + questions + " can not be blank");
          break;
        }
      }
    }
    questionArray: any[] = [];

    splitAndformat(tags: any) {
      var arr = [];
      for (let item of tags.split(",")) {
        arr.push({ label: item.trim(), value: item.trim() });
      }
      return arr;
    }

    checklistXML1(){
      let rawData = {
        "rows": []
      }
      for (let item of this.FinalQuestionAnswes) {
        rawData.rows.push({
          "row": {
            "CaseGuid":item.CaseGuid,
            "ChecklistQuestion":item.question,
            "ChecklistAnswer":item.answer
          }
        })
      }
      var builder = new xml2js.Builder();
      var xml = builder.buildObject(rawData);
      xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
      xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
      return xml;
  
    }
    ChecklistForm = this.formBuilder.group({

    })

    // Check Warranty(Number Of Days)

    remainingWarrantyDays: number;
    //  purchaseDate: Date = new Date('1-1-2021');
      warrantyDurationInDays: number = 365; 
      Tadydate : Date = new Date('25-8-2023'); // Replace with your warranty duration in days

    // PurChageData(){
    //   const purchaseDate = this.addProductDetails.controls['date'].value
    //   console.log("Purchase Date:",purchaseDate)
    //   const currentDate =  this.Tadydate
    //   console.log("Todaya Date:",currentDate)
    //   const warrantyExpiryDate = new Date(purchaseDate);
    //   warrantyExpiryDate.setDate(warrantyExpiryDate.getDate() + this.warrantyDurationInDays);
    //   if (currentDate < warrantyExpiryDate) {
    //     const timeDiff = warrantyExpiryDate.getTime() - currentDate.getTime();
    //     this.remainingWarrantyDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    //     alert('Under Warranty'+ this.remainingWarrantyDays)
    //   } else {
    //     this.remainingWarrantyDays = 0; 
    //     alert("Warranty has expired:"+ this.remainingWarrantyDays)
  
    //   }
    // }
    CheckElseStatus(event){
      console.log("Else Status:",event)
    }

    // PurchageProduct(){
    //   const coverageStartDate = new Date('2023-01-01 00:00:00.000');
    //   const coverageEndDate = new Date('2024-01-02 00:00:00.000');
    //   const currentDate = new Date();
    //   if (currentDate >= coverageStartDate && currentDate <= coverageEndDate){
    //     alert("Within warranty")
    //     // console.log('Within warranty');
    //   } else {
    //     alert("Out of warranty")
    //     console.log('Out of warranty');
    //   }  
      
    // }

    // purchaseDate: string;
    currentDate: string = new Date().toISOString().split('T')[0];
    warrantyStatus: string;
    // checkWarranty() {
    //   const purachedate = this.customerdetailForm.controls['purchagedate'].value
    //   console.log("Purchage Date:",purachedate)
    //   console.log("Current Date:",this.currentDate)
    //   const purchaseDateTime = new Date(purachedate).getTime();
    //   const currentDateTime = new Date(this.currentDate).getTime();
    //   const millisecondsInADay = 24 * 60 * 60 * 1000; // 1 day in milliseconds
    //   const warrantyDurationInDays = 365; // Assume warranty duration is 1 year
  
    //   if (currentDateTime - purchaseDateTime <= warrantyDurationInDays * millisecondsInADay) {
    //     this.warrantyStatus = 'Under Warranty';
    //   } else {
    //     this.warrantyStatus = 'Out of Warranty';
    //   }
    // }

    PopDateEvent(event){
      const purachedate = this.addProductDetails.controls['date'].value;
      const purchaseDateTime = new Date(purachedate).getTime();
      const currentDateTime = new Date(this.currentDate).getTime();
      const millisecondsInADay = 24 * 60 * 60 * 1000; // 1 day in milliseconds
      const purchaseDate = new Date(purachedate);
      const warrantyEndDate = new Date(purchaseDate);
      warrantyEndDate.setFullYear(warrantyEndDate.getFullYear() + 1); // Increase by 1 year
      const diff = currentDateTime - purchaseDateTime; // Calculate the difference in milliseconds
      const warranty = warrantyEndDate.getTime() - purchaseDateTime; // Calculate the warranty duration in milliseconds

      if (diff <= warranty) {
        this.addProductDetails.controls['BillingOption'].enable()
        this.warrantyStatus = 'Under Warranty';
        this.product.WarrantyStatus = this.warrantyStatus
      } else {
        this.warrantyStatus = 'Out of Warranty';
        
        this.addProductDetails.controls['BillingOption'].disable()
        this.addProductDetails.patchValue({ BillingOption :  'BILLABLE'})
        this.product.WarrantyStatus = this.warrantyStatus
      }

    }

  }



