import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobsheetVerificationComponent } from './jobsheet-verification.component';

describe('JobsheetVerificationComponent', () => {
  let component: JobsheetVerificationComponent;
  let fixture: ComponentFixture<JobsheetVerificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobsheetVerificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JobsheetVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
