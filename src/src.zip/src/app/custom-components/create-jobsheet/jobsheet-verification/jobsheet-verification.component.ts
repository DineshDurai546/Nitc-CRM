import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import * as glob from 'src/app/config/global';
import { ActivatedRoute, Router } from '@angular/router';
import SignaturePad from 'signature_pad';
import { v4 as uuidv4 } from 'uuid';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-jobsheet-verification',
  templateUrl: './jobsheet-verification.component.html',
  styleUrls: ['./jobsheet-verification.component.css']
})
export class JobsheetVerificationComponent implements OnInit {
  @Input() GetCustomerDetailData:any;
  @Input() GetProductDetailData:any;
  @Input() GetServiceTypeData:any;
  @Output() submitCustomerForm = new EventEmitter<any>();
  @Output() ClosePopUp = new EventEmitter<any>();
  @Input() verificationArray: any={};
  @Input() imageListArray: any={};
  @Input() CustomerDetailData:any;


  @ViewChild("canvas", { static: true }) canvas: ElementRef;
  isNONSERIALIZED:boolean=false;
  isWOHDMI:boolean=false;
  SignatureFileName:String ;
  authorSigFileName:String;
  AuthorizationFileName:String;
  typeSelected = 'ball-clip-rotate';
  
  @ViewChild("customerSign", { static: true }) customerSignature: ElementRef;
  customerSignPad: SignaturePad;

  @ViewChild("authorizationSign", { static: true }) authorizationSignature: ElementRef;
  authorizationSignPad:SignaturePad;
  imageStr:any[]=[];

  close: boolean;
  CloseEvent: any;
  toaster: any;
  SignatureTypeValue: string;
  authorisedSignature: any;
  errorMessage: any;
  termsandcondition:boolean=false;
  isOpenterms:boolean=false;
  
  constructor(
    private dynamicService: DynamicService,
    private activatedRoute: ActivatedRoute,
    private toasty: ToastrService,
    private spinner: NgxSpinnerService
  ) { }

  // @Output() signatureValidate = new EventEmitter<any>();
  // @Output() authorizationValidate = new EventEmitter<any>();


  // authSaveSignature()
  // {
  //   const authorSig = new FormData();
  //   var filename = uuidv4() + "_signature.png" ;
  //   authorSig.append('file', this.dataURLtoBlob(this.authorizationSignPad.toDataURL()),filename);
  //   this.dynamicService.uploadimagefile(authorSig).subscribe(
  //     {
  //       next: (value) => {
  //         let uploadedimage: any;
  //         uploadedimage = value;
  //         this.authorSigFileName =  uploadedimage?.dbPath;
  //         this.authorizationValidate.emit(this.authorSigFileName) ;  
  //       }
  //     });
  // }

  // sig: SignaturePad;
  // SaveSignature()
  // {
  //   const formDataSig = new FormData();
  //   var filename = uuidv4() + "_signature.png" ;
  //   formDataSig.append('file', this.dataURLtoBlob(this.customerSignPad.toDataURL()),filename);
  //   this.dynamicService.uploadimagefile(formDataSig).subscribe(
  //     {
  //       next: (value) => {
  //         let uploadedimage: any;
  //         uploadedimage = value;
  //         var close = false 
  //         this.SignatureFileName =  uploadedimage?.dbPath;
  //         this.signatureValidate.emit(this.SignatureFileName)
  //         console.log("Calling Customer Function:",this.SignatureFileName)
  //       }
  //     });
  // }

  save: boolean;
 
  dataURLtoBlob(dataurl) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
}


 
  ngOnInit(): void { 
    this.imagePush()
    // this.customerSignPad = new SignaturePad(this.customerSignature.nativeElement);
    // this.authorizationSignPad = new SignaturePad(this.authorizationSignature.nativeElement);
    // this.sig = new SignaturePad(this.canvas.nativeElement);
    // this.SignatureFileName="";
    // this.authorSigFileName="";
  }

 //============Verification PopUp close Function====================
isverificationPopClose()
{
  this.close = false; 
}

//Images Push [To HTML]
imagePush()
{ 
  for(let i=0; i<this.imageListArray.length ; i++)
  {
   this.imageStr.push(this.imageListArray[i][0]['src']); 
  }
}

  ngOnDestroy() 
  {
    while(this.imageListArray.length > 0) 
    {
      this.imageListArray.pop();    
    }  }

//RESET customer sign
ClearSignature()
{
  this.customerSignPad.clear();
  this.SignatureFileName = "";
}

//Clear Authorization Sign 
authorizationClearSignature()
{
  this.authorizationSignPad.clear();
  this.authorSigFileName ="";
}

popupClose($event)
{
  this.isOpenterms = $event; 
}
CloseBbtn(){
  this.close = false; 
  this.ClosePopUp.emit(this.close )
}

verificationSave(){
this.submitCustomerForm.emit();
}
//   if(this.authorizationSignPad.isEmpty())
//   {
//     this.toasty.error("Please Add Authorization Signature.");
//     return ;
//   }
//   else if(this.customerSignPad.isEmpty())
//   {
//     this.toasty.error("Please Add Customer Signature.");
//     return ;
//   }
//   else{
//     this.authSaveSignature();
//     this.SaveSignature();
    
//      this.spinner.show();
//     setTimeout(() => {
      
//       this.spinner.hide();
//         this.CloseBbtn();
//    
//     }, 2000);
//   } 
// }
// sIGNATURE(){
//   console.log("AuthSign:",this.authorSigFileName);
//   console.log("Customer Sign:",this.SignatureFileName)
// }
}
