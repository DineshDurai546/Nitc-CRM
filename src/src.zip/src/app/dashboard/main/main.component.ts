import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog'
import { Router } from '@angular/router';
import { AppInitService } from 'src/app/core/service/app.init.service';
import { CommonService } from 'src/app/core/service/common.service';
import { CompanyDetailComponent } from '../company-detail/company-detail.component';
import * as glob from  "../../config/global";

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {

  constructor(
    public dialog: MatDialog,
    private router: Router,
    private appInitService: AppInitService,
    public commonService: CommonService,
  ) { }

  ngOnInit() {
    this.openDialog();
  }

  openDialog(): void {
    if (this.commonService.checkCompanyPermission()) {
      let dialogRef = this.dialog.open(CompanyDetailComponent, {
        width: '80%',
        disableClose: true,
        data: {
          allowtoclose: false
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result != null && result != undefined) {
          let companyCode = result.trim();
          glob.setCompanyCode(companyCode);
          this.appInitService.initNotFound(companyCode);
          debugger;
          if(glob.getLogedInUser().UserDetails.MenuGroupId==2)
          {
            this.router.navigate(['auth/' + companyCode + "/token-create"]);
          }
          else if(glob.getLogedInUser().UserDetails.MenuGroupId==5)
          {
            this.router.navigate(['auth/' + companyCode + "/token-display"]);
          }
          else
          {

          
          this.router.navigate(['auth/' + companyCode + "/dashboard"]);
          }
        }
      });
    }
    else {
      this.router.navigate(['authentication/nopermission']);
    }
  }

}
