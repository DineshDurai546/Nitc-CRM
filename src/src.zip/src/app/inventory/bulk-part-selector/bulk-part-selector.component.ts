import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { ToastrService } from 'ngx-toastr';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-bulk-part-selector',
  templateUrl: './bulk-part-selector.component.html',
  styleUrls: ['./bulk-part-selector.component.css']
})
export class BulkPartSelectorComponent implements OnInit {

  typeSelected = 'ball-clip-rotate';

  toastr: any;
  validateAllFormFields: any;
  returnOrderPartList: any[] = [];
  resourceData: any[] = []
  SelectedReturnOrderPartList: any[] = [];
  SelectedPartCount: Number = 0;
  searchText: String = "";
  close: boolean = false
  showonlyselected: boolean = false;
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  @Input() returnType:string;
  @Input() ToLocationCode: string;
  @Output() returnOrderPartSelector = new EventEmitter<any>();
  @Output() closeReturnOrderPartSelector  = new EventEmitter<any>();


  ngOnChanges(changes: SimpleChanges): void {

    if (changes['objcasedetail']) {
      this.GetReturnOrder();
    }
  }

  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  constructor(
    private dynamicService: DynamicService,
    private toast: ToastrService,
    private ngxSpinnerService: NgxSpinnerService,
  ) { }


  ngOnInit() {
    this.GetReturnOrder();
  }

  onSubmit() {
    this.SelectedReturnOrderPartList = [];
    for (let item of this.returnOrderPartList) {
      if (item.selected == true) {
        // let retvalue = this.returnOrderPartList.filter(partNumber => partNumber.toString() == item.partNumber.toString());
        this.SelectedReturnOrderPartList.push(item);
      }
    }
    console.log("Selected List ", this.SelectedReturnOrderPartList)
    this.returnOrderPartSelector.emit(this.SelectedReturnOrderPartList);
    this.closeReturnOrderPartSelector.emit(false);

  }

  UpdateSelectedCount() {
    this.SelectedPartCount = this.returnOrderPartList.filter(x => x.selected == true).length;
  }

  GetReturnOrder() {
    this.ngxSpinnerService.show();
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetReturnOrderList"
    });
    requestData.push({
      "Key": "ReturnOrderType",
      "Value": this.returnType
    });
    requestData.push({
      "Key": "ToLocationCode",
      "Value": this.ToLocationCode
    });

    // requestData.push({
    //   "Key": "PageNo",
    //   "Value": "1"
    // });
    // requestData.push({
    //   "Key": "PageSize",
    //   "Value": "10"
    // });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    console.log("Before List ", requestData)
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          try {
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              this.toast.success("Records Found") 
              let data = JSON.parse(response?.ExtraData);
              console.log("Result ", data)
              if(Array.isArray(data?.ReturnOrderList?.ReturnOrder))
              {
                this.returnOrderPartList = data?.ReturnOrderList?.ReturnOrder
                // console.log(re)
              }
              else
              {
                this.returnOrderPartList.push(data?.ReturnOrderList?.ReturnOrder)
              }
              this.detail.next({ totalRecord: data?.Totalrecords, Data: this.returnOrderPartList });
              console.log('Data' , this.detail)
              this.ngxSpinnerService.hide()
            }
          } catch (ext) {
            this.ngxSpinnerService.hide()
            console.log(ext);
          }
        },
        error: err => {
          this.ngxSpinnerService.hide()
          console.log(err);
        }
      }
    );
  }


  onSearchChange(text) {
    console.log(text);

    for (let item of this.returnOrderPartList) {
      if (text.length > 1) {
        item.inSearch = (item.partDescription.toLowerCase().includes(text.toLowerCase()) || item.repairId.toLowerCase().includes(text.toLowerCase()) || item.repairDevice?.identifiers?.serial.toLowerCase().includes(text.toLowerCase()) || item.partNumber.toLowerCase().includes(text.toLowerCase()));
      } else {
        item.inSearch = false;
      }
    }
  }


  sortArrayOfObjects = <T>(
    data: T[],
    keyToSort: keyof T,
    direction: 'ascending' | 'descending' | 'none',
  ) => {
    if (direction === 'none') {
      return data
    }
    const compare = (objectA: T, objectB: T) => {
      const valueA = objectA[keyToSort]
      const valueB = objectB[keyToSort]

      if (valueA === valueB) {

        return 0
      }

      if (valueA > valueB) {
        return direction === 'ascending' ? 1 : -1
      } else {
        return direction === 'ascending' ? -1 : 1
      }
    }

    return data.slice().sort(compare)
  }



  isToShowTr(item): Boolean {
    if (this.showonlyselected == false) {
      if (this.searchText.length <= 1) {
        return true;
      } else if (item.selected == true) {
        return true;
      } else if (item.inSearch) {
        return true;
      } else {
        return false;
      }
    }
    else {
      if (item.selected == true) {
        return true;
      } else {
        return false;
      }

    }
  }

}
