import { Component, OnInit, Input } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Columns } from 'src/app/models/column.metadata';
import { ToastrService } from 'ngx-toastr';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { ACTIONENUM } from 'src/app/config/comman.const';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Router } from '@angular/router';
import { Filter } from 'src/app/custom-components/call-login-dashboard/filter.meta' 
import { Observable } from 'rxjs/internal/Observable';
import { PaginationMetaData } from 'src/app/models/pagination.metadata';
import * as glob from 'src/app/config/global'

@Component({
  selector: 'app-bulk-return-list',
  templateUrl: './bulk-return-list.component.html',
  styleUrls: ['./bulk-return-list.component.css']
})
export class BulkReturnListComponent implements OnInit {

  breadCumbList: any[];
  screenDetail: any;
  actionDetails: any[]=[
    {"code": "EDIT","icon": "edit","title": "Edit"}
  ];
  screen:any;
  isChoose: boolean = false;
  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  @Input() filters: Observable<Filter[]>;
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  typeSelected = 'ball-clip-rotate';
  selectedCallForm: any;
  searchText: String = "";
  returnTypeArray:any[] = ["Parts-Pending","Mail-In"];
  returnTypeData:string;
  jobPagination: PaginationMetaData;
  toolBarAction: any[] = [];

  columns: Columns[] = [
    {datatype:"STRING",field:"BulkReturnId",title:"Bulk Return Id"},
    {datatype:"STRING",field:"TransportationCarrier",title:"Transportation Carrier"},
    {datatype:"STRING",field:"Length",title:"Length"},
    {datatype:"STRING",field:"Breadth",title:"Breadth"},
    {datatype:"STRING",field:"Height",title:"Height"},
    {datatype:"STRING",field:"Weight",title:"Weight"},
    {datatype:"STRING",field:"TrackingNumber",title:"Tracking Number"},
    {datatype:"STRING",field:"LocationCode",title:"Location Code"},
    {datatype:"STRING",field:"ShipTo",title:"Ship To"},
    {datatype:"STRING",field:"ReturnOrderStatus",title:"Status"},
    {datatype:"STRING",field:"ReturnAddress",title:"Return Address"},
  ];

  constructor(
    private route: Router,
    private dynamicService: DynamicService,
    private ngxservice: NgxSpinnerService,
    private toast: ToastrService,
  ) {
    this.toolBarAction.push({ code: "ADD", icon: "add_circle_outline", title: "Add" });
  }

  actionEmit(event){
    console.log("action Emit", event);
    if(event.action == 'EDIT'){
      this.route.navigate(['/auth/'+glob.getCompanyCode()+'/bulk-return-order'], { queryParams: { headerguid: event.row.BulkReturnOrderHeaderGUID} })
    }
  }

  ngOnInit(): void {

  }

  actionEvent = (act: any) => {
    switch (act.code) {
      case ACTIONENUM.ADD:
        this.add();
        break;
    }
  }

  add(){
    this.route.navigate(['/auth/'+glob.getCompanyCode()+'/bulk-return-order/']);
  }

  GetBulkOrder() {
    debugger;
    this.ngxservice.show();
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetBulkReturnOrderList"
    });
    requestData.push({
      "Key": "ReturnType",
      "Value": this.returnTypeData
    });
    requestData.push({
      "Key": "PageNo",
      "Value": "1"
    });
    requestData.push({
      "Key": "PageSize",
      "Value": "10"
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          debugger
          try {
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              this.toast.success("Records Found")
              let data = JSON.parse(response?.ExtraData);
              let results = []
              if(Array.isArray(data?.BulkReturnOrderList?.BulkReturnOrder))
              {
                results = data?.BulkReturnOrderList?.BulkReturnOrder
                console.log(results)
              }
              else
              {
                results.push(data?.BulkReturnOrderList?.BulkReturnOrder)
              }
              this.detail.next({ totalRecord: data?.Totalrecords, Data: results });
              console.log('Data' , this.detail)
              this.ngxservice.hide()
            }
          } catch (ext) {
            console.log(ext);
          }
        },
        error: err => {
          console.log(err);
        }
      }
    );
  }


  loadPageData(event){
    switch(event.eventType){
      case "PageChange":
        this.jobPagination.PageNumber  = event.eventDetail.pageIndex + 1;
        let requestData =[];
        requestData.push({
          "Key":"APIType",
          "Value": "GetBulkReturnOrderList"
        });
        requestData.push({
          "Key":"PageNo",
          "Value": event.eventDetail.pageIndex + 1 
        });
        requestData.push({
          "Key":"PageSize",
          "Value": event.eventDetail.pageSize
        });
        let strRequestData = JSON.stringify(requestData);
        let contentRequest =
        {
          "content" : strRequestData
        };    
        this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
          {
            next : (Value) =>
            {
              try{
                let response = JSON.parse(Value.toString());
                if(response.ReturnCode =='0')
                {
                  let data = JSON.parse(response?.ExtraData);
                  this.detail.next({totalRecord:data?.Totalrecords , Data: data?.BulkReturnOrderList?.BulkReturnOrder });
                }
              }catch(ext){
                console.log(ext);
              }
            },
            error : err =>
            {
              console.log(err);
            }
          }
        );
        break;
    }  
    setTimeout(()=>{  this.hideSpinnerEvent.next(); }, 1);
  }

}
