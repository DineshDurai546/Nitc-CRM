import { Component, OnInit, Input, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { ToastrService } from 'ngx-toastr';
import xml2js from 'xml2js';
import { Location } from '@angular/common'
import { NgxSpinnerService } from 'ngx-spinner';
import { GsxService } from 'src/app/common/Services/gsxService/gsx.service';
import { v4 as uuidv4 } from 'uuid';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as glob from 'src/app/config/global';
// import { ImagePopupComponent } from 'src/app/custom-components/create-job-customer/image-popup/image-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { lastValueFrom } from 'rxjs';
import { NgSelectComponent } from '@ng-select/ng-select';
import { element } from 'protractor';
import { DomSanitizer } from '@angular/platform-browser';
import { ReportService } from 'src/app/common/Services/gsxService/report.service';


@Component({
  selector: 'app-bulk-return-order',
  templateUrl: './bulk-return-order.component.html',
  styleUrls: ['./bulk-return-order.component.css']
})
export class BulkReturnOrderComponent implements OnInit {


  constructor(
    private toastMessage: ToastrService,
    private ngxSpinnerService: NgxSpinnerService,
    private gsxService: GsxService,
    private activatedRoute: ActivatedRoute,
    private route: Router,
    private reportService: ReportService,
    private location: Location,
    private dynamicService: DynamicService,
    private dropdownDataService: DropdownDataService,
    private dialog: MatDialog,
    // private renderer: Renderer2
  ) { }

  isReturnOrderPartSelector: boolean = false;
  partList: any[] = [];
  readData: boolean = true;
  transportationCarrierData: string;
  length: string;
  params: any;
  breadth: string;
  hideShipmentButton: boolean ;
  typeSelected = 'ball-clip-rotate';
  height: string;
  trackingNumber: string;
  weight: string;
  bulkReturnHeaderGUID: string;
  ToLocationCode: string;
  returnAddress: string;
  isShipmentDone: string;
  returnOrderPartList: any[] = [];
  finalSelectedParts: any[] = [];
  Ship_to_GSX: string;
  hideSaveButton: boolean = false;
  disableReturnType: boolean = false; 
  disableRemarkButton: boolean = true; // Default: true
  showRemarkButton: boolean = false; // Default: true
  selectedCallForm: any;
  selectedLocationCode;
  errorMessage: string;
  bulkReturnId: string= ''; // Default value
  addedPartCount: any;
  bulkPartSelectorView: any[] = [];
  CountOverPack: any = [];
  OverPackBoxData: any = ['Ind', '1'];
  OverPackBox: any[] = []
  returnTypeArray: any[] = ["Parts-Pending", "Mail-In"];
  printTypeArray: any[] = ["All-Return-Labels", "Packing-List", "Delivery Challan"];
  returnTypeData: string;
  returnRemark: string;
  printTypeData:string;
  fileType:string;
  trackingUrl: string;
  TransportationCarrier: DropDownValue = this.getBlankObject();
  BulkReturnDD: DropDownValue = this.getBlankObject();
  BulkReturnType: string
  LocationForJob: DropDownValue = DropDownValue.getBlankObject();
  Spinner: string
  // Image Variables
  isFileUploads = true;
  frontImageList: any =[];
  // Define the number of file to be uploaded
  noOfFilesToUpload = 5;

  // ReturnOrderStatus Value
  ApprovalGUID= '';
  showFileUploadOptions  =false;
  showFileButtons = false;
  AddFiles = false;
  // For Status = Rejected  or Approved
  ApprovalStatus: string;
  CreatedDate: Date;
  
  @ViewChild('forShipmentDetails', { static: true }) forShipmentDetails: ElementRef;
  // For Add Part and Save Buttons
  isEdit: boolean; // Default is true
  fileOptions: boolean // Default is Send for Approval Button
  isApproverPermission: boolean = false 
  submitClicked =false 

  ngOnInit(): void {
    this.isEdit = false; // Default is false
    this.hideShipmentButton = true; // Default hide Shipment Button
    this.showFileUploadOptions = true;
    this.forShipmentDetails.nativeElement.parentElement.classList.remove('disabled-select') // Default Editable Shipment Details
    this.fileOptions= true // Default is Send for Approval Button

    this.params = this.activatedRoute.snapshot.queryParams;
    if (this.params.headerguid != null || this.params.headerguid != undefined) {
      // Get a list of 5 integer indexes for File Upload List and After Upload to Server List:-
        for (let i = 0; i < this.noOfFilesToUpload; i++)  {
            this.FileUploadList[i] = { AttachmentFile: null, src: null, filename: '', type: ''}; 
            this.UploadedFileList[i] = { AttachmentFile: null, src: null, filename: '', type: ''}; 
        }
      this.getData()
    }
    else if (Object.keys(this.params).length == 0) {
      this.showFileUploadOptions = false;
      this.AddFiles = true;
      this.ApprovalStatus = 'NEW'
      this.isEdit= true;
    }
    
    // this.location.back()
    this.onBulkReturnOrderType({ term: '', items: [] })
    this.onTransportationCarrier({ term: '', items: [] })
    this.onLocationSearch({ term: "", item: [] });
    this.UpdateCountOverPack()
  }


  openPartSelector() {
    if (this.BulkReturnType == null || this.BulkReturnType == undefined) {
      this.toastMessage.error("Please Select Return Type to add parts")
    }
    else if (this.ToLocationCode == null || this.ToLocationCode == undefined) {
      this.toastMessage.error("Please select Location To Add parts")
    }
    else {
      if (this.isReturnOrderPartSelector == true) {
        this.isReturnOrderPartSelector = false;
      } else {
        this.isReturnOrderPartSelector = true;
      }
    }

  }


  UpdateCountOverPack() {
    if (this.CountOverPack.length == 0) {
      this.CountOverPack.push("Individual");
      this.CountOverPack.push("1");

    }
    else {
      var tmpcntpack = 0;
      for (let item of this.bulkPartSelectorView) {

        var cp = item.CountPack == "Individual" ? 0 : item.CountPack == undefined || item.CountPack == null ? 0 : parseInt(item.CountPack.toString())
        tmpcntpack = tmpcntpack < cp ? cp : tmpcntpack

      }
      this.CountOverPack = []
      this.CountOverPack.push("Individual");
      this.CountOverPack.push("1");
      for (let i = 2; i <= tmpcntpack + 1; i++) {
        this.CountOverPack.push(i.toString());
      }

    }
  }

  validateReturnItem(com: any) {
    for (let item of this.finalSelectedParts) {
      if (item.repairId == com.repairId && item.sequenceNumber == com.sequenceNumber && item.partNumber == com.partNumber) {
        this.toastMessage.error("Part already exists")
        return false;
      }
    }
    return true;
  }

  returnOrderPartSelector($event) {
    this.finalSelectedParts = $event
    // if (this.partList != null && this.partList != undefined) {
    //   this.disableReturnType = true
    //     for (var item of this.partList) {
    //           this..push({
    //             "sequenceNumber": item.sequenceNumber,
    //             "partNumber": item.partNumber,
    //             "serialNumber": item.repairDevice?.identifiers?.serial,
    //             "partDescription": item.partDescription,
    //             "productDescription": item.productDescription,
    //             "repairId": item.repairId,
    //             "returnOrderNumber": item.returnOrderNumber,
    //             "purchaseOrderNumber": item.purchaseOrderNumber,
    //             "batteryNetWeight": item.batteryNetWeight,
    //             "returnLabelPrinted": item.returnLabelPrinted,
    //             "received": item.received == null || item.received == undefined ? '...' : item.received,
    //             "quantity": item.quantity == null || item.quantity == undefined ? 1 : item.quantity,
    //             "CountPack": "Individual",
    //             "IsGSXPosted": "0",
    //             "IsDeleted": "0",
    //             "wareHouseAddress": item.wareHouseAddress,
    //             "vendorAddress": item.vendorAddress
    //           })
    //           // this.finalSelectedParts[0].vendorAddress = item.vendorAddress
    //           // this.finalSelectedParts[0].wareHouseAddress = item.wareHouseAddress
    //     }
    //   this.UpdateSelectedCount()
    // }
    console.log(" Selected List in Bulk ",this.finalSelectedParts)
    // if(this.finalSelectedParts.length > 0)
    // {
    //   if(!(this.finalSelectedParts[0].wareHouseAddress == undefined || this.finalSelectedParts[0].wareHouseAddress == null))
    //   {
    //     let address = this.finalSelectedParts[0].wareHouseAddress
    //     this.returnAddress = address.warehouseName + ", " + address.street + ", "  + address.city   + ", " + address.countryName + ", " + address.postalCode
  
    //   }
    //   else if (!(this.finalSelectedParts[0].vendorAddress == undefined || this.finalSelectedParts[0].vendorAddress == null))
    //   {
    //     let address = this.finalSelectedParts[0].vendorAddress
    //     this.returnAddress = address.vendorName + ", " + address.street + ", "  + address.city +  + ", " + address.countryName + ", " + address.postalCode

    //   }
    //   else
    //   {
    //     this.returnAddress = ""
    //   }

    // }
  }

  showShipTo() {
    if (this.ToLocationCode != null || this.ToLocationCode != undefined) {
      this.readData = false;
    }
    else {
      this.readData = true;
    }
  }

  //this function saves the confirmed shipment from GSX to NITC Database
  saveConfirmedShipment() {
    this.ngxSpinnerService.show()
    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "SaveConfirmShipment"
    })
    requestData.push({
      "Key": "BulkReturnId",
      "Value": this.bulkReturnId
    })
    requestData.push({
      "Key": "BulkReturnHeaderGUID",
      "Value": this.bulkReturnHeaderGUID
    })
    requestData.push({
      "Key": "TrackingUrl",
      "Value": this.trackingUrl
    })
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (value) => {
          let response = JSON.parse(value.toString());
          if (response.ReturnCode == '0') {
            this.toastMessage.success("Successfully Parts Added")
            this.ngxSpinnerService.hide();
          }
          else {
            this.errorMessage = response.ReturnMessage;
            this.toastMessage.error(response.ReturnMessage)
          }
        },
        error: err => {
          console.log(err);
          this.ngxSpinnerService.hide();
        }
      });
  }

  //This functions confirms the Shipment on GSX
  confirmShipment() {
    this.ngxSpinnerService.show();
    var objData = {
      "bulkReturn": this.bulkReturnId,
      "shipmentDetails": {
        "notes": "Bulk Shipment",
        "packageMeasurements": {
          "length": this.length,
          "width": this.breadth,
          "weight": this.weight,
          "height": this.height
        },
        "carrierCode": this.transportationCarrierData,
        "trackingNumber": this.trackingNumber
      },
      "shipTo": this.Ship_to_GSX
    }
    var strRequestData = JSON.stringify(objData)
    var data = {
      "Content": strRequestData
    }
    // console.log(data)
    this.gsxService.returnConfirmShipment(data).subscribe({
      next: (value) => {
        this.ngxSpinnerService.hide()
        let response = JSON.parse(value.toString());
        if (!(response.errors == undefined || response.errors == null)) {
          var errorMessage = "";
          for (let iCtr = 0; iCtr < response.errors.length; iCtr++) {
            errorMessage = response.errors[iCtr].code + ' - ' + response.errors[iCtr].message;
            this.toastMessage.error(errorMessage, "Error", { closeButton: true, disableTimeOut: true })
          }
        }
        else {
          this.toastMessage.success("Data posted successfully")
          console.log(response)
          this.trackingUrl = response.trackingURL
        }
      },
      error: (err) => {
        console.log(err);
        this.toastMessage.error("Please try again. " + err)
        this.ngxSpinnerService.hide()
      }
    });
  }


  //This function gets the detail of existing Bulk Return
  getData() {

    this.ngxSpinnerService.show()
    // debugger

    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "GetBulkReturnOrderObject"
    });
    requestData.push({
      "Key": "BulkReturnOrderHeaderGUID",
      "Value": this.params.headerguid
    });

    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    // console.log("Before GetData SP:-", requestData )
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (value) => {
          // debugger
          let response = JSON.parse(value.toString());
          let data = JSON.parse(response.ExtraData.toString())
          if (response.ReturnCode == '0') {
            console.log("After Get Data Funct, SP Response:- ", data)
            //Set Status in the Header
            this.ApprovalStatus = data?.ReturnOrderStatus;
            // console.log("Status:- ", this.ApprovalStatus)
            // Disbale Location Dropdown Value for isEdit mode:-
            this.disableReturnType = true
            this.CreatedDate = data.CreatedDate
            this.readData = false;
            this.bulkReturnHeaderGUID = data.BulkReturnOrderHeaderGUID
            this.bulkReturnId = data.BulkReturnId
            this.transportationCarrierData = data.TransportationCarrier
            this.ToLocationCode = data.LocationCode
            this.returnTypeData = data.ReturnType
            this.length = data.Length
            this.breadth = data.Breadth
            this.height = data.Height
            this.weight = data.Weight
            this.trackingNumber = data.TrackingNumber
            this.Ship_to_GSX = data.ShipTo
            this.returnAddress = data.ReturnAddress
            this.isShipmentDone = data.isShipmentDone
            this.ApprovalStatus = data.ReturnOrderStatus
            this.ApprovalGUID = data.ApprovalGUID
            this.FinalFileObjects = data.ApprovalFile
            this.FinalFileNames = data.BulkStatusList?.FileNames
            this.FinalFileTypes = data.BulkStatusList?.FileTypes
            this.returnRemark = data.BulkStatusList?.ApprovalRemark

            // If Files are available then show them:-
            // console.log("Final Files ", this.FinalFileObjects)
            if ( (this.FinalFileObjects == null || this.FinalFileObjects == undefined) && this.isApproverPermission == false ){
              this.ApprovalStatus == 'NEW' || this.ApprovalStatus == 'NEED MORE INFORMATION' ?  this.toastMessage.info("Upload/Edit Files") : ''
            }
            else{
              this.extractFileSrc(this.FinalFileObjects, this.FinalFileNames, this.FinalFileTypes);
            }

            let xmldata = data.BulkReturnDetailList.BulkReturnDetail
            var result = []
            if (Array.isArray(xmldata)) {
              result = xmldata
            }
            else {
              result.push(xmldata)
            }
            for (let item of result) {
              this.finalSelectedParts.push({
                "BulkReturnOrderDetailGUID":item.BulkReturnOrderDetailGUID,
                "partNumber": item.PartCode,
                "serialNumber": item.SerialNo,
                "partDescription": item.PartDescription,
                "productDescription": item.ProductDescription,
                "repairId": item.RepairId,
                "returnOrderNumber": item.ReturnOrderNumber,
                "purchaseOrderNumber": item.PurchaseOrderNumber,
                "batteryNetWeight": item.BatteryNetWeight,
                "received": item.Recieved,
                "returnLabelPrinted": item.returnLabelPrinted,
                "CountPack": item.OverPackBox
              })
            }
            // console.log("Shipment Done:-", data.isShipmentDone)
            // debugger
            this.ngxSpinnerService.hide()
            this.checkLocalPermission() // Check if Local Appprover
            this.checkStatusChanges(this.isApproverPermission, data.isShipmentDone)
          }
          else {
            this.ngxSpinnerService.hide()
            this.toastMessage.error("Something Went Wrong")
          }
        },
        error: err => {
          this.toastMessage.error(err)
        }
      });
  }

  checkStatusChanges(isApproverPermission, isShipmentDone){
    // First Check all the Parameters
    console.log("Status- ", this.ApprovalStatus, "\n ApproverPermission- ", isApproverPermission, "\nShipment Done?- ", isShipmentDone)
    this.showFileUploadOptions = true;
    this.showFileButtons = false;
    this.isEdit= false;
    this.showRemarkButton = false
    this.forShipmentDetails.nativeElement.parentElement.classList.add('disabled-select')
    this.disableRemarkButton = true
    
    // When Local Approver Views
    if ( isApproverPermission== true) { 
      if (this.ApprovalStatus == 'NEED MORE INFORMATION') {
        this.showRemarkButton = true
      }
      else if (this.ApprovalStatus == 'SENT FOR APPROVAL') {
        this.fileOptions= false
        this.showFileButtons = true;
        this.showRemarkButton = true;
        this.disableRemarkButton = false
      }
      else if (this.ApprovalStatus == 'NEW'){
        // Hide Remark Button
        if (this.FileUploadList.some(file => {file?.src !=null || file?.src!= undefined}) ){
          this.showFileButtons = true
          this.fileOptions = false
        }
      }
      else if (this.ApprovalStatus== 'APPROVED' || this.ApprovalStatus == 'REJECTED') {
        this.showFileButtons = false
        this.showRemarkButton = true
      }
    }
    else if (this.ApprovalStatus== 'NEW' ) {
      this.fileOptions = true
      this.showFileButtons = true
      this.AddFiles = true
      // this.isEdit= true;
      // this.showFileUploadOptions= true;
    }
    else if (this.ApprovalStatus== 'SENT FOR APPROVAL' ) {
      // this.forShipmentDetails.nativeElement.parentElement.classList.add('disabled-select')
    }
    else if (this.ApprovalStatus== 'APPROVED' || this.ApprovalStatus == 'REJECTED') {
      // this.showFileUploadOptions= false; // Hide file upload options
      // Show Remark but disable it
      this.showFileButtons = false
      this.disableRemarkButton = true
      if (this.ApprovalStatus == 'APPROVED'){
        this.showRemarkButton = true  
        isShipmentDone == 0 ? this.hideShipmentButton = false : this.hideShipmentButton = true // Enable Confirm Shipment Button
      }
    } 
    else if (this.ApprovalStatus== 'NEED MORE INFORMATION' ) {
      this.showFileButtons = true
      this.AddFiles = true
      // this.isEdit= true;
      // Show Remark but disable it
      this.showRemarkButton = true
      this.disableRemarkButton = true
    }    
    else{
      this.toastMessage.error("Error in Status, contact IT")
      this.showFileUploadOptions = false;
      // Disable Shipment Details and hide buttons:- 
      this.forShipmentDetails.nativeElement.parentElement.classList.add('disabled-select') 
      // Show Remark but disable it
      this.disableRemarkButton = true
    }
    
    if (isShipmentDone == 0 ) {
      // Hide Add Parts and Save Buttons
      this.isEdit= true;
      this.showRemarkButton= false
    }
    else if (isShipmentDone == 1  ) {
      // Hide Add Parts and Save Buttons
      this.isEdit= false;
      this.showRemarkButton= false
    }
   
  }

  async onSubmit() {

    if(this.finalSelectedParts== null || this.finalSelectedParts == undefined || this.finalSelectedParts.length > 0){
      this.toastMessage.error("No Bulk Return Id found")
      return
    }
    let requestData = [];
    // debugger
    requestData.push({
      "Key": "ApiType",
      "Value": "SaveBulkReturnOrder"
    });
    // requestData.push({
    //   "Key": "BulkReturnId",
    //   "Value": this.bulkReturnId == null || this.bulkReturnId == undefined ? '' : this.bulkReturnId
    // });
    this.bulkReturnHeaderGUID = this.params.headerguid == null || this.params.headerguid == undefined ? uuidv4() : this.params.headerguid 
    requestData.push({
      "Key": "BulkReturnOrderHeaderGUID",
      "Value": this.bulkReturnHeaderGUID
    });
    requestData.push({
      "Key": "ReturnType",
      "Value": this.returnTypeData
    })
    requestData.push({
      "Key": "TransportationCarrier",
      "Value": this.transportationCarrierData
    });
    requestData.push({
      "Key": "Length",
      "Value": this.length
    });
    requestData.push({
      "Key": "Breadth",
      "Value": this.breadth
    });
    requestData.push({
      "Key": "Height",
      "Value": this.height
    });
    requestData.push({
      "Key": "Weight",
      "Value": this.weight
    });
    requestData.push({
      "Key": "TrackingNumber",
      "Value": this.trackingNumber
    });
    requestData.push({
      "Key": "LocationCode",
      "Value": this.location
    });
    requestData.push({
      "Key": "ShipTo",
      "Value": this.ToLocationCode
    });
    requestData.push({
      "Key": "ReturnAddress",
      "Value": this.returnAddress == null || this.returnAddress == undefined ? "" : this.returnAddress
    });
    requestData.push({
      "Key": "BulkReturnOrderDetail",
      "Value": this.saveBulkReturnOrderXml()
    });
    
    // Set Status NEW for the first time 
    requestData.push({
      "Key": "ReturnOrderStatus",
      "Value": 'PREPARING FOR SHIPMENT'
    });
    requestData.push({
      "Key": "ApprovalGUID",
      "Value": '00000000-0000-0000-0000-000000000000'
    });
    requestData.push({
      "Key": "ApprovalFile",
      "Value": ''
    });
    
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    
    // // Checking if the DetailGUID is the same each time when editing the existing Parts in the Detail Table 
    // const xml = requestData.find(item => item.Key === 'BulkReturnOrderDetail').Value;
    // // console.log("XML Dumb is :- ", xml)
    // xml2js.parseString(xml, (err, result) => {
    //   const rows = result.rows.row;
    //   const detailGUIDs = rows.map(row => row.BulkReturnOrderDetailGUID);
    //   // Log the resulting XML string
    //   // console.log("Before sending to DB the Details GUIDs :-", detailGUIDs);
    // });
    
    if(this.submitClicked == true)
    {
      return;
    }
    this.submitClicked=true
    // // TODO:- 
    // console.log("Whole Data before Sending to Save:- ",requestData)
    // return
    this.ngxSpinnerService.show();
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (value) => {
          let response = JSON.parse(value.toString());
          this.submitClicked = false
          // console.log("After OnSubmit BulkReturn Header SP :- ",response)
          if (response.ReturnCode == '0') {
            this.toastMessage.success("Successfully Parts Added")
            this.ngxSpinnerService.hide();
            this.toastMessage.info("Upload Files Now!")
            this.route.navigate(["auth/" + glob.getCompanyCode() + "/bulk-return-order"], {queryParams: {headerguid : this.bulkReturnHeaderGUID}})
          }
          else {
            this.errorMessage = response.ReturnMessage;
            this.toastMessage.error(response.ReturnMessage)
          }
        },
        error: err => {
          this.submitClicked = false
          this.ngxSpinnerService.hide();
          console.log(err);
          alert("Error from Database:- " + err.message[0])
        }
      });
  }




  UpdateSelectedCount() {
    this.addedPartCount = 0
    for (let item of this.bulkPartSelectorView) {
      this.addedPartCount = parseFloat(this.addedPartCount.toString()) + parseFloat(item.quantity.toString())
    }

  }


  closeReturnOrderPartSelector($event) {
    this.isReturnOrderPartSelector = $event
  }

  saveBulkReturnOrderXml() {
    let rawData = { "rows": [] }
    for (let item of this.finalSelectedParts) {
      rawData.rows.push({
        "row": {
          "BulkReturnOrderDetailGUID": item.BulkReturnOrderDetailGUID == null || item.BulkReturnOrderDetailGUID == undefined ? uuidv4(): item.BulkReturnOrderDetailGUID,
          "IsGSXPosted": "1",
          "PartCode": item.partNumber,
          "SerialNo": item.serialNumber,
          "PartDescription": item.partDescription,
          "ProductDescription": item.productDescription,
          "RepairId": item.repairId,
          "ReturnOrderNumber": item.returnOrderNumber,
          "PurchaseOrderNumber": item.purchaseOrderNumber,
          "BatteryNetWeight": item.batteryNetWeight,
          "Recieved": item.received,
          "ReturnLabelPrinted": item.returnLabelPrinted,
          "OverPackBox": item.CountPack,
          "Isdeleted": item.IsDeleted
        }
      })
    }
    var builder = new xml2js.Builder();
    var xml = builder.buildObject(rawData);
    xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
    xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
    // console.log("xml", xml);
    return xml;
  }

  onBulkReturnOrderType($event: { term: String, items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.BulkReturnType, $event.term, {

    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.BulkReturnDD = value;
        }
      },
      error: (err) => {
        this.BulkReturnDD = this.getBlankObject();
      }
    })
  }

  onTransportationCarrier($event: { term: String, items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.TransportationCarrier, $event.term, {

    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.TransportationCarrier = value;
        }
      },
      error: (err) => {
        this.TransportationCarrier = this.getBlankObject();
      }
    })
  }


  onLocationSearch($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.Location, $event.term, {
      CompanyCode: glob.getCompanyCode().toString()
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.LocationForJob = value;
        }
      },
      error: (err) => {
        this.LocationForJob = DropDownValue.getBlankObject();
      }
    });
  }


  removeItem(item) {
    item.isDeleted = item.isDeleted == 1 ? 0 : 1;
    let index = this.finalSelectedParts.indexOf(item)
    if (item.IsGSXPosted == "1") {
      item.IsDeleted = "1"
    }
    else {
      this.finalSelectedParts.splice(index, 1)
      this.bulkPartSelectorView.splice(index, 1)
    }
    this.UpdateSelectedCount()
  }


  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  printDocument() {
    debugger;
    var objData = { "identifiers":[]  }
      objData.identifiers.push({
        "bulkReturnId":this.bulkReturnId,
        "shipTo": this.Ship_to_GSX
      })
    // debugger
    var documentType = ""

    if(this.printTypeData==undefined || this.printTypeData=="")
    {
      this.toastMessage.error("Select Print Type","Error",{closeButton:true,disableTimeOut:true})
      return;
    }
    // if( this.isShipmentDone == '0' ){
    //   this.toastMessage.error("Shipment is not yet confirmed","Error",{closeButton:true,disableTimeOut:true})
    //   return;
    // }
    if(this.printTypeData=="All-Return-Labels")
    {
        documentType="bulkReturnLabel"
        if(this.finalSelectedParts.length > 1)
        {
          this.fileType="application/zip"
        }
        else
        {
          this.fileType="application/pdf"
        }
    }
    else if(this.printTypeData=="Packing-List")
    {
      documentType="returnsPackingList"
      this.fileType="application/pdf"
    }
    else if(this.printTypeData=="Delivery Challan")
    {
      documentType="downloadBulkReturnDC"
      // TODO:
      this.downloadServiceReport(documentType)
      return
    }

    this.ngxSpinnerService.show()
    
    var strRequestData = JSON.stringify(objData);
      var data = {
        "Content":strRequestData
      };
      this.gsxService.downloadDocument(documentType,data).subscribe(value =>{ 
          debugger;
          this.ngxSpinnerService.hide()
          let response = JSON.parse(value.toString());
          if (!(response.errors == undefined || response.errors == null)) {
            debugger;
            var errorMessage = "";
            for( let iCtr = 0 ; iCtr < response.errors.length ; iCtr++)
            {
                errorMessage =  response.errors[iCtr].code + ' - ' + response.errors[iCtr].message ;
                this.toastMessage.error(errorMessage,"Error",{closeButton:true,disableTimeOut:true})
            }
          }
          else
          {
            debugger;
            const byteArray = new Uint8Array(atob(response.FileContents).split('').map(char => char.charCodeAt(0)));
            var blob = new Blob([byteArray], { type: this.fileType });
            var url = URL.createObjectURL(blob);
            window.open(url);
          }
        },
        err => {
          debugger;
          console.log(err);
          this.toastMessage.error("Please try again. "+ err)
          this.ngxSpinnerService.hide()
  
        }
      );
    }

    downloadServiceReport(reportType: String) {
      this.ngxSpinnerService.show()
      let PdfData = [];
      PdfData.push({
        "Key": "ApiType",
        "Value": "GetBulkReturnOrderObject4Print",
      });
      PdfData.push({
        "Key": "BulkReturnOrderHeaderGUID",
        "Value": this.params.headerguid,
      });
      let pdfRequestData = JSON.stringify(PdfData);
      let contentRequest =
      {
        "content": pdfRequestData
      };
      this.reportService.downloadServiceReport(reportType, contentRequest).subscribe(
        {
          next: (value) => {
            let response = JSON.parse(value.toString());
            const byteArray = new Uint8Array(atob(response.FileContents).split('').map(char => char.charCodeAt(0)));
            var blob = new Blob([byteArray], { type: 'application/pdf' });
            var url = URL.createObjectURL(blob);
            window.open(url);
            this.ngxSpinnerService.hide()
          },
          error: err => {
            console.log(err);
            this.ngxSpinnerService.hide()
          }
        });
    }

  // Key Press Validations
  onKeyPress(event: KeyboardEvent, validationType: string, maxLength: number) {
    const input = event.target as HTMLInputElement;
    const charCode = event.which || event.keyCode;
    const charStr = String.fromCharCode(charCode);

    // When Keypresses should only be integers
    if (validationType === 'int') {
      if (!/^[0-9]*$/.test(charStr)) {
        event.preventDefault();
      }
    } else if (validationType === 'alpha') {
      if (!/^[a-zA-Z]*$/.test(charStr)) {
        event.preventDefault();
      }
    }

    // Max Value of the Key Presses, charCode 8 is for backspaces I guess
    if (input.value.length >= maxLength && charCode !== 8) {
      event.preventDefault();
    }
  }


  isFileUploaded = false;
  // Initialize the file upload list with length as number of files
  FileUploadList=[];
  UploadedFileList= [];
  FinalFileObjects='';
  FinalFileNames ='';
  FinalFileTypes = '';
  
  // Handle file uploads
  UploadFile(event: any, index: number) {
        // Initialize Default for this index
        this.FileUploadList[index] = {
          AttachmentFile: null, // Its of Type blob
          src: null,
          filename: '',
          type: '',
        };

        // console.log("File Data:- ",  (event.target).files);
        // Check if a file is selected
        if(event.target.files.length == 0){
          return
        }
        let fileData = (event.target).files[0];
        // console.log("File Data :- ",fileData);

        // Check if the file is an jpeg,jpg,png  or pdf file
        if( fileData.type.match(/\/jpg|\/jpeg|\/png|\/pdf/) == null ){
          this.toastMessage.error("Please select a jpg, jpeg, png or pdf file type");
          return;
        }
        else if (fileData.size > 2 * 1024 * 1024) {
          this.toastMessage.error("File size should be less than 2MB");
          return;
        }

        // Store the File in the exact index of FileUploadList
        const reader = new FileReader();
        reader.readAsDataURL(fileData);
        // console.log("File Reader:-", reader);
        // console.log("File Blob is:- ",fileData);
        reader.onload = (e) => {
            // Get Files Details
            this.FileUploadList[index].AttachmentFile = fileData;
            this.FileUploadList[index].src = reader.result as string;
            this.FileUploadList[index].filename = fileData.name
            this.FileUploadList[index].type = fileData.type;
            // console.log("File Uploaded List:- ", this.FileUploadList);
      };
  }

  // To view the image at the specified index
  viewImage(file: any, index: number): void {
    // If Image then view else show in new tab:- 
    // if(file.type.includes('image/') ){
    //   this.dialog.open(ImagePopupComponent, {
    //     data: {Imagesrc: file.src}
    //     });
    // }
    // else{
    //   window.open(file.src, '_blank');
    // }
  }
  removeFile(file: any, index: number){
    // Empty the Local List, the Server List and the FinalFileObjects
    this.FileUploadList[index] = {
      AttachmentFile: null, // Its of Type blob/File
      src: null,
      filename: '',
      type: '',
    }
    this.UploadedFileList[index] = { 
      AttachmentFile: null, 
      src: null, 
      filename: '',
      type: ''
    }; 
  }

  // Send to server files and get back their src paths. As server response is slow so subscribe will wait as its an async method
  // so to make the for loop wait while subscribe results an output ie value or error, I have used async and await 
  async sendFilesToServer(){
    // console.log("sendFilesToServer:- ", this.FileUploadList)
    // Warn User If No Files Selected to Upload
    if (this.FileUploadList.some(file =>file.AttachmentFile == null )){
      // const allFilesUploaded = this.FileUploadList.reduce((acc, file) => acc && file.AttachmentFile !== null, true);
      const shouldContinue = confirm("You are not uploading all the "+ this.noOfFilesToUpload + " Files, Do you want to Continue");
      // console.log("Confirm Button Clicked:- ", shouldContinue);
      // if (!allFilesUploaded) return false;
      if(shouldContinue === false) return false ; // stop execution of onSubmit() if sendFilesToServer() returns false
    }
    // debugger
    this.ngxSpinnerService.show();
    // First Empty whole FinalFileObjects 
    this.FinalFileObjects ='';
    this.FinalFileNames ='';
    this.FinalFileTypes = '';

    // Create an array to hold all the observables for file uploads
    const uploadObservables = [];
    debugger
    for (var file_index = 0; file_index < this.FileUploadList.length ; file_index++) {
        // If File exists in the "to be uploaded List" then get src path from server else default values from ngOnInit
        if (this.FileUploadList[file_index].AttachmentFile != null) { //For Sending New Files to Server
          // console.log("File Uploaded List:- ",this.UploadedFileList[file_index].src)
          // Only when file_index has no File in the Server, then send the new file to the server else do nothing
          if (this.UploadedFileList[file_index].src == null) { 
              // Create a new FormData object to Upload it in Server
              let fileToUpload = this.FileUploadList[file_index];
              let formData = new FormData();
              var filename = uuidv4() + "_" + fileToUpload.filename ;
              formData.append('file', fileToUpload.AttachmentFile, filename);

              // using await the for loop waits for the DynamicService's upload to complete
              const result = await lastValueFrom(this.dynamicService.uploadimagefile(formData));
              // Change src in the File Object:- 
              fileToUpload.src =  glob.GLOBALVARIABLE.SERVER_LINK + result['dbPath']              
              // Store the File Object in a String for that first convert it into a FileReader object
              const reader = new FileReader();
              reader.readAsDataURL(fileToUpload.AttachmentFile);
              // As onload is a Async operation which sometimes leads to slow operation
              await new Promise((resolve, reject) => {
                reader.onload = (e) => {
                  this.UploadedFileList[file_index] = {
                    "AttachmentFile": reader.result as string,
                    "src": fileToUpload.src ,
                    "filename": fileToUpload.filename,
                    "type": fileToUpload.type,
                  }
                  // console.log("File Object from Reader inside onload:- ", this.UploadedFileList[file_index]);
                  resolve(e);
                };
               });
              // console.log("index:- ",file_index, "\n The whole File Object:- ", this.UploadedFileList[file_index].AttachmentFile, "\n Actaul File Object:- ", fileToUpload.AttachmentFile);
          }
        }
        // Use Template literal `` instaed of '' and add ? for the condition in Ternary Operator
        // console.log("STRINGIFY FILE OBJECT:- ", JSON.stringify(this.UploadedFileList[file_index].AttachmentFile))
        if (file_index < this.UploadedFileList.length - 1) {
          this.FinalFileObjects += this.UploadedFileList[file_index].src == null || this.UploadedFileList[file_index].src == '' ? `NULL,` : `${JSON.stringify(this.UploadedFileList[file_index].src)},`;
          this.FinalFileNames += this.UploadedFileList[file_index].filename == null || this.UploadedFileList[file_index].filename == '' ? `NULL,` : `${JSON.stringify(this.UploadedFileList[file_index].filename)},`;
          this.FinalFileTypes += this.UploadedFileList[file_index].type == null || this.UploadedFileList[file_index].type == '' ? `NULL,` : `${JSON.stringify(this.UploadedFileList[file_index].type)},`;
        } else {
          // No , in case it's the last index
          this.FinalFileObjects += this.UploadedFileList[file_index].src == null || this.UploadedFileList[file_index].src == '' ? `NULL` : `${JSON.stringify(this.UploadedFileList[file_index].src)}`;
          this.FinalFileNames += this.UploadedFileList[file_index].filename == null || this.UploadedFileList[file_index].filename == '' ? `NULL` : `${JSON.stringify(this.UploadedFileList[file_index].filename)}`;
          this.FinalFileTypes += this.UploadedFileList[file_index].type == null || this.UploadedFileList[file_index].type == '' ? `NULL` : `${JSON.stringify(this.UploadedFileList[file_index].type)}`;
        }        
      }
      this.ngxSpinnerService.hide();
      return true; // for Confirm Box, send true if user wants to continue with fewer files than noOfFilesToUpload
  }

  extractFileSrc(filesrc, filenames, filetypes){
      // Split the String using Regex as normal Split wont work:- 
      const regex = /,(?![^{]*\})/; // Split using , and {}
      if (filenames == null || filenames == undefined ){
        this.toastMessage.error("Invalid Files Uploaded");
        return
      }
      const fileSrcArray = filesrc.split(regex);
      const fileNamesArray = filenames.split(regex);
      const fileTypesArray = filetypes.split(regex)
      // console.log("Files are:- ",fileNamesArray)

    
      fileSrcArray.forEach((file, index) => {
          const src = file !== "NULL" ? file.toString().slice(1, -1) : null;
          // console.log("File Names:- ", index)
          const filename = fileNamesArray[index] != "NULL" ? fileNamesArray[index].toString().slice(1, -1) : '';
          const type = fileTypesArray[index] != "NULL" ? fileTypesArray[index].toString().slice(1, -1) : '';
      
          this.FileUploadList[index] = {
            AttachmentFile: null,
            src: src,
            filename: filename,
            type: type
          };
          this.UploadedFileList[index] = {
            AttachmentFile: null,
            src: src,
            filename: filename,
            type: type
          };
        });
        
    }

  checkLocalPermission() {
    let allPermision = JSON.parse(localStorage.getItem('UserPermission'));
    let resp = allPermision.find(x => x.ProfileId == 14); // 14 is Local Approver
    // console.log("Data", resp)
    
    if(resp?.View == true){
      this.isApproverPermission = true;
      this.showFileUploadOptions= true
      this.fileOptions = false
    }
    return resp != undefined && resp?.View ? true : false;

  }
 
  async ChangeStatus(statusClicked: string){
    // Warn User If No Files Selected to Upload
    if (statusClicked == 'APPROVED' || statusClicked == 'REJECTED'){
      // const allFilesUploaded = this.FileUploadList.reduce((acc, file) => acc && file.AttachmentFile !== null, true);
      const shouldContinue = confirm("Are you sure? ");
      if(shouldContinue === false) return  // stop execution
    }
    // Send Files to the server and get the src path from server and set Status accordingly
    if (this.showFileUploadOptions == true &&  statusClicked == 'SENT FOR APPROVAL'){
       if (await this.sendFilesToServer() === false) {
          this.toastMessage.error("Error in Uploading Files to Server")
          return;
       }
     }
  

    // Get UserName from Local Storage
    let userName = glob.getLogedInUser().UserDetails.UserName;

    // return
    // this.ngxSpinnerService.show();
    let requestData = []
    requestData.push({
      "Key": "ApiType",
      "Value": "SaveBulkApprovalStatus"
    });
    requestData.push({
      "Key": "BulkReturnId",
      "Value": this.bulkReturnId
    });
    requestData.push({
      "Key": "BulkReturnOrderHeaderGUID",
      "Value": this.bulkReturnHeaderGUID
    });
    // Always create a new ApprovalGUID
    requestData.push({
      "Key": "ApprovalGUID",
      "Value": uuidv4() 
    });
    requestData.push({
      "Key": "ApprovalStatus",
      "Value": statusClicked
    });
    requestData.push({
      "Key": "ApprovalRemark",
      "Value": this.returnRemark
    });
    requestData.push({
      "Key": "ApprovalFile",
      "Value": this.FinalFileObjects
    });
    requestData.push({
      "Key": "FileNames",
      "Value": this.FinalFileNames
    });
    requestData.push({
      "Key": "FileTypes",
      "Value": this.FinalFileTypes
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    // console.log("Before BulkApprovalStatus SP:-", this.FinalFileObjects.toString() )
    // console.log("Before names SP:-", this.FinalFileNames )
    // console.log("Before types SP:-", this.FinalFileTypes )
    // // TODO:- 
    // return
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
      next: (value) =>{
        this.ngxSpinnerService.hide()
        let response = JSON.parse(value.toString());
        // console.log("After BulkApprovalStatus SP:- ", response);
        if(response.ReturnCode == '0'){
          this.toastMessage.success("Status Changed Successfully")
          this.route.navigate(['auth/' + glob.getCompanyCode() + '/bulk-return-list'])
        } 
        else{
          this.errorMessage = response.errorMessage
          this.toastMessage.error("Error:- ",this.errorMessage)
        }
      },
      error: (err) =>{
        console.log("Error in Fetching BulkApprovalStatus Data:-  ",err)
      }
    });
  }


}

