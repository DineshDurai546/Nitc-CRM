import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SptonSharedModule } from '../shared/spton-shared.module';
import { MaterialModule } from '../shared/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { NgSelectModule } from '@ng-select/ng-select';

import { BulkReturnOrderComponent } from './bulk-return-order/bulk-return-order.component';
import { BulkReturnListComponent } from './bulk-return-list/bulk-return-list.component';
import { BulkPartSelectorComponent } from './bulk-part-selector/bulk-part-selector.component';
import { DebounceClickDirective } from '../config/debounce-click.directive';
import { RepairPartsApprovalComponent } from './repair-parts-approval/repair-parts-approval.component';


@NgModule({
  declarations: [
    BulkReturnOrderComponent,
    BulkReturnListComponent,
    BulkPartSelectorComponent,
    DebounceClickDirective,
    RepairPartsApprovalComponent,
  ],

  imports: [
    CommonModule,
    MaterialModule,
    SptonSharedModule,
    ReactiveFormsModule,
    FormsModule,
    MatCardModule,
    NgSelectModule,
    NgxSpinnerModule,
    MatSlideToggleModule
  ]
})
export class InventoryModule { }
