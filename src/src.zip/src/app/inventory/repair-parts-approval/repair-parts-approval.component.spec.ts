import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepairPartsApprovalComponent } from './repair-parts-approval.component';

describe('RepairPartsApprovalComponent', () => {
  let component: RepairPartsApprovalComponent;
  let fixture: ComponentFixture<RepairPartsApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepairPartsApprovalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepairPartsApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
