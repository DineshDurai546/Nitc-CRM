import { Component, NgModule, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { GsxService } from 'src/app/common/Services/gsxService/gsx.service';
import * as glob from "../../config/global";
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { Location } from '@angular/common'
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import xml2js from 'xml2js';
import { MatDialog } from '@angular/material/dialog';
import { v4 as uuidv4 } from 'uuid';
import { UUID } from 'uuid';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import { CaseDetail } from 'src/app/transaction/repair-process/repair-process.metadata';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-repair-parts-approval',
  templateUrl: './repair-parts-approval.component.html',
  styleUrls: ['./repair-parts-approval.component.css']
})
export class RepairPartsApprovalComponent implements OnInit {

 
  currentDate: Date;
  CustomerObject: any[] = []
  LocationObject: any[] = []
  typeSelected = 'ball-clip-rotate';

  companyObject: any;
  partList: any[] = [];
  LocationCode: any;
  params: any;
  errorMessage: string;
  CaseGuid: any;
  CaseId: string;
  CustomerCode: any;
  isEdit: boolean = false;
  approverUser: string = '';
  isnotApprover: boolean = true;
  userName: string;
  objCaseDetail: CaseDetail;
  objCaseDetailObServable: Observable<CaseDetail>;
  LocationDD: DropDownValue = DropDownValue.getBlankObject();
  results:any[] = []
  ApprovalStatus : string;
  isApprover: boolean = false;
  RepairDate: Date
  ReturnOrderDate: Date
  submitClicked= false 


  constructor(
    private ngxSpinnerService: NgxSpinnerService,
    private toastMessage: ToastrService,
    private dynamicService: DynamicService,
    private activatedRoute: ActivatedRoute,
    private location: Location,
    public dialog: MatDialog,
    private route: Router,
    private dropdownDataService: DropdownDataService

  ) { }



  ngOnInit(): void {
    this.currentDate = new Date();
    this.params = this.activatedRoute.snapshot.queryParams;

    if (Object.keys(this.params).length == 0) {
      // console.log("Params are ",this.params))
      this.toastMessage.warning("Access Denied")
      this.location.back()
    }
    else{
      if (this.params.caseguid != null || this.params.caseguid != undefined) {
        this.CaseGuid = this.params.caseguid
        this.getRepair()
      }
      else {
        this.toastMessage.error("Repair Parts Not Found")
        this.location.back()
      }

      const allowedParams = ['customercode', 'locationcode', 'caseguid'];

      // Check if any additional parameters are present
      const additionalParams = Object.keys(this.params).filter(param => !allowedParams.includes(param));
      if (additionalParams.length > 0) {
        this.toastMessage.warning("Access Denied");
        this.location.back();
        return;
      }
    }
    // this.getApprovalSettingDetailObject()
    this.onLocationSearch({ term: "", item: [] });

  }

  getCustomerObject() {
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetRtlCustomerObject"
    });
    requestData.push({
      "Key": "CustomerCode",
      "Value": this.CustomerCode
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          try {
            let response = JSON.parse(Value.toString());
            // console.log("Customer Obkect ", response)
            if (response.ReturnCode == '0') {
              let data = JSON.parse(response?.ExtraData);
              if (Array.isArray(data?.Customer)) {
                this.CustomerObject.push(data?.Customer[0])
              }
              else {
                this.CustomerObject.push(data?.Customer)
                this.errorMessage = "";
              }
            }
          } catch (ext) {
          }
        },
        error: err => {
          console.log(err)
        }

      }
    );
  }


  getLocationData() {
    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "GetLocationObject"
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "LocationCode",
      "Value": this.LocationCode
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (value) => {
          let response = JSON.parse(value.toString());
          if (response.ReturnCode == '0') {
            let data = JSON.parse(response.ExtraData)?.Location;
            this.LocationObject.push(data)
          }
          else {
            console.log("error");
          }
        },
        error: err => {
          console.log(err);
        }
      });
  }

  
  onLocationSearch($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.Location, $event.term, {
      CompanyCode: glob.getCompanyCode().toString(),
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.LocationDD = value;
        }
      },
      error: (err) => {
        this.LocationDD = DropDownValue.getBlankObject();
      }
    });
  }

  getRepair() {
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetJobObject"
    });
    requestData.push({
      "Key": "CaseGUID",
      "Value": this.CaseGuid,
    });
    requestData.push({
      "Key": "CompanyCode", 
      "Value": glob.getCompanyCode()
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
        next: (Value) => {
          let response = JSON.parse(Value.toString());
          if (response.ReturnCode == '0') {
            response['ExtraDataJSON'] = JSON.parse(response.ExtraData);
            console.log("Get RepairPartList****************************************", response)
            this.objCaseDetailObServable = response['ExtraDataJSON'];
            this.objCaseDetail = response['ExtraDataJSON'];
            console.log("****************************************",this.objCaseDetail)
            this.CaseId = this.objCaseDetail.CaseId
            this.RepairDate = this.objCaseDetail.CreatedDate
            this.CustomerCode = this.objCaseDetail.RetailCustomerCode
            this.LocationCode = this.objCaseDetail.LocationCode
            this.getCustomerObject()
            this.getLocationData()
            this.checkLocalPermission()
            if ( this.objCaseDetail.RETURNORDER != null || this.objCaseDetail.RETURNORDER != undefined){
              if (Array.isArray(this.objCaseDetail.RETURNORDER.RETURNORDERLIST)) {
                for (let item of this.objCaseDetail.RETURNORDER.RETURNORDERLIST) {
                  this.partList.push(item)
                }
              }
              else {
                this.partList.push(this.objCaseDetail.RETURNORDER.RETURNORDERLIST);
              }
              this.ReturnOrderDate = this.partList[0].CreatedDate
            }
            else{
              this.isEdit = true
              if (Array.isArray(this.objCaseDetail.REPAIR.REPAIRLIST.REPAIRDETAIL)) {
                for (let item of this.objCaseDetail.REPAIR.REPAIRLIST.REPAIRDETAIL) {
                  this.partList.push(item)
                }
              }
              else {
                this.partList.push(this.objCaseDetail.REPAIR.REPAIRLIST.REPAIRDETAIL);
              }
            }
            console.log("PartList ", this.partList)
            // this.objCaseDetail = Object.assign({}, this.objCaseDetail);
          }
        },
        error: err => {
          console.log(err);
        }
      }
    );
  }  

  onSubmit(status){
debugger
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "SaveReturnOrder"
    });  
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "LocationCode",
      "Value": this.objCaseDetail.LocationCode,
    });
    requestData.push({
      "Key": "CaseGuid",
      "Value": this.objCaseDetail.CaseGUID
    });
    requestData.push({
      "Key": "JobStatus",
      "Value": status
    });
    
    requestData.push({
      "Key": "ReturnOrderDetail",
      "Value":  this.ReturnOrderDetailXml()
    });
    console.log("Array Data:",requestData)

    const ShouldContinue = confirm("Are you sure? Do you want to continue")
    if (ShouldContinue == false ){
      return
    }

    if(this.submitClicked == true)
    {
      return;
    }
    this.submitClicked=true 
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.ngxSpinnerService.show()
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
            this.ngxSpinnerService.hide()
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              let data = JSON.parse(response?.ExtraData);
              console.log("Print CaseGuid:",data)
              this.route.navigate(['/auth/' + glob.getCompanyCode() + '/repair-process'], { queryParams: { guid: data.CaseGUID } });
              this.submitClicked= false 
              // this.toastMessage.success("Approved")
            }
            else {
              this.submitClicked= false 
              let errResponse = response['ErrorMessage']
              if (errResponse) {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(errResponse, 'text/xml');
                const errorMessagesList = xmlDoc.getElementsByTagName('errorMessage');
              
                for (let i = 0; i < errorMessagesList.length; i++) {
                  const errorMessageNode = errorMessagesList[i];
                  const errorMessageText = errorMessageNode.querySelector('ErrorMessage').textContent;
                  this.toastMessage.error(`Error: ${errorMessageText}`)
                }
              }                
            }
          },
          error: err => {
            this.ngxSpinnerService.hide()
            this.submitClicked= false 
            console.log("Error Message:- ", err)
            const errors = err.split("Error Code:").slice(1); // Split the error string into separate error segments
            errors.forEach(error => {
              const messageIndex = error.indexOf("Message: ");
              if (messageIndex !== -1) {
                const messageSubstring = error.substring(messageIndex + 9).trim();
                const message = JSON.parse(messageSubstring).message;
                this.toastMessage.error("Error:-  " + message);
              } else {
                this.toastMessage.error("Error parsing the error message.");
              }
            });
        }
        
      }
    );
  }


  ReturnOrderDetailXml(){
    let rawData = {
      "rows": []
    }
    for (let item of this.partList) {
      // console.log("All Component Name:",item)
      rawData.rows.push({
        "row": {
          "ReturnOrderGUID": item.ReturnOrderGUID == null || item.ReturnOrderGUID == undefined ? uuidv4() : item.ReturnOrderGUID,
				  //  "ReturnOrderCode": item.ReturnOrderNumber // TODO
				   "CaseGUID": this.objCaseDetail.CaseGUID ,
				   "CaseId": this.objCaseDetail.CaseId ,
				   "ReturnOrderType": "KBB", 
				   "CompanyCode": glob.getCompanyCode() ,
				   "RepairDetailGUID": item.RepairDetailGUID,
				   "RepairDocCode": this.objCaseDetail.REPAIR.RepairDocCode,
				   "LocationCode": this.objCaseDetail.LocationCode,
				   "ToLocationCode": this.objCaseDetail.LocationCode,
				   "MaterialCode": item.PartCode,
				   "ReturnOrderStatus": item.ReturnOrderStatus == null || item.ReturnOrderStatus == undefined ? "OPEN" : item.ReturnOrderStatus,
				   "SerialNo": this.objCaseDetail.SerialNo1, //TODO
				   "SerializedFlag": item.PartSerialized,
				   "UnitPrice": "0",   //TODO
				   "CostPrice": "0"  //TODO
        }
      })
    }
    console.log("rawData", rawData);
    var builder = new xml2js.Builder();
    var xml = builder.buildObject(rawData);
    xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
    xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
    xml = xml.split(' ').join('')
    console.log("Updated xml", xml);
    return xml;
  }

  


  checkLocalPermission() {
    let allPermision = JSON.parse(localStorage.getItem('UserPermission'));
    console.log("Data", allPermision)
    // TODO
    let resp = allPermision.find(x => x.ProfileId == 5); // 14 is Local Approver
    console.log("Data", resp)
    
    if(resp?.View == true){
      this.isApprover = true;
    }
    return resp != undefined && resp?.View ? true : false;
  }

}