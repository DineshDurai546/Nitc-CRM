import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBusinessPlaceComponent } from './add-business-place.component';

describe('AddBusinessPlaceComponent', () => {
  let component: AddBusinessPlaceComponent;
  let fixture: ComponentFixture<AddBusinessPlaceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddBusinessPlaceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBusinessPlaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
