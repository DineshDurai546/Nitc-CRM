import { Component, OnInit } from '@angular/core';
import { FormGroup,Validator,FormBuilder } from '@angular/forms';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { Location } from '@angular/common';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import {DropDownValue, DropdownDataService,} from "src/app/common/Services/dropdownService/dropdown-data.service";
@Component({
  selector: 'app-add-business-place',
  templateUrl: './add-business-place.component.html',
  styleUrls: ['./add-business-place.component.css']
})
export class AddBusinessPlaceComponent implements OnInit {
  Countries:DropDownValue = this.getBlankObject();
  States: DropDownValue;
  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  addbusinessplaceForm = this.formbuilder.group({
    CompanyCode:[],
    businessplacecode:[],
    businessplacename:[],
    businessplaceaddress1:[],
    businessplaceaddress2:[],
    city:[],
    zipcode:[],
    gstregistrationno:[],
    statecode:[],
    countrycode:[]
  })

  constructor(
    private formbuilder:FormBuilder,
    private dynamicService:DynamicService,
    private location:Location,
    private dropdownDataService:DropdownDataService
  ) { }

  ngOnInit(): void {
  }

  SaveBusinessPlace(){
    let BusinessPlaceRequest=[];
    BusinessPlaceRequest.push({
      "Key":"APIType",
      "Value":"SaveBusinessPlace"
    });
    BusinessPlaceRequest.push({
      "Key":"CompanyCode",
      "Value":this.addbusinessplaceForm.controls["CompanyCode"].value
    });
    BusinessPlaceRequest.push({
      "Key":"BusinessPlaceCode",
      "Value":this.addbusinessplaceForm.controls["businessplacecode"].value
    });
    BusinessPlaceRequest.push({
      "Key":"BUsinessPlaceName",
      "Value":this.addbusinessplaceForm.controls["businessplacename"].value
    });
    BusinessPlaceRequest.push({
      "Key":"Address1",
      "Value":this.addbusinessplaceForm.controls["businessplaceaddress1"].value
    });
    BusinessPlaceRequest.push({
      "Key":"Address2",
      "Value":this.addbusinessplaceForm.controls["businessplaceaddress2"].value
    });
    BusinessPlaceRequest.push({
      "Key":"City",  
      "Value":this.addbusinessplaceForm.controls["city"].value
    });
    BusinessPlaceRequest.push({
      "Key":"ZipCode",
      "Value":this.addbusinessplaceForm.controls["zipcode"].value
    });
    BusinessPlaceRequest.push({
      "Key":"GSTRegistrationNo",
      "Value":this.addbusinessplaceForm.controls["gstregistrationno"].value
    });
    BusinessPlaceRequest.push({
      "Key":"StateCode",
      "Value":"L0001"
    });
    BusinessPlaceRequest.push({
      "Key":"CountryCode",
      "Value":"L0002"
    });
    let BusinessPlaceJson = JSON.stringify(BusinessPlaceRequest);

    let contentRequest={
      "content":BusinessPlaceJson
    }
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
      next:(value)=>{
        this.location.back()
      }
    })
  }
  onCountrySearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.Country, $event.term)
      .subscribe({
        next: (value) => {
          if (value != null) {
            this.Countries = value;
            this.onStatesSearch({ term: "", items: [] });
          }
        },
        error: (err) => {
          this.Countries = this.getBlankObject();
          this.States = this.getBlankObject();
        },
      });
  }
  onStatesSearch(arg0: { term: string; items: undefined[]; }) {
    throw new Error('Method not implemented.');
  }
}
