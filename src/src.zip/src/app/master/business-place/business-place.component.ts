import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as glob from "src/app/config/global";
import { Columns } from 'src/app/models/column.metadata';
import { BehaviorSubject, Observable } from 'rxjs';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { FormGroup,FormBuilder,Validator } from '@angular/forms';
@Component({
  selector: 'app-business-place',
  templateUrl: './business-place.component.html',
  styleUrls: ['./business-place.component.css']
})
export class BusinessPlaceComponent implements OnInit {
  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  actionDetails: any[]=[{"code": "EDIT","icon": "edit","title": "Edit"}];
   columns: Columns[] = [
    {datatype:"STRING",field:"CompanyCode",title:"CompanyCode"},
    {datatype:"STRING",field:"BusinessPlaceCode",title:"businessPlaceCode"},
    {datatype:"STRING",field:"BusinessPlaceName",title:"BusinessPlaceName"},
    {datatype:"STRING",field:"Address1",title:"Address1 "},
    {datatype:"STRING",field:"City",title:"City"},
  ];
  toolBarAction: any[] = [];

  constructor(
    private router:Router,
    private dynamicService:DynamicService,
    private formBuilder:FormBuilder
  ) {
    this.toolBarAction.push({code:"ADD", icon:"add_circle_outline",title:"Add"});
   }

   businessplaceFormList=this.formBuilder.group({
    gstregistrationno:[],
    businessname:[],
   })

  ngOnInit(): void {
 this.GetBusinessPlace()
  }
  AddBusinessPlace(){
    this.router.navigate(['/auth/'+glob.getCompanyCode()+'/add-business-place'])
  }
  actionEmit(event){
    console.log("action Emit", event);
    if(event.action == 'EDIT'){
      this.router.navigate(['/auth/'+glob.getCompanyCode()+'/add-company-master'], { queryParams: { companycode: event.row.CompanyCode, companyname:event.row.CompanyName } })
    }
  }

    GetBusinessPlace(){
      let businessRequest=[];
      businessRequest.push({
        "Key":"APIType",
        "Value":"GetBusinessPlaceList"
      });
      businessRequest.push({
        "Key":"BusinessPlaceCode",
        "Value":""
      })
      businessRequest.push({
        "Key":"CompanyCode",
        "Value":""
      })
      businessRequest.push({
        "Key":"PageNo",
        "Value":"1"
      })
      businessRequest.push({
        "Key":"PageSize",
        "Value":"10"
      })
      let businessJson = JSON.stringify(businessRequest);
      let contentRequest={
        "content":businessJson
      }
      this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
        next:(value)=>{
        let strBusinessData = JSON.parse(value.toString())
      if(strBusinessData.ReturnCode=='0'){
        let data = JSON.parse(strBusinessData?.ExtraData);
        let BusinessPlaceLst=[];
        if(Array.isArray(data?.CompanyCode?.data)){
        BusinessPlaceLst = data?.CompanyCode?.data;
      }
      else{
        BusinessPlaceLst.push(data?.CompanyCode?.data)
      }
      this.detail.next({totalRecord: data?.Totalrecords, Data: BusinessPlaceLst });
    }
        }
      })
    
    }

}
