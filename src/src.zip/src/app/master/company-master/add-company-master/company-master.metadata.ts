import { FormGroup } from "@angular/forms";

export class Company {
    companyForm: FormGroup;                                                                        
    CompanyCode:any
    CompanyName:string
    City:string
    Country: string;
    State: any; 
    Phone2:any;
    TanNo:any;
    DefaultCurrency:any;
    CompanyAddress2:any;
    WebSite:any;
    SAPCompanyCode:any;
    CIN:any;
  }