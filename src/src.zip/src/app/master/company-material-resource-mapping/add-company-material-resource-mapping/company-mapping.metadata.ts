import { FormGroup } from "@angular/forms";

export class CompanyResourceMapping {
    companyMappingForm: FormGroup;                                                                        
    ItemType: String;
    ItemCode: String;
    TAXType: String;
    GSTGroupCode: any;
    UnitPrice: any;
    LocalCurrencyCode: String;
  }