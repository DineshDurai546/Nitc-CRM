import {DropDownValue, DropdownDataService,} from "src/app/common/Services/dropdownService/dropdown-data.service";
import { DynamicService } from "src/app/common/Services/dynamicService/dynamic.service";
import {AbstractControl, FormBuilder,  FormControl,  FormGroup,  Validators,} from "@angular/forms";
import { DropDownType } from "src/app/custom-components/call-login/metadata/request.metadata";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import {  Component,  OnInit,  Input,  SimpleChanges,  Output,  EventEmitter,} from "@angular/core";
import { Customer } from "src/app/custom-components/create-customer/add-customer/CUSTOMER.metadata";
import * as glob from "src/app/config/global";
import { NgxSpinnerService } from "ngx-spinner";
import { emailValidatorService } from "src/app/common/Services/gsxService/email.validator";
import { ToastrService } from "ngx-toastr";
import xml2js from "xml2js";
import { ActivatedRoute, Router } from "@angular/router";
import { Filter } from "src/app/custom-components/call-login-dashboard/filter.meta";

@Component({
  selector: "app-add-customer-master",
  templateUrl: "./add-customer-master.component.html",
  styleUrls: ["./add-customer-master.component.css"],
})
export class AddCustomerMasterComponent implements OnInit {
  PinCode: any;
  date: any;
  @Input() callbackfunction;
  params: any;
  filterList: Filter[] = [];
  stateCodeValidation;
  customerForm: FormGroup;
  customer: Customer;
  errorMessage: String;
  PopUp_Event: boolean = false;
  RetailData: any = [];
  formTitle: string = "Add";
  isEdit: boolean = false;
  RetailsCustomerData: any = [];
  Countries: DropDownValue = this.getBlankObject();
  States: DropDownValue = this.getBlankObject();
  CustAccountGroup: DropDownValue = this.getBlankObject();
  BindStatePincode: DropDownValue = this.getBlankObject();
  GSTRegistration: DropDownValue = this.getBlankObject();
  @Output() AddCustomerData = new EventEmitter<any>();
  @Output() closeAddCustomer = new EventEmitter<any>();
  @Output("search") search: EventEmitter<any> = new EventEmitter();

  constructor(
    private formBuilder: FormBuilder,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private spinner: NgxSpinnerService,
    private emailValidator: emailValidatorService,
    private toastr: ToastrService,
    private route: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  SpninnerChecker() {
    this.spinner.show();
  }
  gstConditionallyRequiredValidator(formControl: AbstractControl) {
    if (!formControl.parent) {
      return null;
    }
    debugger;
    if (formControl.parent.get("DoGST").value) {
      return Validators.required(formControl);
    }
    return null;
  }

  private gstnoValidatorRequired = [
    Validators.maxLength(14),
    Validators.minLength(14),
    Validators.required,
  ];



  private gstnoValidatornotRequired = [
    Validators.maxLength(14),
    Validators.minLength(0),
  ];

  ngOnInit(): void {
    this.params = this.activatedRoute.snapshot.queryParams;
    if (
      this.params.customercode != null ||
      this.params.customercode != undefined
    ) {
      this.getData();
      this.formTitle = "Edit";
      this.isEdit = true;
    }
    this.customer = new Customer();
    this.customerForm = this.formBuilder.group({
      StateCode: [],
      FirstName: [null, Validators.required],
      LastName: [null, Validators.required],
      Address1: [null, Validators.required],
      Address2: [null, Validators.required],
      PhoneNo: [null, [Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
          Validators.pattern("^[0-9]*$"),
        ],
      ],
      AlternateNo: [null],
      EmailId: [null, [Validators.required, Validators.email]],
      Country: [null, Validators.required],
      State: [
        { value: this.customer?.Country == null ? null : this.customer.State },
        Validators.required,
      ],
      City: [null, Validators.required],
      PinCode: [
        null,
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(6),
          Validators.pattern("^[0-9]*$"),
        ],
      ],
      DoGST: [false],
      gstNo: [null, [Validators.minLength(0), Validators.maxLength(15)]],
      CustAccGroup: [null, Validators.required],
      GSTRegistrationType: ["GSTU"],
    });
    this.onCountrySearch({ term: "", items: [] });
    this.onCustAccountGroupSearch({ term: "", items: [] });
    this.onGSTRegistrationSearch({ term: "", items: [] });
    // this.onStateCodeValidation({ term: "", items: [] });
  }

  getData() {
    let requestData = [];
    requestData.push({
      Key: "ApiType",
      Value: "GetRtlCustomerObject",
    });
    requestData.push({
      Key: "CompanyCode",
      Value: glob.getCompanyCode(),
    });
    requestData.push({
      Key: "CustomerCode",
      Value: this.params.customercode,
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      content: strRequestData,
    };

    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
      next: (Value) => {
        let response = JSON.parse(Value.toString());
        if (response.ReturnCode == "0") {
          let data = JSON.parse(response.ExtraData)?.Customer;
          console.log(data);
          this.customerForm.patchValue({
            FirstName: data.FirstName,
            LastName: data.LastName,
            Address1: data.Address1,
            Address2: data.Address2,
            PhoneNo: data.MobileNo,
            AlternateNo: data.PhoneNo,
            EmailId: data.EmailID,
            Country: data.CountryCode,
            State: data.StateCode,
            City: data.City,
            PinCode: data.ZipCode,
            DoGST: data.GST,
            gstNo: data.GSTRegistrationNo,
            CustAccGroup: data.CustAccGroupCode,
            GSTRegistrationType: data.GSTRegistrationType,
          });
        } else {
          console.log("error");
        }
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
  
  returnPrevious()
  {
    this.route.navigateByUrl('/auth/'+glob.getCompanyCode()+'/customer-master')
  }

  onSubmit() {

    const pattern = /^[^\\+\\=@\\-]/;
    const htmlpattern= /[-!$%^&*()_+|~=`{}\[\]:";#@'<>?,.\/]/
    const customerform = this.customerForm.value
    if(!pattern.test(customerform.FirstName.trim()))
    {
      this.toastr.error('Invalid FirstName')
      return;
    }
    if(!pattern.test(customerform.LastName.trim()))
    {
      this.toastr.error('Invalid LastName')
      return;
    }
    if(!pattern.test(customerform.Address1.trim()))
    {
      this.toastr.error('Invalid Address1')
      return;
    }
    if(!pattern.test(customerform.Address2.trim()))
    {
      this.toastr.error('Invalid Address2')
      return;
    }
    if(!pattern.test(customerform.City.trim()))
    {
      this.toastr.error('Invalid City')
      return;
    }


    // HTML PATTERN
    if(htmlpattern.test(customerform.FirstName.trim()))
    {
      this.toastr.error('Invalid FirstName')
      return;
    }  
     if(htmlpattern.test(customerform.LastName.trim()))
    {
      this.toastr.error('Invalid LastName')
      return;
    }
    if(htmlpattern.test(customerform.Address1.trim()))
    {
      this.toastr.error('Invalid Address1')
      return;
    }
    if(htmlpattern.test(customerform.Address2.trim()))
    {
      this.toastr.error('Invalid Address2')
      return;
    }
    if(htmlpattern.test(customerform.City.trim()))
    {
      this.toastr.error('Invalid City')
      return;
    }

    
    console.log(this.params.customercode);
    this.dynamicService.validateAllFormFields(this.customerForm);
    if (this.customerForm.valid) {
      this.errorMessage = "";
      let requestData = [];
      requestData.push({
        Key: "ApiType",
        Value: "SaveRetailCustomer",
      });
      requestData.push({
        Key: "CustAccGroupCode",
        Value: this.customerForm.controls["CustAccGroup"].value,
      });
      requestData.push({
        Key: "CompanyCode",
        Value: glob.getCompanyCode(),
      });
      requestData.push({
        Key: "CustomerCode",
        Value:
          this.params.customercode == undefined ? "" : this.params.customercode,
      });
      requestData.push({
        Key: "FirstName",
        Value: this.customerForm.controls["FirstName"].value,
      });
      requestData.push({
        Key: "LastName",
        Value: this.customerForm.controls["LastName"].value,
      });
      requestData.push({
        Key: "Blocked",
        Value: "0",
      });
      requestData.push({
        Key: "Address1",
        Value: this.customerForm.controls["Address1"].value,
      });
      requestData.push({
        Key: "Address2",
        Value: this.customerForm.controls["Address2"].value,
      });
      requestData.push({
        Key: "CountryCode",
        Value: this.customerForm.controls["Country"].value,
      });
      requestData.push({
        Key: "StateCode",
        Value: this.customerForm.controls["State"].value,
      });
      requestData.push({
        Key: "City",
        Value: this.customerForm.controls["City"].value,
      });
      requestData.push({
        Key: "ZipCode",
        Value: this.customerForm.controls["PinCode"].value,
      });
      requestData.push({
        Key: "MobileNo",
        Value: this.customerForm.controls["PhoneNo"].value,
      });
      requestData.push({
        Key: "PhoneNo",
        Value:
          this.customerForm.controls["AlternateNo"].value == null ||
            this.customerForm.controls["AlternateNo"].value == undefined
            ? ""
            : this.customerForm.controls["AlternateNo"].value,
      });
      requestData.push({
        Key: "EmailID",
        Value: this.customerForm.controls["EmailId"].value,
      });
      requestData.push({
        Key: "TaxType",
        Value: "GST",
      });
      requestData.push({
        Key: "GSTRegistrationNo",
        Value:
          this.customerForm.controls["gstNo"].value == null ||
            this.customerForm.controls["gstNo"].value == undefined
            ? ""
            : this.customerForm.controls["gstNo"].value,
      });
      requestData.push({
        Key: "GSTRegistrationType",
        Value: this.customerForm.controls["GSTRegistrationType"].value,
      });
      requestData.push({
        Key: "DefaultPartnerCode",
        Value: "",
      });
      requestData.push({
        Key: "BillToCustomerCode",
        Value: "",
      });
      requestData.push({
        Key: "PriceGroup",
        Value: this.getPriceGroup(),
      });
      requestData.push({
        Key: "IdentificationDocument",
        Value: "",
      });
      requestData.push({
        Key: "SubmissionType",
        Value: "",
      });
      console.log(requestData);
      let strRequestData = JSON.stringify(requestData);
      console.log(strRequestData);
      let contentRequest = {
        content: strRequestData,
      };
      console.log(contentRequest);
      this.spinner.show();
      this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
        next: (value) => {
          this.spinner.hide();
          console.log("CustomerValue:", value);

          let response = JSON.parse(value.toString());
          if (response.ReturnCode == "0") {
            let data = JSON.parse(response?.ExtraData);
            this.AddCustomerData.emit(data.RetailCustomer);
            var close = false;
            this.closeAddCustomer.emit(close);
            this.toastr.success("Customer Added Successfully");
            this.returnPrevious();
          } else {
            this.spinner.hide();
            this.errorMessage = response.ReturnMessage;
            const parser = new xml2js.Parser({ strict: false, trim: true });
            parser.parseString(response.ErrorMessage, (err, result) => {
              response["errorMessageJson"] = result;
              this.handleError(response);
            });
          }
        },
        error: (err) => {
          this.spinner.hide();
          console.log(err);
        },
      });
    } else {
      console.log("Error in valid");
    }
  }

  getErrorMessage(control: string): string {
    let formControl = this.customerForm.controls[control];
    if (formControl.valid) {
      return "";
    } else {
      console.log(formControl.errors);
      return formControl.errors?.Message;
    }
  }

  handleError(response: any) {
    console.log("handleError form", this.customerForm.controls["PhoneNo"]);

    console.log(response.errorMessageJson.ERRORLIST.ERRORMESSAGE);
    for (let error of response.errorMessageJson.ERRORLIST.ERRORMESSAGE) {
      let controlName = "";
      switch (error.FIELDNAME[0]) {
        case "MobileNo":
          controlName = "PhoneNo";
          break;
        case "EmailId":
          controlName = "EmailId";
          break;
        case "GSTRegistrationNo":
          controlName = "gstNo";
          break;
      }
      this.customerForm.controls[controlName].setErrors({
        Invalid: true,
        Message: error.ERRORMESSAGE[0],
      });
      this.toastr.error(error.ERRORMESSAGE[0], "Error", {
        closeButton: true,
        disableTimeOut: true,
      });
    }
  }

  cancelfunction() {
    this.route.navigate([
      "/auth/" + glob.getCompanyCode() + "/customer-master",
    ]);
  }

  getPriceGroup(): String {
    let value: String = "";
    for (let cust of this.CustAccountGroup.Data) {
      if (cust["ID"] == this.customer.CustomerAccountGroup) {
        value = cust.extraDataJson.Data.$.DefaultPriceGroup;
        break;
      }
    }
    return value;
  }

  onGSTSelect() {
    var gstselect = this.customerForm.get("DoGST").value;
    if (gstselect != true) {
      this.customerForm.controls["gstNo"].disable();
      this.customerForm.controls["GSTRegistrationType"].disable();
      this.customerForm.controls["GSTRegistrationType"].setValue("GSTU");
      this.customerForm
        .get("gstNo")
        .setValidators(this.gstnoValidatornotRequired);
    } else {
      this.customerForm.controls["gstNo"].enable();
      this.customerForm.controls["GSTRegistrationType"].enable();
      var data = { Id: "GRR", TEXT: "GST registered- Regular" };
      this.customerForm.controls["GSTRegistrationType"].setValue("GRR");
      this.customerForm.get("gstNo").setValidators(this.gstnoValidatorRequired);
    }
  }

  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  onCountrySearch($event: { term: string; items: any[] }) {
    this.dropdownDataService
      .fetchDropDownData(DropDownType.Country, $event.term)
      .subscribe({
        next: (value) => {
          if (value != null) {
            this.Countries = value;
            this.States = this.getBlankObject();
            // console.log("Country selected ID are:- " , this.Countries)
            this.onStatesSearch({ term: "", items: [] });
          }
        },
        error: (err) => {
          this.Countries = this.getBlankObject();
          this.States = this.getBlankObject();
          this.customer.Country = null;
          this.customer.State = null;
        },
      });
  }

  onStatesSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService
      .fetchDropDownData(DropDownType.State, $event.term, {
        CountryCode: this.customerForm.controls["Country"].value,
      })
      .subscribe({
        next: (value) => {
          if (value != null) {
            this.States = value;
          }
        },
        error: (err) => {
          this.States = this.getBlankObject();
        },
      });
  }

  onCustAccountGroupSearch($event: { term: string; items: any[] }) {
    console.log($event);
    this.dropdownDataService
      .fetchDropDownData(DropDownType.CustAccountGroup, $event.term, {
        CompanyCode: glob.getCompanyCode().toString(),
      })
      .subscribe({
        next: (value) => {
          if (value != null) {
            this.CustAccountGroup = value;
            console.log(value);
          }
        },
        error: (err) => {
          this.CustAccountGroup = this.getBlankObject();
        },
      });
  }

  onGSTRegistrationSearch($event: { term: string; items: any[] }) {
    console.log($event);
    this.dropdownDataService
      .fetchDropDownData(DropDownType.GSTRegistration, $event.term, {})
      .subscribe({
        next: (value) => {
          if (value != null) {
            this.GSTRegistration = value;
          }
        },
        error: (err) => {
          this.GSTRegistration = this.getBlankObject();
        },
      });
  }

  patchStateCode() {
    if (
      this.customerForm.controls["Pincode"].value.TEXT != undefined ||
      this.customerForm.controls["Pincode"].value.TEXT != null
    ) {
      for (let item of this.stateCodeValidation) {
        if (this.customerForm.controls["Pincode"].value.TEXT == item.TEXT) {
          this.customerForm.patchValue({
            City: item.extraDataJson.Data.CityCode[0],
            StateCode: item.extraDataJson.Data.StateCode[0],
            Country: item.extraDataJson.Data.CountryCode[0],
          });
        }
      }
    }
  }

  // KeyPress Event Handling for change in PinCode Field Value
  onPinCodeChange() {
    this.spinner.show();
    let pinCodeFieldValue = this.customerForm.get("PinCode").value;
    console.log("PinCode Event", pinCodeFieldValue);
    if (!pinCodeFieldValue) {
      console.log("PinCode Value:- ", pinCodeFieldValue);
      this.customerForm.patchValue({
        Country: "",
        City: "",
        State: "",
      });
    } else if (
      this.customerForm.get("PinCode").value.toString().length == "6"
    ) {
      let requestData = [];
      requestData.push({
        key: "APIType",
        Value: "GetPinCodeValidation",
      });
      requestData.push({
        key: "PinCode",
        Value: this.customerForm.value.PinCode,
      });

      let strRequestData = JSON.stringify(requestData);
      let contentRequest = {
        content: strRequestData,
      };
      this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
        next: (value) => {
          try {
            let response = JSON.parse(value.toString());
            if (response.ReturnCode == "0") {
              let data = JSON.parse(response?.ExtraData);
              if (data?.Totalrecords == "1") {
                let results = [];
                this.toastr.success("Pincode Found");
                results.push(data?.PinCodeRow);
                results = data?.PinCodeRow;
                this.customerForm.patchValue({
                  Country: results["CountryCode"],
                  City: results["City"],
                  State: results['StateCode']
                });
                // Calling State service to fill the data in the Dropdown and then Patching with the Id
                this.onStatesSearch({ term: "", items: [] });
                this.customerForm.get("State").patchValue(results["StateCode"]);
              } else {
                this.toastr.error("No such PinCode Found");
                this.customerForm.patchValue({
                  Country: "",
                  City: "",
                  State: "",
                });
              }
              this.spinner.hide();
            }
          } catch (ext) {
            console.log(ext);
          }
        },
        error: (err) => {
          console.log(err);
        },
      });
    }
  }

  DateT() {
    var RemoveT = new Date().toISOString().replace("T", " ");
  }

  validateemail() {
    this.spinner.show();
    var emailid = this.customerForm.controls["EmailId"].value;
    this.emailValidator.validateEmail(emailid).subscribe({
      next: (value: any) => {
        if (value.ReturnValue == true) {
          this.toastr.success("Valid Email Id");
        } else {
          this.customerForm.controls["EmailId"].setErrors({
            Invalid: true,
            Message: "Invalid Email Id",
          });
          this.toastr.error("In-valid Email Id");
        }

        this.spinner.hide();
      },
    });
  }
}