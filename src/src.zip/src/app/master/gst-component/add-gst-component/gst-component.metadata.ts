import { FormGroup } from "@angular/forms";

export class GSTComponent {
    gstComponent: FormGroup;                                                                        
    GSTComponentCode: String;
    ERPGSTComponentCode: String;
    GSTComponentName: String;
    GSTJuridictionType: any;
    CalculationOrder: String;
  }