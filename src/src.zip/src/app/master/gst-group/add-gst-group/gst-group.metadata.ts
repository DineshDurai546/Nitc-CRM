import { FormGroup } from "@angular/forms";

export class GSTGroup {
    gstGroup: FormGroup;                                                                        
    GSTGroupCode: String;
    Description: String;
    HSNSACCode: String;
  }