import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMasterContentComponent } from './add-master-content.component';

describe('AddMasterContentComponent', () => {
  let component: AddMasterContentComponent;
  let fixture: ComponentFixture<AddMasterContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddMasterContentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMasterContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
