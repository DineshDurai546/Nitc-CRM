import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { DropDownValue, DropdownDataService, } from "src/app/common/Services/dropdownService/dropdown-data.service";
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import { ToastrService } from 'ngx-toastr';
import { v4 as uuidv4 } from 'uuid';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-add-master-content',
  templateUrl: './add-master-content.component.html',
  styleUrls: ['./add-master-content.component.css']
})
export class AddMasterContentComponent implements OnInit {
  params: any;
  numrangeType: any = ['E', 'A']
  selectednumrageCode = this.getBlankObject();

  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }
  addmastercontentForm = this.formBuilder.group({
    mastercode: [],
    mastername: [],
    numrangtype: [],
    numrangecode: [],
  })
  constructor(private formBuilder: FormBuilder,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private toastrService: ToastrService,
    private location: Location,
    private activatedRoute: ActivatedRoute,) { }

  ngOnInit(): void {
    this.onNumrangeCodeSearch({ term: '', items: [] });
    this.params = this.activatedRoute.snapshot.queryParams;
    if (this.params.nc != null || this.params.nc != undefined) {
      this.getMasterContent()
      // this.formTitle = "Edit"
      // this.isEdit = true
    }
  }

  getMasterContent(){
    console.log("Mastercontent",this.params.nc)
    let getMasterContent=[];  
  getMasterContent.push({
    "Key":"APIType",
    "Value":"GetMaterContentObject"
});
getMasterContent.push({
  "Key":"MasterContentGUID",
  "Value":this.params.nc
});
console.log("data:",getMasterContent)
let getMasterContentJson = JSON.stringify(getMasterContent);

let contentRequest={
  "content":getMasterContentJson
}

this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
  next:(value)=>{
    console.log("Get Response:",value)
    let response = JSON.parse(value.toString())
    if(response.ReturnCode=='0'){
      let Data = JSON.parse(response?.ExtraData)
      this.addmastercontentForm.patchValue({
        mastercode:Data?.MasterContent.MasterCode,
        mastername:Data?.MasterContent.MasterName,
        numrangtype:Data?.MasterContent.NumrangeType,
        numrangecode:Data?.MasterContent.NumRangeCode,
      })
      console.log("Response Data:",Data)
    }
  }
})

}
  SavematerContent() {
    let MasterContentRequest = [];
    MasterContentRequest.push({
      "Key": "APIType",
      "Value": "SaveMasterContent"
    })
    MasterContentRequest.push({
      "Key": "MasterContentGUID",
      "Value": uuidv4()
    })
    MasterContentRequest.push({
      "Key": "MasterCode",
      "Value": this.addmastercontentForm.controls["mastercode"].value
    })
    MasterContentRequest.push({
      "Key": "MasterName",
      "Value": this.addmastercontentForm.controls["mastername"].value
    })
    MasterContentRequest.push({
      "Key": "IsActive",
      "Value": "1"
    })
    MasterContentRequest.push({
      "Key": "NumrangeType",
      "Value": this.addmastercontentForm.controls["numrangtype"].value
    })
    MasterContentRequest.push({
      "Key": "NumRangeCode",
      "Value": this.addmastercontentForm.controls["numrangecode"].value
    })
    console.log("Array Data", MasterContentRequest);
    let NumrangeData = JSON.stringify(MasterContentRequest);
    let RequestContent = {
      "content": NumrangeData
    }
    this.dynamicService.getDynamicDetaildata(RequestContent).subscribe({
      next: (value) => {
        this.toastrService.success("Add Master Content Successfully");
        this.location.back()
      }
    })
  }
  isActive() {
    console.log()
  }
  onNumrangeCodeSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.numrangecode, $event.term)
      .subscribe({
        next: (value) => {
          if (value != null) {
            this.selectednumrageCode = value;
          }
        },
        error: (err) => {
          this.selectednumrageCode = this.getBlankObject();
        },
      });
  }
  CancelButton() {
    this.location.back()
  }
}
