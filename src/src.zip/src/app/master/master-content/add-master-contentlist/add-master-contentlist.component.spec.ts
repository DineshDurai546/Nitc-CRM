import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMasterContentlistComponent } from './add-master-contentlist.component';

describe('AddMasterContentlistComponent', () => {
  let component: AddMasterContentlistComponent;
  let fixture: ComponentFixture<AddMasterContentlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddMasterContentlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMasterContentlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
