import { Component, OnInit } from '@angular/core';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { ActivatedRoute,Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Location } from '@angular/common';
import * as glob from "src/app/config/global";
import { Columns } from 'src/app/models/column.metadata';
import { BehaviorSubject, combineLatest, of, Subject } from 'rxjs';
@Component({
  selector: 'app-add-master-contentlist',
  templateUrl: './add-master-contentlist.component.html',
  styleUrls: ['./add-master-contentlist.component.css']
})
export class AddMasterContentlistComponent implements OnInit {
  hidemastercontentform:boolean=false;
  isChecked:true;
  StrMasterCode:any;
  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  actionDetails: any[] = [
    { "code": "EDIT", "icon": "edit", "title": "Edit" },];

  constructor(
    private dynamicService: DynamicService,
    private activatedRoute: ActivatedRoute,
    private toastrService:ToastrService,
    private formBuilder: FormBuilder,
    private location:Location,
    private router:Router) { }
    columns: Columns[] = [
      { datatype: "STRING", field: "Code", title: "Code" },
      { datatype: "STRING", field: "MasterCode", title: "MasterCode" },
      { datatype: "STRING", field: "Content", title: "Content" },
      { datatype: "STRING", field: "IsActive", title: "IsActive" },
      
    ];
    params: any;
    addmasterContentList = this.formBuilder.group({
    mastercode: [],
    code: [],
    mastercontet: [],
    isactive: [],

  })
  ngOnInit(): void {
    
    this.params = this.activatedRoute.snapshot.queryParams;
    if (this.params.nc != null || this.params.nc != undefined) {
      this.GetMasterContentList();
      // this.formTitle = "Edit"
      // this.isEdit = true
    }
  }

  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  GetMasterContentList() {
    let requestMasterContentList = [];
    requestMasterContentList.push({
      "APIType": "APIType",
      "Value": "GetMaterContentObject"
    })
    requestMasterContentList.push({
      "APIType": "MasterContentGUID",
      "Value": this.params.nc
    });
    let RequestData = JSON.stringify(requestMasterContentList);

    let contentRequest = {
      "content": RequestData
    }
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
      next: (value) => {
        let Response = JSON.parse(value.toString());
        if (Response.ReturnCode == '0') {
          let data = JSON.parse(Response?.ExtraData);
          this.StrMasterCode = data.MasterContent.MasterCode
          this.GetMasterContenyRecords();
        }
      }
    })

  }

  SaveMasterContentList() {
    let requestcontentlist = [];
    requestcontentlist.push({
      "Key": "APIType",
      "Value": "SaveMasterContentList"
    });
    requestcontentlist.push({
      "Key": "MasterContectGUID",
      "Value": this.params.nc
    });
    requestcontentlist.push({
      "Key": "MasterCode",
      "Value":this.StrMasterCode
    });
    requestcontentlist.push({
      "Key": "Code",
      "Value":  this.addmasterContentList.controls["code"].value
    });
    requestcontentlist.push({
      "Key": "Content",
      "Value": this.addmasterContentList.controls["mastercontet"].value
    });
    requestcontentlist.push({
      "Key": "IsActive",
      "Value":this.isChecked
      // this.addmasterContentList.controls["isactive"].value
    });
    let RequestData = JSON.stringify(requestcontentlist);
    let contentRequest={
      "content":RequestData
    }
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
      next:(value)=>{
        this.toastrService.success("Saved Successfully")
        window.location.reload()
      }
    })
  }

  actionEmit(event) {
    if (event.action == 'EDIT') {
      this.router.navigate(['/auth/'+glob.getCompanyCode()+'/add-master-content'], { queryParams: { cc: event.row.CompanyCode, nc: event.row.MasterContentGUID} })
    }
    if (event.action == 'AddMasterContetList') {
      this.router.navigate(['/auth/'+glob.getCompanyCode()+'/add-master-content-list'], { queryParams: { cc: event.row.MasterCode, nc: event.row.MasterContentGUID} })
    }
  }
  MasterContent(){
    this.hidemastercontentform=true;
  }
  GetMasterContenyRecords(){
    let getMsterList=[];
    getMsterList.push({
      "Key":"APIType",
      "Value":"getSearchMasterContent"
    });
    getMsterList.push({
      "Key":"MasterContectGUID",
      "Value":this.params.nc
    });
    getMsterList.push({
      "Key":"MasterCode",
      "Value":this.StrMasterCode
    });
    console.log("Array Data:",getMsterList)
    let GetMasterJson  = JSON.stringify(getMsterList)

    let mastercontetRequest={
      "content":GetMasterJson
    }
  this.dynamicService.getDynamicDetaildata(mastercontetRequest).subscribe({
    next:(value)=>{
      console.log("Data Bind",value)
      let Response = JSON.parse(value.toString());
    if(Response.ReturnCode=='0'){
      let data = JSON.parse(Response?.ExtraData);
      var mastercontentList=[]
      if(Array.isArray(data?.MasterContect?.data)){
        mastercontentList = data?.MasterContect?.data
        console.log("Data Bind1",mastercontentList)
      }
      else{
        mastercontentList.push(data?.MasterContect?.data)
      }
      this.detail.next({totalRecord: data?.Totalrecords, Data: mastercontentList });
    }
  }

  })

  }
}
