import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as glob from "src/app/config/global";
import { Columns } from 'src/app/models/column.metadata';
import { BehaviorSubject, combineLatest, of, Subject } from 'rxjs';
import { ACTIONENUM } from 'src/app/config/comman.const';


import { ProfileModuleMetaData } from 'src/app/core/models/profilemodule.metadata';
import { CommonService } from 'src/app/core/service/common.service';
import { LoadScriptService } from 'src/app/core/service/load-script.service';
import { ToastrService } from 'ngx-toastr';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service'; 
import { PaginationMetaData } from 'src/app/models/pagination.metadata';
import { GridFormComponent } from 'src/app/nitc-control/grid-form/grid-form.component';
import { SubSink } from 'src/app/shared/sub-sink';

@Component({
  selector: 'app-master-content',
  templateUrl: './master-content.component.html',
  styleUrls: ['./master-content.component.css']
})
export class MasterContentComponent implements OnInit {
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  toolBarAction: any[] = [];
  actionDetails: any[] = [
    { "code": "EDIT", "icon": "edit", "title": "Edit" },
    { "code": "AddMasterContetList", "icon": "add", "title": "Add Master Content List" }
  ];
  columns: Columns[] = [
    { datatype: "STRING", field: "MasterCode", title: "MasterCode" },
    { datatype: "STRING", field: "MasterName", title: "MasterName" },
    { datatype: "STRING", field: "NumrangeType", title: "NumrangeType" },
    { datatype: "STRING", field: "NumRangeCode", title: "NumRangeCode" },
  ];
  ngOnInit(): void {
    this.GetMasterContent();
  }

  constructor( private router:Router,
    private dynamicService:DynamicService){
    this.toolBarAction.push({code:"ADD", icon:"add_circle_outline",title:"Add"});
  }
  AddMasterConetent(){this.router.navigate(['/auth/'+glob.getCompanyCode()+'/add-master-content'])}


  GetMasterContent(){
    let MasterRequestContent=[];
    MasterRequestContent.push({
      "Key":"APIType",
      "Value":"GetMasterContentlist"
    });

    MasterRequestContent.push({
      "Key":"MasterCode",
      "Value":""
    });
    MasterRequestContent.push({
      "Key":"MasterName",
      "Value":""
    });
    MasterRequestContent.push({
      "Key":"PageNO",
      "Value":"1"
    });
    MasterRequestContent.push({
      "Key":"PageSize",
      "Value":"500"
    });
    let RequestContentJson = JSON.stringify(MasterRequestContent);

    let RequestContent={
      "content":RequestContentJson
    }
    this.dynamicService.getDynamicDetaildata(RequestContent).subscribe({
next:(value)=>{
  let response = JSON.parse(value.toString())
  if(response.ReturnCode=='0'){
    let data = JSON.parse(response?.ExtraData);
    console.log("Response Data:",data)
    let results = []
              if(Array.isArray(data?.CompanyList?.data))
              {
                results = data?.CompanyList?.data
              }
              else
              {
                results.push(data?.CompanyList?.data)
              }
              this.detail.next({ totalRecord: data?.Totalrecords, Data: results });}}
            })}

            // actionEmit = (act: any) => {
            //   switch (act.code) {
            //     case ACTIONENUM.ADD:
            //       this.AddMasterConetent();
            //       break;
            //   }
            // }

            actionEmit(event) {
              if (event.action == 'EDIT') {
                this.router.navigate(['/auth/'+glob.getCompanyCode()+'/add-master-content'], { queryParams: { cc: event.row.CompanyCode, nc: event.row.MasterContentGUID} })
              }
              if (event.action == 'AddMasterContetList') {
                this.router.navigate(['/auth/'+glob.getCompanyCode()+'/add-master-content-list'], { queryParams: { cc: event.row.MasterCode, nc: event.row.MasterContentGUID} })
              }
            }
            
            
}
