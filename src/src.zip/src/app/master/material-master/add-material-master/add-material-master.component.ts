import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { DropdownDataService, DropDownValue } from 'src/app/common/Services/dropdownService/dropdown-data.service'
import xml2js from 'xml2js';
import { ActivatedRoute, Router } from '@angular/router';
import * as glob from 'src/app/config/global'
import { Material } from './material-master.metadata';
import { ToastrService } from 'ngx-toastr';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
@Component({
  selector: 'app-add-material-master',
  templateUrl: './add-material-master.component.html',
  styleUrls: ['./add-material-master.component.sass']
})
export class AddMaterialMasterComponent implements OnInit {
  selectedUOM:DropDownValue = this.getBlankObject();
  selectedLaborTier: DropDownValue = this.getBlankObject();
  selectcomponetgroup:DropDownValue = this.getBlankObject();

  ItemType: any[]= [
    {"Id":"Material","TEXT":"Material"},
    {"Id":"Resource","TEXT":"Resource"}
  ]
  constructor(
    private formBuilder: FormBuilder,
    private route: Router,
    private activatedRoute: ActivatedRoute,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private toastMessage: ToastrService
  ) { }
  Serialized = "";
  formTitle: string = "Add"
  isEdit:boolean = false;
  MyFunction_T() {
    this.Serialized;
    let tgl = this.Serialized;
    if (tgl == "") {
      console.log(1)
    }
    else {
      console.log(0)
    }
  }
  params: any;
  materialForm: FormGroup;
  material: Material;
  errorMessage: String;
  PartType: DropDownValue = this.getBlankObject();
  PriceGroup: DropDownValue = this.getBlankObject();
  selectedBaseofMgmt:DropDownValue = this.getBlankObject();



  ngOnInit(): void {
    this.params = this.activatedRoute.snapshot.queryParams;
    if (this.params.nc != null || this.params.nc != undefined) {
      this.getData()
      this.formTitle = "Edit"
      this.isEdit = true
    }
    this.material = new Material();
    this.material.materialForm = this.materialForm;
    this.materialForm = this.formBuilder.group({
      MaterialCode: [null, Validators.required],
      MaterialName: [null, Validators.required],
      MaterialDescription: [null, Validators.required],
      PartType: [null, Validators.required],
      EEECode: [null, Validators.required],
      SubstitutePart: [null, Validators.required],
      ComponentGroup: [null, Validators.required],
      SerializedModule: [null, Validators.required],
      ERPMaterialCode: [null,Validators.required],
      LaborTier: [null, Validators.required],
      PriceGroup: [null, Validators.required],
      DivisionCode: [null, Validators.required],
      BaseUOM: [null, Validators.required],
      SalesUOM: [null, Validators.required],
      ItemType: [null, Validators.required],
      ERPSerialized: [null, Validators.required],
    });
    this.onPartType({ term: '', items: [] })
    this.onPriceGroup({term:'', items:[]})
    this.onLaberTierSerch({term:'', items:[]})
    this.onComponentGroupSerch({term:'', items:[]})
    this.onUnitOfMagermentSerch({term:'', items:[]})
    this.onBaseOfMagermentSerch({term:'', items:[]})
  }

  slideval = false
  islideval2=false
  public newslide(event: any): void {
    if (event.checked) {
      console.log('true')
    } else {
      console.log('false')
    }
  }

  getData() {
    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "GetMaterialObject"
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": this.params.cc
    });
    requestData.push({
      "Key": "MaterialCode",
      "Value": this.params.nc
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          let response = JSON.parse(Value.toString());
          if (response.ReturnCode == '0') {
            let data = JSON.parse(response.ExtraData)?.Material;
            console.log("edit material data:",data)
            this.materialForm.patchValue({
              MaterialCode: data.MaterialCode,
              LaborTier:data.LaborTier,
              MaterialName: data.MaterialName,
              MaterialDescription: data.MaterialDescription,
              EEECode: data.EEECode,
              SubstitutePart: data.SubstitutePart,
              ComponentGroup: data.ComponentGroup,
              SerializedModule: data.SerializedModule,
              ERPMaterialCode: data.ERPMaterialCode,
              PriceGroup: data.PriceGroup,
              PartType: data.PartType,
              DivisionCode:data.DivisionCode,
              BaseUOM:data.BaseUOM,
              SalesUOM:data.BaseUOM,
              ItemType:data.ItemType,
              ERPSerialized:data.ERPSerialized
            })}
          else {
            console.log("error");
          }
        },
        error: err => {
          console.log(err);
        }
      });
  }

  controlValidations() {
    Object.keys(this.materialForm.controls).forEach(field => {
        let controlValue = this.materialForm.get(field).value
        if (controlValue == null || controlValue == undefined) {
          this.materialForm.get(field).setErrors({incorrect:true})
          this.toastMessage.error(field + " Cannot be Empty")
        }
    })
  }
  
  returnPrevious()
  {
    this.route.navigateByUrl('/auth/'+glob.getCompanyCode()+'/material-master')
  }

  onSubmit() {
    this.dynamicService.validateAllFormFields(this.materialForm);
    if (this.materialForm.valid) {
      this.errorMessage = "";
    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "SaveMaterialMaster"
    });
    requestData.push({
      "Key": "MaterialCode",
      "Value": this.material.MaterialCode
    });
    requestData.push({
      "Key": "MaterialDescription",
      "Value": this.material.MaterialDescription
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": glob.getCompanyCode()
    });
    requestData.push({
      "Key": "MaterialName",
      "Value": this.material.MaterialName
    });
    requestData.push({
      "Key": "PartType",
      "Value": this.materialForm.controls["PartType"].value
    });
    requestData.push({
      "Key": "LaborTier",
      "Value": this.materialForm.controls["LaborTier"].value
    });
    requestData.push({
      "Key": "EEECode",
      "Value": this.material.EEECode
    });
    requestData.push({
      "Key": "SubstitutePart",
      "Value": this.material.SubstitutePart
    });
    requestData.push({
      "Key": "ComponentGroup",
      "Value": this.materialForm.controls["ComponentGroup"].value
    });
    requestData.push({
      "Key": "SerializedModule",
      "Value": this.material.SerializedModule
    });
    requestData.push({
      "Key": "ERPMaterialCode",
      "Value": this.material.ERPMaterialCode
    });
    requestData.push({
      "Key":"PriceGroup",
      "Value": this.materialForm.controls["PriceGroup"].value
    })
    requestData.push({
      "Key": "DivisionCode",
      "Value": this.material.DivisionCode
    });
    requestData.push({
      "Key": "BaseUOM",
      "Value": this.material.BaseUOM
    });
    requestData.push({
      "Key": "SalesUOM",
      "Value": this.material.SalesUOM
    });
    requestData.push({
      "Key": "ItemType",
      "Value": this.materialForm.controls["ItemType"].value
    });
    requestData.push({
      "Key": "ERPSerialized",
      "Value": this.material.ERPSerialized
    });
    console.log("Array Data:",requestData)
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    console.log(contentRequest);
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          let response = JSON.parse(Value.toString());
          if (response.ReturnCode == '0') {
            this.toastMessage.success("Form Submitted Successfully");
            this.returnPrevious()
          }
          else {
            this.errorMessage = response.ReturnMessage;
            const parser = new xml2js.Parser({ strict: false, trim: true });
            parser.parseString(response.ErrorMessage, (err, result) => {
              response['errorMessageJson'] = result;
              this.handleError(response);
            });
          }

        },
        error: err => {
          console.log(err);
          if (err.includes('"message":"Cannot')) {
            this.controlValidations()
          }
        }
      });
    } else {
      console.log("Error in valid");
    }
  }

  getErrorMessage(control: string): string {
    let formControl = this.materialForm.controls[control];
    if (formControl.valid) {
      return "";
    } else {
      console.log(formControl.errors);
      return formControl.errors?.Message;
    }
  }

  handleError(response: any) {
    let errror = response.errorMessageJson.ERRORLIST.ERRORMESSAGE[0]["ERRORMESSAGE"]
    console.log(errror)
    var validationErrorMessage = errror[0]
    console.log(validationErrorMessage)
  }

  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  onPartType($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.PartType, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.PartType = value;
        }
      },
      error: (err) => {
        this.PartType = this.getBlankObject();
      }
    });
  }

  onPriceGroup($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.MatPriceGroup, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.PriceGroup = value;
        }
      },
      error: (err) => {
        this.PriceGroup = this.getBlankObject();
      }
    });
  }

  onComponentGroup($event) {
    console.log($event);
    this.material.ComponentGroup = $event.TEXT;
  }
  onLaborTier($event) {
    console.log($event);
    this.material.LaborTier = $event.TEXT; }

    // onItemTypeSelect($event){
    //   if(this.companyMappingForm.controls["ItemType"].value=="Material")
    //   {
    //     this.onMaterialItemCode({ term:"", items:[] })
    //   }
    //   else
    //   {
    //     this.onResourceItemCode( {term:"", items:[] })
    //   }
    // }

    onLaberTierSerch($event: { term: string; items: any[] }) {
      this.dropdownDataService.fetchDropDownData(DropDownType.labortier, $event.term, {
      }).subscribe({
        next: (value) => {
          if (value != null) {
            this.selectedLaborTier = value;
          }
        },
        error: (err) => {
          this.selectedLaborTier = this.getBlankObject();
        }
      });
    }
    onComponentGroupSerch($event: { term: string; items: any[] }) {
      this.dropdownDataService.fetchDropDownData(DropDownType.componentgroup, $event.term, {
      }).subscribe({
        next: (value) => {
          if (value != null) {
            this.selectcomponetgroup = value;
          }
        },
        error: (err) => {
          this.selectcomponetgroup = this.getBlankObject();
        }
      });
    }

    onUnitOfMagermentSerch($event: { term: string; items: any[] }) {
      this.dropdownDataService.fetchDropDownData(DropDownType.unitofmagerment, $event.term, {
      }).subscribe({
        next: (value) => {
          if (value != null) {
            this.selectedUOM = value;
          }
        },
        error: (err) => {
          this.selectedUOM = this.getBlankObject();
        }
      });
    }
    onBaseOfMagermentSerch($event: { term: string; items: any[] }) {
      this.dropdownDataService.fetchDropDownData(DropDownType.unitofmagerment, $event.term, {
      }).subscribe({
        next: (value) => {
          if (value != null) {
            this.selectedBaseofMgmt = value;
          }
        },
        error: (err) => {
          this.selectedBaseofMgmt = this.getBlankObject();
        }
      });
    }
}
