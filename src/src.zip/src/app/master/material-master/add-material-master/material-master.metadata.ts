import { FormGroup } from "@angular/forms";

export class Material {
    materialForm: FormGroup;                                                                        
    MaterialCode: String;
    MaterialName: String;
    MaterialDescription: String;
    PartType: any;
    LaborTier: any;
    EEECode: String;
    MarginPercentage: number;
    SubstitutePart: String;
    ComponentGroup: any;
    SerializedModule: boolean;
    ERPMaterialCode: String;
    GSTRegistration: any;
    DivisionCode:any;
    BaseUOM:any;
    SalesUOM:any;
    ItemType:any;
    ERPSerialized:any;
  }