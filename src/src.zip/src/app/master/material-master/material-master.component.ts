import { Component, OnInit,Input } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { ACTIONENUM } from 'src/app/config/comman.const';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { Columns } from 'src/app/models/column.metadata';
import { PaginationMetaData } from 'src/app/models/pagination.metadata';
import * as glob from "src/app/config/global"
import { NgxSpinnerService } from 'ngx-spinner';
import { Filter } from 'src/app/custom-components/call-login-dashboard/filter.meta' 
import { Observable } from 'rxjs/internal/Observable';


@Component({
  selector: 'app-material-master',
  templateUrl: './material-master.component.html',
  styleUrls: ['./material-master.component.sass']
})
export class MaterialMasterComponent implements OnInit {

  filterList: Filter[] = [];
  erpMaterialCode: string = '';
  materialCode: string = '';
  materialName: string = '';
  eeeCode: string = '';
  searchForm: FormGroup;
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  @Input() filters: Observable<Filter[]>;
  columns: Columns[] = [
    {datatype:"STRING",field:"MaterialCode",title:"Material Code"},
    {datatype:"STRING",field:"MaterialName",title:"Material Name"},
    {datatype:"STRING",field:"MaterialDescription",title:"Material Description"},
    {datatype:"STRING",field:"PartType",title:"Part Type"},
    {datatype:"STRING",field:"LaborTier",title:"Labor Tier"},
    {datatype:"STRING",field:"EEECode",title:"EEE Code"},
    {datatype:"STRING",field:"ComponentGroup",title:"Component Group "},
    {datatype:"STRING",field:"SubstitutePart",title:"Substitute Part"},
    {datatype:"STRING",field:"SerializedModule",title:"Serialized Module"},
    {datatype:"STRING",field:"ERPMaterialCode",title:"ERPMaterial Code"},
    {datatype:"STRING", field:"PriceGroup", title:"Price Group"}
  ];
  toolBarAction: any[] = [];
  breadCumbList: any[];
  actionDetails: any[]=[
    {"code": "EDIT","icon": "edit","title": "Edit"}
  ];
  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  isChoose: boolean = false;
  editNumRangeForm:FormGroup;
  jobPagination: PaginationMetaData;
  screenDetail: any;
  screen:any;

  constructor(
    private dynamicService: DynamicService,
    private route: Router,    
    private ngxservice: NgxSpinnerService,
  ) { 
    this.jobPagination = new PaginationMetaData();
    this.toolBarAction.push({code:"ADD", icon:"add_circle_outline",title:"Add"});
    
  }

  ngOnInit(): void {
    this.GetMaterialList('', '', '', '');    
  }

  search() {
    this.GetMaterialList(this.materialCode, this.materialName, this.eeeCode, this.erpMaterialCode);
  }

  GetMaterialList(materialcode, materialname, eeecode, erpmaterialcode) {
    this.ngxservice.show();
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetMaterialList"
    });
    requestData.push({
      "Key": "MaterialName",
      "Value": materialname
    });
    requestData.push({
      "Key": "MateriaLCode",
      "Value": materialcode
    });
    requestData.push({
      "Key": "EEECode",
      "Value": eeecode
    });
    requestData.push({
      "Key": "ERPMaterialCode",
      "Value": erpmaterialcode
    });
    
    requestData.push({
      "Key": "PageNo",
      "Value": "1"
    });
    requestData.push({
      "Key": "PageSize",
      "Value": "10"
    });
    for (let filter of this.filterList ?? []) {
      requestData.push({
        "Key": filter.type,
        "Value": filter.value
      });
    }
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          try {
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              let data = JSON.parse(response?.ExtraData);
              let results = []
              if(Array.isArray(data?.MaterialList?.Material))
              {
                results = data?.MaterialList?.Material
              }
              else
              {
                results.push(data?.MaterialList?.Material)
              }
              this.detail.next({ totalRecord: data?.Totalrecords, Data: results });
              this.ngxservice.hide()
            }
          } catch (ext) {
            console.log(ext);
          }
        },
        error: err => {
          console.log(err);
        }
      }
    );
  }



  actionEvent = (act: any) => {
    switch (act.code) {
      case ACTIONENUM.ADD:
        this.add();
        break;
    }
  }

  add(){
    this.route.navigate(['/auth/'+glob.getCompanyCode()+'/add-material-master']);
  }

  actionEmit(event){
    console.log("action Emit", event);
    if(event.action == 'EDIT'){
      this.route.navigate(['/auth/'+glob.getCompanyCode()+'/add-material-master'], { queryParams: { cc: event.row.CompanyCode, nc:event.row.MaterialCode } })
    }
  }

  loadPageData(event){
    switch(event.eventType){
      case "PageChange":
        this.jobPagination.PageNumber  = event.eventDetail.pageIndex + 1;
        let requestData =[];

        requestData.push({
          "Key":"APIType",
          "Value": "GetMaterialList"
        });
        requestData.push({
          "Key":"CompanyCode",
          "Value": "NITC"
        });
        requestData.push({
          "Key":"PageNo",
          "Value": event.eventDetail.pageIndex + 1 
        });
        requestData.push({
          "Key":"PageSize",
          "Value": event.eventDetail.pageSize
        });

        let strRequestData = JSON.stringify(requestData);
        let contentRequest =
        {
          "content" : strRequestData
        };    
        this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
          {
            next : (Value) =>
            {
              try{
                let response = JSON.parse(Value.toString());
                if(response.ReturnCode =='0')
                {
                  let data = JSON.parse(response?.ExtraData);
                  this.detail.next({totalRecord:data?.Totalrecords , Data: data?.MaterialList?.Material });
                }
              }catch(ext){
                console.log(ext);
              }
            },
            error : err =>
            {
              console.log(err);
            }
          }
        );
        break;
    }  
    setTimeout(()=>{  this.hideSpinnerEvent.next(); }, 1);
  }

}
