import { FormGroup } from "@angular/forms";

export class OrgRole {
    orgRoleForm: FormGroup;                                                                        
    orgRoleName: String;
    orgRoleDescription: String;
  }