import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPriceListDetailComponent } from './add-price-list-detail.component';

describe('AddPriceListDetailComponent', () => {
  let component: AddPriceListDetailComponent;
  let fixture: ComponentFixture<AddPriceListDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddPriceListDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPriceListDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
