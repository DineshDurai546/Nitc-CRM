import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { DropdownDataService, DropDownValue } from 'src/app/common/Services/dropdownService/dropdown-data.service'
import xml2js from 'xml2js';
import { ActivatedRoute, Router } from '@angular/router';
import { pricelist } from '../price-list-detail.metadata'; 
import { ToastrService } from 'ngx-toastr';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import * as glob from 'src/app/config/global'
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-add-price-list-detail',
  templateUrl: './add-price-list-detail.component.html',
  styleUrls: ['./add-price-list-detail.component.sass']
})
export class AddPriceListDetailComponent implements OnInit

 {


  constructor(
    private formBuilder: FormBuilder,
    private route : Router,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private activatedRoute: ActivatedRoute,
    private toastMessage: ToastrService
  ) { }

  pricelistForm: FormGroup;
  params:any;
  isEdit:boolean = false;
  pricelist: pricelist;
  formTitle: string = "Add"
  errorMessage: String;
  LocationPriceGroup: DropDownValue = this.getBlankObject();
  MaterialPriceGroup: DropDownValue = this.getBlankObject();
  pricelist1:any;

  ngOnInit(): void {
    this.params = this.activatedRoute.snapshot.queryParams;
    this.params = this.activatedRoute.snapshot.queryParams;
    if (this.params.nc != null || this.params.nc != undefined) {
      this.getData()
      this.formTitle = "Edit"
      this.isEdit = true
    }
    this.pricelist = new pricelist();
    this.pricelistForm = this.formBuilder.group({
      CompanyCode: [null, Validators.required],
      LocationPriceGroup: [null, Validators.required],
      MaterialPriceGroup: [null, Validators.required],
      CustomerPriceGroup: [null, Validators.required],
      PricingOption: [null, Validators.required],
      ProductCategory: [null, Validators.required],
      EffectiveDate:[null, Validators.required],
      PriceRangeApplicable:[null, Validators.required],
      PriceRangeStart:[null, Validators.required],
      PriceRangeEnd:[null, Validators.required],
      MarginType:[null, Validators.required],
      Margin:[null, Validators.required],
      UnitPrice:[null, Validators.required],
      CurrencyCode:[null, Validators.required],

    });
    this.pricelist.pricelistForm = this.pricelistForm;
    this.onlocationPriceGroup({ term: '', items: [] })
    this.onMaterialPriceGroup({ term: '', items: [] })
  }

  controlValidations() {
    Object.keys(this.pricelistForm.controls).forEach(field => {
      let controlValue = this.pricelistForm.get(field).value
      if (controlValue == null || controlValue == undefined) {
        this.toastMessage.error(field + " Cannot be Empty")
      }
    })
  }

  getData(){ 
    let params = this.activatedRoute.snapshot.queryParams;
    let requestData= [];

    requestData.push({
      "Key":"ApiType",
      "Value": "GetPricelistObject"
    });

    requestData.push({
      "Key": "PriceListGUID",
      "Value":params.nc
    });
    console.log('*******',requestData)
    
    

    let strRequestData = JSON.stringify(requestData);
      let contentRequest = {
        "content": strRequestData
      };

      this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
        {
          next :(value) => {
            let response = JSON.parse(value.toString());
            console.log('*****RESPO',response)
            
            if(response.ReturnCode =='0')
            {
              let data = JSON.parse(response.ExtraData)?.TestPriceListObject;
              console.log('******',data)
    
              this.pricelistForm.patchValue({
                CompanyCode : data.CompanyCode, 
                LocationPriceGroup :data.LocationPriceGroup,
                MaterialPriceGroup : data.MaterialPriceGroup,
                CustomerPriceGroup : data.CustomerPriceGroup,
                PricingOption: data.PricingOption,
                ProductCategory:data.ProductCategory,
                EffectiveDate:data.EffectiveDate,
                PriceRangeApplicable:data.PriceRangeApplicable,
                PriceRangeStart:data.PriceRangeStart,
                PriceRangeEnd:data.PriceRangeEnd,
                Margin:data.Margin,
                MarginType:data.MarginType,
                UnitPrice:data.UnitPrice,
                CurrencyCode:data.CurrencyCode,
               })
                         
            }
            else{
              console.log("error");
            }
  
          },
          error :err =>{
            console.log(err);
          }
          });
  }

  returnPrevious()
  {
    this.route.navigateByUrl('/auth/'+glob.getCompanyCode()+'/price-list-detail')
  }

  onSubmit() {
    this.controlValidations();
    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "SavePriceListMaster"
    });
    requestData.push({
      "Key": "PriceListGUID",
      "Value": uuidv4()
    });
    requestData.push({
      "Key": "CompanyCode",
      "Value": this.pricelistForm.controls["CompanyCode"].value
    });
    requestData.push({
      "Key": "LocationPriceGroup",
      "Value": this.pricelistForm.controls["LocationPriceGroup"].value
    });
    requestData.push({
      "Key": "MaterialPriceGroup",
      "Value": this.pricelistForm.controls["MaterialPriceGroup"].value
    });
    requestData.push({
      "Key": "CustomerPriceGroup",
      "Value": this.pricelistForm.controls["CustomerPriceGroup"].value
    });
    requestData.push({
      "Key": "PricingOption",
      "Value": this.pricelistForm.controls["PricingOption"].value
    })
    requestData.push({
      "Key": "ProductCategory",
      "Value": this.pricelistForm.controls["ProductCategory"].value
    })
    requestData.push({
      "Key": "EffectiveDate",
      "Value": this.pricelistForm.controls["EffectiveDate"].value
    })
    requestData.push({
      "Key": "PriceRangeApplicable",
      "Value": this.pricelistForm.controls["PriceRangeApplicable"].value
    })
    requestData.push({
      "Key": "PriceRangeStart",
      "Value": this.pricelistForm.controls["PriceRangeStart"].value
    })
    requestData.push({
      "Key": "PriceRangeEnd",
      "Value": this.pricelistForm.controls["PriceRangeEnd"].value
    })
    requestData.push({
      "Key": "MarginType",
      "Value": this.pricelistForm.controls["MarginType"].value
    })
    requestData.push({
      "Key": "Margin",
      "Value": this.pricelistForm.controls["Margin"].value
    })
    requestData.push({
      "Key": "UnitPrice",
      "Value": this.pricelistForm.controls["UnitPrice"].value
    })
    requestData.push({
      "Key": "CurrencyCode",
      "Value": this.pricelistForm.controls["CurrencyCode"].value
    })
    console.log(" Array Data",requestData)


    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    }; 
    console.log("Array Data:",contentRequest)
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (value) => {
          console.log("VALUE",value)
          let response = JSON.parse(value.toString());
          console.log("*******R",response)
          if (response.ReturnCode == '0') {
            this.toastMessage.success("Form Submitted Successfully");
            this.returnPrevious()
          }
          else {
            this.errorMessage = response.ReturnMessage;
            const parser = new xml2js.Parser({ strict: false, trim: true });
            parser.parseString(response.ErrorMessage, (err, result) => {
              response['errorMessageJson'] = result;
              this.handleError(response);
            });
          }

        },
        error: err => {
          if (err.includes('"message":"Cannot')) {
            // this.controlValidations()
          }
        }
      });
  }

  getErrorMessage(control: string): string {
    let formControl = this.pricelistForm.controls[control];
    if (formControl.valid) {
      return "";
    } else {
      return formControl.errors?.Message;
    }
  }

  handleError(response: any) {
    let errror = response.errorMessageJson.ERRORLIST.ERRORMESSAGE[0]["ERRORMESSAGE"]
    console.log(errror)
  }

  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  onMaterialPriceGroup($event: { term: String, items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.ProductCategory, $event.term, {

    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.pricelist1 = value;
        }
      },
      error: (err) => {
        this.pricelist1 = this.getBlankObject();
      }
    })
  }

  onlocationPriceGroup($event: { term: string; items: any[] }) {

    this.dropdownDataService.fetchDropDownData(DropDownType.LocationPriceGroup, $event.term, {

    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.pricelist1 = value;
        }
      },
      error: (err) => {
        this.pricelist1 = this.getBlankObject();
      }
    });
  }


}
