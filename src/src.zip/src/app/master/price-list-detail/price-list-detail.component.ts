import { Component, OnInit,Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { ACTIONENUM } from 'src/app/config/comman.const';
import { Columns } from 'src/app/models/column.metadata';
import { Filter } from 'src/app/custom-components/call-login-dashboard/filter.meta' 
import { PaginationMetaData } from 'src/app/models/pagination.metadata';
import * as glob from "src/app/config/global"
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-price-list-detail',
  templateUrl: './price-list-detail.component.html',
  styleUrls: ['./price-list-detail.component.sass']
})
export class PriceListDetailComponent implements OnInit {

  filterList: Filter[] = [];
  MaterialPriceGroup: string = '';
  PricingOption: string = '';
  MasterPriceGroup: string = '';
  CustomerPriceGroup: string = '';
  searchForm: FormGroup;
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  @Input() filters: Observable<Filter[]>;

  columns: Columns[] = [
    { datatype: "STRING", field: "CompanyCode", title: "Company Code" },
    { datatype: "STRING", field: "LocationPriceGroup", title: "Location Price Group" },
    { datatype: "STRING", field: "MaterialPriceGroup", title: "Material Price Group" },
    { datatype: "STRING", field: "CustomerPriceGroup", title: "Customer Prize Group" },
    { datatype: "STRING", field: "PricingOption", title: "Pricing Option" },
    
  ];
  
  toolBarAction: any[] = [];
  breadCumbList: any[];
  actionDetails: any[] = [
    { "code": "EDIT", "icon": "edit", "title": "Edit" }
  ];

  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  isChoose: boolean = false;
  editNumRangeForm: FormGroup;
  jobPagination: PaginationMetaData;
  constructor(
    private dynamicService: DynamicService,
    private ngxservice: NgxSpinnerService,
    private route: Router,
  ) {
    this.jobPagination = new PaginationMetaData();
    this.toolBarAction.push({ code: "ADD", icon: "add_circle_outline", title: "Add" });
  }

  ngOnInit(): void {
    this.GetPriceListDetails('', '');
  }


  actionEvent = (act: any) => {
    switch (act.code) {
      case ACTIONENUM.ADD:
        this.add();
        break;
    }
  }

  add() {
    this.route.navigate(['/auth/'+glob.getCompanyCode()+'/add-price-list-detail']);
  }

  actionEmit(event) {
    if (event.action == 'EDIT') {
      this.route.navigate(['/auth/'+glob.getCompanyCode()+'/add-price-list-detail'], { queryParams: {  nc: event.row.PriceListGUID } })
    }
  }

  search() {
    this.GetPriceListDetails (this.MaterialPriceGroup, this.PricingOption);
  }

  GetPriceListDetails(MaterialPriceGroup, PricingOption, ) {
    this.ngxservice.show();
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetPriceListDetails"
    });
    requestData.push({
      "Key": "MaterialPriceGroup",
      "Value": MaterialPriceGroup
    });
    requestData.push({
      "Key": "PricingOption",
      "Value": PricingOption
    });
   
    requestData.push({
      "Key": "PageNo",
      "Value": "1"
    });
    requestData.push({
      "Key": "PageSize",
      "Value": "10"
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          try {
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              
              let data = JSON.parse(response?.ExtraData);
             
              let results = []
              if(Array.isArray(data?.PriceList?.PriceListRow))
              {
                results = data?.PriceList?.PriceListRow
              }
              else
              {
                results.push(data?.PriceList?.PriceListRow)
              }
              this.detail.next({ totalRecord: data?.Totalrecords, Data: results });
              this.ngxservice.hide()
            }
          } catch (ext) {
            console.log(ext);
          }
        },
        error: err => {
          console.log(err);
        }
      }
    );
  }

  loadPageData(event) {
    switch (event.eventType) {
      case "PageChange":
        this.jobPagination.PageNumber = event.eventDetail.pageIndex + 1;
        let requestData = [];

        requestData.push({
          "Key": "APIType",
          "Value": "GetPriceListDetails"
        });
        
        requestData.push({
          "Key": "PageNo",
          "Value": event.eventDetail.pageIndex + 1
        });
        requestData.push({
          "Key": "PageSize",
          "Value": event.eventDetail.pageSize
        });

        let strRequestData = JSON.stringify(requestData);
        let contentRequest =
        {
          "content": strRequestData
        };
        this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
          {
            next: (Value) => {
              try {
                let response = JSON.parse(Value.toString());
                if (response.ReturnCode == '0') {
                  let data = JSON.parse(response?.ExtraData);
                  this.detail.next({ totalRecord: data?.Totalrecords, Data: data?.PriceList?.PriceListRow });
                }
              } catch (ext) {
                console.log(ext);
              }
            },
            error: err => {
              console.log(err);
            }
          }
        );
        break;
    }
    setTimeout(() => { this.hideSpinnerEvent.next(); }, 1);
  }

}


 
