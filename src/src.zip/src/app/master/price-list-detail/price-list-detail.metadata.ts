import { FormGroup } from "@angular/forms";

export class pricelist {
    
    pricelistForm: FormGroup;                                                                        
    CompanyCode: String;
    LocationPriceGroup:String;
    MaterialPriceGroup: String;
    CustomerPriceGroup: String;
    PricingOption: any;
    ProductCategory:String;
    EffectiveDate:String;
    PriceRangeApplicable:any;
    PriceRangeStart:any;
    PriceRangeEnd:any;
    MarginType:any;
    Margin:any;
    UnitPrice:any;
   CurrencyCode:any;
 }