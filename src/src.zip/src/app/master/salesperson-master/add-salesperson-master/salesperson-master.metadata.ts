import { FormGroup } from "@angular/forms";

export class Salesperson {
    
    salespersonForm: FormGroup;                                                                  
    EmployeeCode: String;
    SalesPersonName:string;      
    LocationCode:String;

  
  }