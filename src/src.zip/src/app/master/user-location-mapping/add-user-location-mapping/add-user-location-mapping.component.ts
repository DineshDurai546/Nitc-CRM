import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { DropdownDataService, DropDownValue } from 'src/app/common/Services/dropdownService/dropdown-data.service'
import xml2js from 'xml2js';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserLocation } from './user-location-mapping.metadata';
import * as glob from 'src/app/config/global'

@Component({
  selector: 'app-add-user-location-mapping',
  templateUrl: './add-user-location-mapping.component.html',
  styleUrls: ['./add-user-location-mapping.component.sass']
})
export class AddUserLocationMappingComponent implements OnInit {

  constructor(
    private formBuilder: FormBuilder,
    private route: Router,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private toastMessage: ToastrService,
    private activatedRoute: ActivatedRoute
  ) { }

  userLocationForm: FormGroup
  params: any;
  formTitle: string = "Add"
  userlocation: UserLocation
  errorMessage: string;
  LocationAccGroup: DropDownValue = this.getBlankObject();

  ngOnInit(): void {
    this.userlocation = new UserLocation()
    this.userLocationForm = this.formBuilder.group({
      UserName: [null, Validators.required],
      locationCode: [null, Validators.required],
      IsActive: [null, Validators.required],
    })
    this.params = this.activatedRoute.snapshot.queryParams;
    if (this.params.nc != null || this.params.locationcode != undefined) {
      this.getData()
      this.formTitle = "Edit"
      this.userLocationForm.controls["UserName"].disable()
      this.userLocationForm.controls["LocationCode"].disable()
    }
     this.userlocation.userocation = this.userLocationForm
     this.onLocationAccGroupCode({ term: '', items: [] })

  }

  controlValidations() {
    Object.keys(this.userLocationForm.controls).forEach(field => {
      let controlValue = this.userLocationForm.get(field).value
      if (controlValue == null || controlValue == undefined) {
        this.toastMessage.error(field + " Cannot be Empty")
      }
    })
  }

  onLocationAccGroupCode($event: { term: string; items: any[] }) {

    this.dropdownDataService.fetchDropDownData(DropDownType.LocationAccountGroupCode, $event.term, {

    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.LocationAccGroup = value;
        }
      },
      error: (err) => {
        this.LocationAccGroup = this.getBlankObject();
      }
    });
  }

  getData() {
    let requestData = [];
    requestData.push({
      "Key": "ApiType",
      "Value": "GetUserLocationObject"
    });
    requestData.push({
      "Key": "UserName",
      "Value": this.params.nc

    });
    requestData.push({
      "Key": "LocationCode",
      "Value": this.params.locationcode

    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };

    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          let response = JSON.parse(Value.toString());
          console.log("*******",response)
          if (response.ReturnCode == '0') {
            let data = JSON.parse(response.ExtraData)?.UserLocation;
            console.log(data)
            this.userLocationForm.patchValue({
              UserName: data.UserName,
              locationCode: data.LocationCode,
              IsActive: data.isActive,
            })
            this.onLocationAccGroupCode({ term: '', items: [] })
          }
          else {
            console.log("error");
          }

        },
        error: err => {
          console.log(err);
        }
      });
  }

  returnPrevious() {
    this.route.navigateByUrl('/auth/'+glob.getCompanyCode()+'/user-location-mapping')
  }

  onSubmit() {
    this.controlValidations()
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "SaveUserLocationMapping"
    });
    requestData.push({
      "Key": "UserName",
      "Value": this.userLocationForm.controls["UserName"].value
    });
    requestData.push({
      "Key": "LocationCode",
      "Value": this.userLocationForm.controls["locationCode"].value
    });
    requestData.push({
      "Key": "IsActive",
      "Value": this.userLocationForm.controls["IsActive"].value
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest = {
      "content": strRequestData
    };
    console.log(contentRequest)
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (value) => {

          let response = JSON.parse(value.toString());
          if (response.ReturnCode == '0') {
            this.toastMessage.success("Form Submitted Successfully");
            this.returnPrevious()
          }
          else {
            this.errorMessage = response.ReturnMessage;
            const parser = new xml2js.Parser({ strict: false, trim: true });
            parser.parseString(response.ErrorMessage, (err, result) => {
              response['errorMessageJson'] = result;
              this.handleError(response);
            });
          }

        },
        error: err => {
          if (err.includes('"message":"Cannot')) {
            this.controlValidations()
          }
        }
      });
  }

  getErrorMessage(control: string): string {
    let formControl = this.userLocationForm.controls[control];
    if (formControl.valid) {
      return "";
    } else {
      return formControl.errors?.Message;
    }
  }

  handleError(response: any) {
    let errror = response.errorMessageJson.ERRORLIST.ERRORMESSAGE[0]["ERRORMESSAGE"]
    console.log(errror)
  }

  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

}
