import { FormGroup } from "@angular/forms";

export class UserLocation {
    userocation: FormGroup;
    userName: FormGroup;                                                                        
    locationCode: String;
    isActive: String;
  }