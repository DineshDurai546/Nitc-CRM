export class ActionMetaData {
    code: any;
    icon: any;    
}