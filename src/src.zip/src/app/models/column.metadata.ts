export class Columns {
    datatype: any;
    field: any;
    title:any;
}