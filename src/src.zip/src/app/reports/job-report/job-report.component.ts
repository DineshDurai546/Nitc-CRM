import { Component, OnInit } from '@angular/core';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import { NgxSpinnerService } from 'ngx-spinner';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { GsxService } from 'src/app/common/Services/gsxService/gsx.service';
import { ReportService } from 'src/app/common/Services/gsxService/report.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import * as glob from 'src/app/config/global';
import { Columns } from 'src/app/models/column.metadata';
import { BehaviorSubject } from 'rxjs';
import { DatePipe } from '@angular/common';
import { PaginationMetaData } from 'src/app/models/pagination.metadata';

@Component({
  selector: 'app-job-report',
  templateUrl: './job-report.component.html',
  styleUrls: ['./job-report.component.css']
})
export class JobReportComponent implements OnInit {

  typeSelected = 'ball-clip-rotate';
  LocationData: string;
  actionDetails: any[]=[];
  LocationForJob: DropDownValue = DropDownValue.getBlankObject();
  StartDate:any;
  hideSpinnerEvent: BehaviorSubject<void> = new BehaviorSubject<void>(null);
  EndDate:any;
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  isChoose: boolean = false;
  jobPagination: PaginationMetaData;
  results =[];
  CallType: DropDownValue = DropDownValue.getBlankObject();
  CallTypeData:string;
  CallStatus: any[] = ["OPEN","CLOSE"]
  CallStatusTypeData : string
  CaseIdData:string;
  screenDetail: any;

  columns: Columns[] = [
    {datatype:"STRING",field:"CaseId",title:"CaseId"},
    {datatype:"STRING",field:"CaseGUID",title:"CaseGuid"},
    {datatype:"STRING",field:"CaseDate",title:"CaseDate"},
    {datatype:"STRING",field:"JobType",title:"Call Type"},
    {datatype:"STRING",field:"SerialNo1",title:"Serial No"},
    {datatype:"STRING",field:"ProductType",title:"Product Type"},
    {datatype:"STRING",field:"productDescription",title:"Product Description"},
    {datatype:"STRING",field:"RetailCustomerCode",title:"Customer Code"},
    {datatype:"STRING",field:"BillingOption",title:"BillingOption"},
    {datatype:"STRING",field:"LocationCode",title:"Location Code"},
    {datatype:"STRING",field:"deviceCoverageDetails",title:"Device Coverage Detail"},

  ];
  constructor(
    private router: Router,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private gsxService: GsxService,
    private datePipe: DatePipe,
    private toast: ToastrService,
    private ngxSpinnerService: NgxSpinnerService,
    private reportService: ReportService,
    private activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.onLocationSearch({ term: "", item: [] });
    this.onJobType({ term: "", item: [] });
  }

  onJobType($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.callForm, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.CallType = value;
        }
      },
      error: (err) => {
        this.CallType = DropDownValue.getBlankObject();
      }

    });
  }


  actionEmit($event)
  {

  }

  onLocationSearch($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.LocationAccountGroupCode, $event.term, {
      CompanyCode: glob.getCompanyCode().toString(),
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.LocationForJob = value;
        }
      },
      error: (err) => {
        this.LocationForJob = DropDownValue.getBlankObject();
      }
    });
  }


  getReportData()
  {
    debugger
    this.results = []
    const startformattedDate = this.datePipe.transform(this.StartDate, 'yyyy-MM-dd');
    const endformattedDate = this.datePipe.transform(this.EndDate, 'yyyy-MM-dd');
      if((this.StartDate != null || this.StartDate != undefined) && (this.EndDate != null || this.EndDate != undefined ))
      {
        {
          let requestData = []
          this.ngxSpinnerService.show();
          requestData.push({
            "Key":"APIType",
            "Value":"GetJobReportList"
          })
          requestData.push({
            "Key":"LocationCode",
            "Value":this.LocationData == null || this.LocationData == undefined?'':this.LocationData
          })
          
          requestData.push({
            "Key":"StartDate",
            "Value":startformattedDate == null || startformattedDate == undefined?"0":startformattedDate
          })
          requestData.push({
            "Key":"EndDate",
            "Value":endformattedDate == null || endformattedDate == undefined?"0":endformattedDate
          })
          requestData.push({
            "Key":"CaseId",
            "Value":this.CaseIdData == null || this.CaseIdData == undefined?"":this.CaseIdData
          })
          requestData.push({
            "Key": "PageNo",
            "Value": "1"
          });
          requestData.push({
            "Key": "PageSize",
            "Value": "10"
          });
          console.log(requestData)
          let strRequestData = JSON.stringify(requestData);
          let contentRequest =
          {
            "content": strRequestData
          };
          console.log(contentRequest)
          this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
            {
              next: (Value) => {
                debugger
                try {
                  let response = JSON.parse(Value.toString());
                  if (response.ReturnCode == '0') {
                    let data = JSON.parse(response?.ExtraData);
                    console.log(data)
                    if(Array.isArray(data?.ReportData?.Report))
                    {
                      this.results = data?.ReportData?.Report
                    }
                    else
                    {
                      this.results.push(data?.ReportData?.Report)
                    }
                    console.log(this.results)
                    this.detail.next({ totalRecord: data?.Totalrecords, Data: this.results });
                    this.ngxSpinnerService.hide()
                  }
                } catch (ext) {
                  console.log(ext);
                }
              },
              error: err => {
                console.log(err);
                this.ngxSpinnerService.hide()
              }
            }
          );
        }
      }
      else
      {
        this.toast.error("Please Select Start and End Date")
      }
    
    
  }


  loadPageData(event){
    const startformattedDate = this.datePipe.transform(this.StartDate, 'yyyy-MM-dd');
    const endformattedDate = this.datePipe.transform(this.EndDate, 'yyyy-MM-dd');
    switch(event.eventType){
      case "PageChange":
        this.jobPagination.PageNumber  = event.eventDetail.pageIndex + 1;
        let requestData =[];
        requestData.push({
          "Key":"APIType",
          "Value":"GetJobReportList"
        })
        requestData.push({
          "Key":"LocationCode",
          "Value":this.LocationData == null || this.LocationData == undefined?'':this.LocationData
        })
        requestData.push({
          "Key":"StartDate",
          "Value":startformattedDate == null || startformattedDate == undefined?"0":startformattedDate
        })
        requestData.push({
          "Key":"EndDate",
          "Value":endformattedDate == null || endformattedDate == undefined?"0":endformattedDate
        })
        requestData.push({
          "Key":"CaseId",
          "Value":this.CaseIdData == null || this.CaseIdData == undefined?"":this.CaseIdData
        })
        requestData.push({
          "Key":"PageNo",
          "Value": event.eventDetail.pageIndex + 1 
        });
        requestData.push({
          "Key":"PageSize",
          "Value": event.eventDetail.pageSize
        });

        let strRequestData = JSON.stringify(requestData);
        let contentRequest =
        {
          "content" : strRequestData
        };    
        this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
          {
            next : (Value) =>
            {
              try{
                let response = JSON.parse(Value.toString());
                if(response.ReturnCode =='0')
                {
                  let data = JSON.parse(response?.ExtraData);
                  this.detail.next({totalRecord:data?.Totalrecords , Data: data?.ReportData?.Report });
                }
              }catch(ext){
                console.log(ext);
              }
            },
            error : err =>
            {
              console.log(err);
            }
          }
        );
        break;
    }  
    setTimeout(()=>{  this.hideSpinnerEvent.next( ); }, 1);
  }

  

  // exportReportData()
  // {
  //   const startformattedDate = this.datePipe.transform(this.StartDate, 'yyyy-MM-dd');
  //   const endformattedDate = this.datePipe.transform(this.EndDate, 'yyyy-MM-dd');
  //   this.results = []
  //   if(this.LocationData != null || this.LocationData != undefined )
  //   if((this.StartDate != null || this.StartDate != undefined) && (this.EndDate != null || this.EndDate != undefined ))
  //   {
  //     {
  //       let requestData = []
  //       this.ngxSpinnerService.show();
  //       requestData.push({
  //         "Key":"APIType",
  //         "Value":"ExportJobReportList"
  //       })
  //       requestData.push({
  //         "Key":"LocationCode",
  //         "Value":this.LocationData == null || this.LocationData == undefined?'':this.LocationData
  //       })
        
  //       requestData.push({
  //         "Key":"StartDate",
  //         "Value":startformattedDate == null || startformattedDate == undefined?"0":startformattedDate
  //       })
  //       requestData.push({
  //         "Key":"EndDate",
  //         "Value":endformattedDate == null || endformattedDate == undefined?"0":endformattedDate
  //       })
  //       requestData.push({
  //         "Key": "PageNo",
  //         "Value": "1"
  //       });
  //       requestData.push({
  //         "Key": "PageSize",
  //         "Value": "10"
  //       });
  //       console.log(requestData)
  //       let strRequestData = JSON.stringify(requestData);
  //       let contentRequest =
  //       {
  //         "content": strRequestData
  //       };
  //       console.log(contentRequest)
  //       this.reportService.downloadServiceReport('TOKEN',contentRequest).subscribe(
  //         {
  //           next: (Value) => {
  //             try {
  //               let response = JSON.parse(Value.toString());
  //               const byteArray = new Uint8Array(atob(response.FileContents).split('').map(char => char.charCodeAt(0)));
  //               var blob = new Blob([byteArray], { type: 'application/vnd.ms-excel' });
  //               var url = URL.createObjectURL(blob);
  //               window.open(url);
  //               this.ngxSpinnerService.hide()

  //             } catch (ext) {
  //               console.log(ext);
  //             }
  //           },
  //           error: err => {
  //             console.log(err);
  //             this.ngxSpinnerService.hide()
  //           }
  //         }
  //       );
  //     }
  //   }
  //   else
  //   {
  //     this.toast.error("Please Select Start and End Date")
  //   }
  // else
  // {
  //   this.toast.error("Please Select Location")
  // }
  
  // }

}