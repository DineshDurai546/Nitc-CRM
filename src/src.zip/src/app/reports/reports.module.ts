import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NitcControlModule } from '../nitc-control/nitc-control.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatCardModule } from '@angular/material/card';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { TokenReportComponent } from './token-report/token-report.component';
import { JobReportComponent } from './job-report/job-report.component';



@NgModule({
  declarations: [
  
    TokenReportComponent,
       JobReportComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    NitcControlModule,
    NgSelectModule,
    MatCardModule,
    NgxSpinnerModule,
    MatDatepickerModule,
    MatInputModule,
    NgxSpinnerModule

  ]
})
export class ReportsModule { }