import {
    Component,
    ContentChildren,
    QueryList,
    AfterContentInit,
    ViewChild,
    ComponentFactoryResolver,
    ViewContainerRef,
    Input
  } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

  import { CreateTabComponent } from './createtab.component';

  @Component({
    selector: 'my-tabs-create',
    template: `
    <div class="tab_content_header" style="height:30px;padding-top:20px">
    <h3 class="header_text">{{pageTitle}}</h3>
    <div class="create_btn">
        <button style="    white-space: nowrap; width: 100%;  font-size: 12px !important;" class="create_btn_content" (click)="CreateSales()">Create Job</button>
    </div>
     <ul class="layout_icons_wrapper wauto">
       <li *ngFor="let tab of tabs" (click)="selectTab(tab)" [class.active]="tab.active"  style="padding: 10px;">
       <span *ngIf = 'tab.gridicon != null && tab.gridicon != undefined' class="grid_svg_layout layout_icons_content" [innerHtml]=tab.gridicon> </span>
         <a  *ngIf = 'tab.title != null && tab.title != undefined'>{{tab.title}}</a>
       </li>
     </ul>
    </div>
      <ng-content></ng-content>
    `,
    styles: [
      `
      .tab-close {
        color: gray;
        text-align: right;
        cursor: pointer;
      }
      `
    ]
  })
  export class CreateTabsComponent implements AfterContentInit {

    @Input('pageTitle') pageTitle: string;
    @Input() onCreate: () => void;

    constructor(private route: ActivatedRoute, private router: Router) {}

    @ContentChildren(CreateTabComponent) tabs: QueryList<CreateTabComponent>;
    ngAfterContentInit() {
      let activeTabs = this.tabs.filter((tab)=>tab.active);
      if(activeTabs.length === 0) {
        this.selectTab(this.tabs.first);
      }
    }

    selectTab(tab: CreateTabComponent){
      this.tabs.toArray().forEach( ( tab) => {
        tab.active = false;
        tab.activeChange.emit(false);
      });
      tab.active = true;
      tab.activeChange.emit(true);
    }

    CreateSales() {
      this.onCreate();
    }
  }
