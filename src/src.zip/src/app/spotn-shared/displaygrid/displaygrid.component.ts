import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displaygrid',
  templateUrl: './displaygrid.component.html',
  styleUrls: ['./displaygrid.component.sass']
})
export class DisplaygridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
