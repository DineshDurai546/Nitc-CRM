import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignToTechnicianComponent } from './assign-to-technician.component';

describe('AssignToTechnicianComponent', () => {
  let component: AssignToTechnicianComponent;
  let fixture: ComponentFixture<AssignToTechnicianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignToTechnicianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignToTechnicianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
