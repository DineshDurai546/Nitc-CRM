import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentIssueComponent } from './component-issue.component';

describe('ComponentIssueComponent', () => {
  let component: ComponentIssueComponent;
  let fixture: ComponentFixture<ComponentIssueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComponentIssueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentIssueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
