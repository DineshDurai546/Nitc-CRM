import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup,Validator,FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { v4 as uuidv4 } from 'uuid';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';

@Component({
  selector: 'app-component-issue',
  templateUrl: './component-issue.component.html',
  styleUrls: ['./component-issue.component.css']
})
export class ComponentIssueComponent implements OnInit {


  selectComponentCode:DropDownValue = DropDownValue.getBlankObject();
  SelectIssueCode: DropDownValue = this.getBlankObject();
  selectProduct:any=['Not Applicable','Countinouse','Damaged']
  @Output() Closecomponent = new EventEmitter<boolean>();
  @Output() ComponentsIssues = new EventEmitter<any>();

// selectComponent:any=['AppleApp','Audio','Accessories','Accessibility-Vision','Accessibility-Hearing']
// selectIssue:any=['Mouse', 'Keyword','Pointer Control'];
// selectProduct:any=['Not Applicable','Continuous','Damaged']
getBlankObject(): DropDownValue {
  const ddv = new DropDownValue();
  ddv.TotalRecord = 0;
  ddv.Data = [];
  return ddv;
}

  constructor(
    private formBuilder:FormBuilder,
    private toastrService:ToastrService,
    private dropdownDataService:DropdownDataService,
  ) { }

  ngOnInit(): void {
    this.onComponentCodeSearch({ term: "", items: null });
  }

  onComponentCodeSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.bindcomponentcode, $event.term)
      .subscribe({
        next: (value) => {
          if (value != null) {
            this.selectComponentCode = value;
            this.SelectIssueCode = this.getBlankObject();
            this.onIssueCodeSearch({ term: "", items: [] });
          }
        },
        error: (err) => {
          this.selectComponentCode = this.getBlankObject();
          this.SelectIssueCode = this.getBlankObject();
          this.selectComponentCode = null;
          this.SelectIssueCode= null;
        },
      });
  }
  onIssueCodeSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.bindissueCode, $event.term, {
      ComponentCode: this.componentissueForm.controls["component"].value,
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.SelectIssueCode = value;
        }
      },
      error: err => {
        this.SelectIssueCode = this.getBlankObject();
      }
    });
  }
  ComponentEvent(event){
    this.componentissueForm.controls.issues.setValue('');
    this.onIssueCodeSearch({ term: "", items: [] });
  
  }

  componentissueForm = this.formBuilder.group({
    component:[],
    issues:[],
    productibility:[]

  })

  isCloseComponent:boolean=false;
  CloseComponentPopUp(){
    this.Closecomponent.emit(this.isCloseComponent)
  }

  AddComponentIssus(){
    if(this.componentissueForm.controls["component"].value == null ||
     this.componentissueForm.controls["component"].value == undefined ||
     this.componentissueForm.controls["component"].value == ""){
     this.toastrService.error("Please Select The Component");
     return false;
     }
     if(this.componentissueForm.controls["issues"].value == null ||
     this.componentissueForm.controls["issues"].value == undefined ||
     this.componentissueForm.controls["issues"].value == ""){
     this.toastrService.error("Please Select The Issues");
     return false;
     }
     if(this.componentissueForm.controls["productibility"].value == null ||
     this.componentissueForm.controls["productibility"].value == undefined ||
     this.componentissueForm.controls["productibility"].value == ""){
     this.toastrService.error("Please Select The productibility");
     return false;
     }
     else{
      const ComponentIssuesObj:any={
        "DiagnosisDetailGUID": uuidv4 (),
        "ComponentDesc":this.componentissueForm.controls["component"].value,
        "IssueDesc":this.componentissueForm.controls["issues"].value,
        "ReproducibilityDescription":this.componentissueForm.controls["productibility"].value
      }
      this.ComponentsIssues.emit(ComponentIssuesObj)

   this.Closecomponent.emit(this.isCloseComponent)
      this.Closecomponent.emit(false)
     }

  }
//  TestData(){
//   console.log("ComponentDesc:",this.componentissueForm.controls["component"].value)
//   console.log("IssueDesc",this.componentissueForm.controls["issues"].value)
//   console.log("ReproducibilityDescription",this.componentissueForm.controls["productibility"].value)
//  }

}
