import { Component, Input, OnInit, SimpleChanges, EventEmitter , Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { v4 as uuidv4 } from 'uuid';
import { HandOverData } from './hand-over.metadata';
import { CaseDetail } from '../repair-process.metadata';
import * as glob from "../../../config/global";
import xml2js from 'xml2js';
import { DatePipe } from '@angular/common';
import { lastValueFrom } from 'rxjs';
//import { ImagePopupComponent } from 'src/app/custom-components/create-job-customer/image-popup/image-popup.component';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-hand-over',
  templateUrl: './hand-over.component.html',
  styleUrls: ['./hand-over.component.css']
})
export class HandOverComponent implements OnInit {

  errorMessage: any;
  isHandOver: boolean = false;
  isAuthPersonSignature : boolean 
  isCustomerSignature : boolean
  HandOverList: any = ['Release']
  HandOverViewList: any [] = []
  HandOverLists: any [] = []
  InputMode=""
  SignatureList: any [] = []
  AuthorisedPersonSignature
  dictData = []
  controlName = ''
  answer = ''
  dictArr = []
  AuthPersonSignature
  CustomerSignature
  datePipe:DatePipe;
  UploadedImageList:any[]=[];
  isSubmit=  true

 

  ngOnChanges(changes: SimpleChanges): void{
    
    if(changes['repa'])
    {
        if(this.repa!= null && this.repa != undefined  ){
          if(this.repa.OTPVALUE != null || this.repa.OTPVALUE != undefined){
            if(this.isSubmit == true){
              this.onSubmit()
            }
          }
          this.HandOverViewList = [];
          this.HandOverLists = [];
          this.HandOverLists.push(this.repa.HANDOVER)
          if(Array.isArray(this.HandOverLists))
          {
            for ( var item of this.HandOverLists)
            {
              this.HandOverViewList.push({
                "HandOverCode":   item?.HandOverCode,
                "HandOverStatus": item?.HandOverStatus==null || item?.HandOverStatus==undefined ? "Release":item?.HandOverStatus,
                "Remark": item?.Remark,
                "CreatedBy": item?.CreatedBy,
                "CreatedDate":item?.CreatedDate,
              })
            }
          }
        }
      }
   
    }

 

    addHandOver() {
   
    this.isHandOver = !this.isHandOver
  }
 
  constructor(
    private formBuilder: FormBuilder,
    private dynamicService: DynamicService,
    private toaster: ToastrService,
    private dialog:MatDialog

  ) { }

  handoverForm: FormGroup;
  handover: HandOverData

  ngOnInit(): void { 

    this.handover = new HandOverData();
    this.handoverForm = this.formBuilder.group({
      HandOverRemark: [null, [Validators.required]],
    });
 
   
  }
  // @Input() Signature
  // @Input() AuthPerson
  @Input() repa: CaseDetail;
  @Output() HanOverUpdated = new EventEmitter<any>();
  // @Output() AddSignature = new EventEmitter<any>();

  // @Output() addCustomerSignature = new EventEmitter<any>();
  // @Output() addAuthorisedSignature = new EventEmitter<any>();

  @Output() isHandoverSubmitted = new EventEmitter<any>();
  @Output() isOtpCall= new EventEmitter<any>();

  async onValidation(){
    
    let errorcount =0  

    var myDate = new Date();
    this.datePipe=new DatePipe("en-US")
    var strDate = this.datePipe.transform(myDate, 'yyyy-MM-ddThh:mm:ss');

    let handoverguid = uuidv4();
    const handoverval = this.handoverForm.value
    // this.dynamicService.validateAllFormFields(this.handoverForm);
    
    const pattern = /^[^\\+\\=@\\-]/;
    const htmlpattern= /<(\"[^\"]\"|'[^']'|[^'\">])*>/
    if(!pattern.test(handoverval.HandOverRemark))
    {
      this.toaster.error("Invalid Remark Pattern")
      return;
    }
    if(htmlpattern.test(handoverval.HandOverRemark))
    {
      this.toaster.error("Invalid Remark Pattern")
      return;
    }
    errorcount == 0 ? this.isHandoverSubmitted.emit(true) : ''
  }
check:boolean;

  // validationCheck() 
  // {
  //   this.check=true

  //   if(this.AuthPerson == undefined )
  //   {
  //     this.toaster.error("Please Add Authorization Signature")
  //     this.check=false
  //     return;
      
  //   }

  //   if(this.Signature == undefined)
  //   {
  //     this.toaster.error("Please Add Customer Signature")
  //     this.check=false
  //     return;
  //   }
    
  //   Object.keys(this.handoverForm.controls).forEach(field => {
  //     let control = this.handoverForm.get(field).value
  //     if (control == null || control == undefined) {
  //       this.toaster.error(field + " Cannot be Empty")
  //       this.check=false
  //       return false;
         
  //     }
  //   })
  // }

  onSubmit() {
 

   
      this.isOtpCall.emit(true)
   
    var myDate = new Date();
    this.datePipe=new DatePipe("en-US")
    var strDate = this.datePipe.transform(myDate, 'yyyy-MM-ddThh:mm:ss');

    let handoverguid = uuidv4();
    const handoverval = this.handoverForm.value
   
 
      let requestData = [];
      requestData.push({
        "Key": "ApiType",
        "Value": "SaveHandOver"
      });
      requestData.push({
        "Key": "CompanyCode",
        "Value": glob.getCompanyCode()
      });
      requestData.push({
        "Key": "HandOverGUID",
        "Value": handoverguid
      });
      requestData.push({
        "Key": "HandOverCode",
        "Value": "NEW"
      });
      requestData.push({
        "Key": "HandOverDate",
        "Value": strDate
      });
      requestData.push({
        "Key": "HandOverStatus",
        "Value": handoverval.HandOverStatus==null || handoverval.HandOverStatus==undefined ? "Release":handoverval.HandOverStatus
      });
      requestData.push({
        "Key": "HandOverRemark",
        "Value": handoverval.HandOverRemark
      });
      requestData.push({
        "Key": "CaseGUID",
        "Value": this.repa.CaseGUID
      });
      // requestData.push({
      //   "Key": "JobChecklistDetails",
      //   "Value": this.ConvertObjectIntoXml()
      // });
      // OTP Verification Data
      requestData.push({
        "Key": "OTPguid",
        "Value": this.repa.OTPVALUE.OTPGUID
      });
      requestData.push({
        "Key": "OTP",
        "Value": this.repa.OTPVALUE.OTP
      });
      requestData.push({
        "Key": "LocationCode",
        "Value": this.repa.LocationCode
      });
      requestData.push({
        "Key": "CustomerCode",
        "Value": this.repa.CUSTOMER.CustomerCode
      });

      console.log(requestData);
      let strRequestData = JSON.stringify(requestData);
      console.log(strRequestData);
      let contentRequest = {
        "content": strRequestData
      };
      console.log(requestData);
      // // TODO
      // return
      this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
        {
          next: (value) => {

            let response = JSON.parse(value.toString());

            if (response.ReturnCode == '0') { 
              console.log("sucess");
              // this.addHandOver()
              this.isHandOver = !this.isHandOver
              this.toaster.success('Form Submitted Successfully')
              var getval = JSON.parse(response.ExtraData);
              this.isSubmit = false;
              this.HanOverUpdated.emit(getval)
            }
            else {
              this.isSubmit = true;
              // console.log("Messages : " ,response)
              this.errorMessage = response?.ErrorMessage;
              console.log("Messages : " ,this.errorMessage)
              const parser = new DOMParser();
              const xmlDoc = parser.parseFromString(this.errorMessage, 'text/xml');
              const errorMessages = xmlDoc.getElementsByTagName('ErrorMessage');
              for (let i = 0; i < errorMessages.length; i++) {
                const errorMsg = errorMessages[i].textContent;
                this.toaster.error(errorMsg); // Display only the error message
              }    
            }
          },
          error: err => {
            this.isSubmit = true;
            console.log(err);
          }
        });
 
  }

  onReset() {
    this.handoverForm.reset();
    this.toaster.info("Form Reset")
  }
  


 
 
 
 

 

 

 
 

}