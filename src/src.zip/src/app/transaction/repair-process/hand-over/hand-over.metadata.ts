export class HandOverData{
    HandOverCode: number;
    HandOverDate: Date;
    HandOverRemark: String;
   
  }