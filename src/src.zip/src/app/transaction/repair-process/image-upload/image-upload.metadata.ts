export class ImgUpload{
    UploadedImageLists: any[] = [];
   
  }