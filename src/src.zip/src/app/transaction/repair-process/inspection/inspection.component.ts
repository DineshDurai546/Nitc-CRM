import { Component, OnInit, Input, EventEmitter, Output, SimpleChanges } from '@angular/core';
import { FormGroup,FormBuilder, Validator, Validators } from '@angular/forms';
import { DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DropDownValue } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DropDownType } from 'src/app/custom-components/call-login/metadata/request.metadata';
import { ToastrService } from 'ngx-toastr';
import * as glob from "../../../config/global";
import { CaseDetail } from '../repair-process.metadata';
import { v4 as uuidv4 } from 'uuid';
import xml2js from 'xml2js';
import { InspectionMetaData } from './inspection.metadata';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-inspection',
  templateUrl: './inspection.component.html',
  styleUrls: ['./inspection.component.css']
})
export class InspectionComponent implements OnInit {

  // =========Boolean Value===========
  billiablebox:boolean=false;
  ispaymentterm:boolean=false;
  iscomponentpopup:boolean=false;
  isDiagEdit: boolean = true;
  ComponentIssueList:any=[];
  inspectionMetaData:InspectionMetaData
  isCheckBox: boolean = false;
  BillableRepair: string;
  isdisabledAllfield:boolean=false;
  isreason:boolean=false;

  // =============Input Event ===========
  @Input() repa : CaseDetail;
  @Input() compoissuelist : any[]
  @Output() InspUpdated  = new EventEmitter<any>();
  @Output() openComponentIssuePopupEvent  = new EventEmitter<any>();


  RepairType : DropDownValue = this.getBlankObject(); 
  BillingOption: DropDownValue = DropDownValue.getBlankObject();
  SubmissionType:DropDownValue = DropDownValue.getBlankObject();
  NoOfDays:DropDownValue = DropDownValue.getBlankObject();
  PaymentTerms:DropDownValue = DropDownValue.getBlankObject();
  selectedReason:DropDownValue = DropDownValue.getBlankObject();
  constructor(
    private formBuilder:FormBuilder,
    private dropdownDataService:DropdownDataService,
    private toastrService:ToastrService,
    private dynamicService:DynamicService,
    private datePipe : DatePipe
  ) { }

  ngOnChanges(changes: SimpleChanges): void{
    if(changes['repa'])
    {
      console.log("Inspection ", this.repa)
      if(this.repa!= null && this.repa != undefined  ){
        if(this.repa!= null && this.repa != undefined ){
          this.inspectionMetaData.DiagnosisGUID = this.repa?.DIAG?.DiagnosisGUID;
          this.inspectionMetaData.RepairType = this.repa?.DIAG?.RepairType;
          this.inspectionMetaData.Remark = this.repa?.DIAG?.Remark;
          this.inspectionMetaData.Reason = this.repa?.DIAG?.Reason;
          this.inspectionMetaData.DiagnosisCode = this.repa?.DIAG?.DiagnosisCode;
          this.inspectionMetaData.DiagnosisDate = this.repa?.DIAG?.DiagnosisDate;
          this.inspectionMetaData.RepairType = this.repa?.DIAG?.RepairType;
          this.inspectionMetaData.RepairTypeDesc = this.repa?.DIAG?.RepairTypeDesc;
          this.inspectionMetaData.BillingOption = this.repa?.DIAG?.BillingOption;
          this.inspectionMetaData.BillingOptionDesc = this.repa?.DIAG?.BillingOptionDescription;
          this.inspectionMetaData.SubmissionType = this.repa?.DIAG?.SubmissionType;
          this.inspectionMetaData.SubmissionTypeDesc = this.repa?.DIAG?.SubmissionTypeDesc;
          this.inspectionMetaData.DiagnosisStatus = this.repa?.DIAG?.DiagnosisStatus;
          this.inspectionMetaData.LaborCovered = this.repa?.DIAG?.LaborCovered;
          this.inspectionMetaData.PartsCovered = this.repa?.DIAG?.PartsCovered;
          this.inspectionMetaData.NoOfDays = this.repa?.DIAG?.NoOfDaysToComplete;
          this.inspectionMetaData.NoOfDaysDesc = this.repa?.DIAG?.NoOfDaysToCompleteDesc;
          this.inspectionMetaData.BillableRepair = this.repa?.DIAG?.BillableRepair == 1 ? true : false;
          this.inspectionMetaData.PaymentTerms = this.repa?.DIAG?.PaymentTerms
          this.isCheckBox= this.repa?.DIAG?.BillableRepair==1 ? true:false;
          this.inspectionForm = this.formBuilder.group({
            RepairType: [this.inspectionMetaData.RepairType, Validators.required],
            BillingOption: [this.inspectionMetaData.BillingOption, Validators.required],
            NoOfDays:[this.inspectionMetaData.NoOfDays, Validators.required],
            PaymentTerms: [this.inspectionMetaData.PaymentTerms],
            billableRepair:[this.inspectionMetaData.BillableRepair],
            SubmissionType:[this.inspectionMetaData.SubmissionType],
            Remark:[this.inspectionMetaData.Remark, Validators.required]
          });
        }
        this.ComponentIssueList=[];
        this.inspectionMetaData.SelectedComponentIssue = []
        if(Array.isArray(this.repa?.DIAG?.DIAGLIST?.DIAGDETAIL))
        {
          for ( var item of this.repa?.DIAG?.DIAGLIST?.DIAGDETAIL)
          {
            this.inspectionMetaData.SelectedComponentIssue.push({
              "DiagnosisDetailGUID":item.DiagnosisDetailGUID,
              "ComponentCode": item.ComponentCode,
              "ComponentDesc": item.ComponentDesc,
              "IssueCode": item.IssueCode,
              "IssueDesc": item.IssueDesc,
              "ReproducibilityCode": item.ReproducibilityCode,
              "ReproducibilityDescription": item.ReproducibilityDescription,
              "IsDeleted": item.IsDeleted
            })
          }
        }
        else
        {
          var lstDiagDetail=[];
          lstDiagDetail.push(this.repa?.DIAG?.DIAGLIST?.DIAGDETAIL);
          this.inspectionMetaData.SelectedComponentIssue.push({
            "DiagnosisDetailGUID":lstDiagDetail[0].DiagnosisDetailGUID,
            "ComponentCode": lstDiagDetail[0].ComponentCode,
            "ComponentDesc": lstDiagDetail[0].ComponentDesc,
            "IssueCode": lstDiagDetail[0].IssueCode,
            "IssueDesc": lstDiagDetail[0].IssueDesc,
            "ReproducibilityCode":  lstDiagDetail[0].ReproducibilityCode,
            "ReproducibilityDescription":  lstDiagDetail[0].ReproducibilityDescription,
            "IsDeleted": lstDiagDetail[0].IsDeleted
          })
          
        }
        this.ComponentIssueList = this.inspectionMetaData.SelectedComponentIssue 
        console.log("Inspection ", this.inspectionMetaData)

      }
    }
  
    if(changes['compoissuelist'])
    {
        debugger;
        if(this.compoissuelist!= null && this.compoissuelist != undefined ){
          0
          console.log("My Data" ,this.compoissuelist)
          var object4 = this.compoissuelist;
          if(this.validateComponents(object4)){
            this.inspectionMetaData.SelectedComponentIssue.push(object4);
         }
      }
    }
  }
  
  validateComponents(com: any) {
    for (let item of this.inspectionMetaData.SelectedComponentIssue) {
      if (item.ComponentDesc == com.ComponentDesc && item.IssueDesc == com.IssueDesc) {
        this.toastrService.error("Component & Issue already exists")
        return false;
      }
    }
    this.toastrService.success("Issue Added Successfully!");
    return true;
  }

  ngOnInit(): void {
    this.inspectionMetaData = new InspectionMetaData();
    this.onRepairType({ term: "", items: [] });
    this.onReasonSearch({ term: "", items: [] });
    this.onBillingOption({ term: "", items: [] });
    this.onSubmissionType({ term: "", item: [] });
    this.onNoOfDays({ term: "", items: [] });
    this.onPaymentTerms({ term: "", item: [] });

    if( this.inspectionMetaData.DiagnosisStatus == 'RELEASED' ){
      this.editDiagForm();
      this.isDiagEdit = false;
     }
     this.setDataFunction()
  }
  
  editDiagForm() {
    this.isDiagEdit = !this.isDiagEdit
  }


  getBlankObject(): DropDownValue {
    const ddv = new DropDownValue();
    ddv.TotalRecord = 0;
    ddv.Data = [];
    return ddv;
  }

  inspectionForm = this.formBuilder.group({
    RepairType:[],
    BillingOption:[],
    SubmissionType:[],
    NoOfDays:[],
    billableRepair:[],
    PaymentTerms:[],
    Remark:[],
    Reason:[],
  })

  billableChangeEvent(event){
    if(this.inspectionForm.controls["BillableRepair"].value == true){
      this.ispaymentterm=true;
    }
    else{
      this.ispaymentterm=false;
    }
  }

  // ===========RepairType DropDown=================

  onRepairType($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.RepairType, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          console.log(value);
          this.RepairType = value;
        }
      },
      error: (err) => {
        this.RepairType = this.getBlankObject();
      }
    });
  }

  
  onReasonSearch($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.SNRReason, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          console.log(value);
          this.selectedReason = value;
        }
      },
      error: (err) => {
        this.selectedReason = this.getBlankObject();
      }
    });
  }

  // ==============BillingOption DropDown===========================
  onBillingOption($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.CovarageOption, $event.term).subscribe({
      next: (value) => {
        if (value != null) {
          console.log(value);
          this.BillingOption = value;
        }
      },
      error: (err) => {
        this.BillingOption = this.getBlankObject();
      }
    });
  }

  // ================SubmissionType DropDown================
  onSubmissionType($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.SubmissionType, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.SubmissionType = value;
        }
      },
      error: (err) => {
        this.SubmissionType = DropDownValue.getBlankObject();
      }
    });
  }

  // ============NoofDays=========================
  
  onNoOfDays($event: { term: string; items: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.NoOfDays, $event.term).subscribe({
      next: (value) => {
        if (value != null) {
          console.log(value);
          this.NoOfDays = value;
        }
      },
      error: (err) => {
        this.NoOfDays = this.getBlankObject();
      }
    });
  }
  
  // =========PaymentTerms Dropdown=========

  onPaymentTerms($event: { term: string; item: any[] }) {
    this.dropdownDataService.fetchDropDownData(DropDownType.PaymentTerm, $event.term, {
    }).subscribe({
      next: (value) => {
        if (value != null) {
          this.PaymentTerms = value;
        }
      },
      error: (err) => {
        this.PaymentTerms = DropDownValue.getBlankObject();
      }
    });
  }

  openComponentIssue(){
    this.iscomponentpopup=true;
  }

  ComponentPopUpColse(event){
    this.iscomponentpopup=false;
  }
  
  setDataFunction(){
    console.log("Working Function")
    if(this.repa!= null && this.repa != undefined ){
      console.log("DiagnosisCode:",this.repa?.DIAG?.DiagnosisCode)
      this.inspectionMetaData.DiagnosisGUID = this.repa?.DIAG?.DiagnosisGUID;
        this.inspectionMetaData.DiagnosisCode = this.repa?.DIAG?.DiagnosisCode;
        this.inspectionMetaData.DiagnosisDate = this.repa?.DIAG?.DiagnosisDate;
        this.inspectionMetaData.RepairType = this.repa?.DIAG?.RepairType;
        this.inspectionMetaData.Remark = this.repa?.DIAG?.Remark;
        this.inspectionMetaData.Reason = this.repa?.DIAG?.Reason;
        this.inspectionMetaData.RepairTypeDesc = this.repa?.DIAG?.RepairTypeDesc;
        this.inspectionMetaData.BillingOption = this.repa?.DIAG?.BillingOption;
        this.inspectionMetaData.SubmissionType = this.repa?.DIAG?.SubmissionType;
        this.inspectionMetaData.SubmissionTypeDesc = this.repa?.DIAG?.SubmissionTypeDesc;
        this.inspectionMetaData.LaborCovered = this.repa?.DIAG?.LaborCovered;
        this.inspectionMetaData.DiagnosisStatus = this.repa?.DIAG?.DiagnosisStatus;
        this.inspectionMetaData.PartsCovered = this.repa?.DIAG?.PartsCovered;
        this.inspectionMetaData.NoOfDays = this.repa?.DIAG?.NoOfDaysToComplete;
        this.inspectionMetaData.NoOfDaysDesc = this.repa?.DIAG?.NoOfDaysToCompleteDesc;
        this.inspectionMetaData.BillableRepair = this.repa?.DIAG?.BillableRepair == 1 ? true : false;
        this.inspectionMetaData.PaymentTerms = this.repa?.DIAG?.PaymentTerms;

          this.inspectionForm = this.formBuilder.group({
          RepairType: [this.inspectionMetaData.RepairType, Validators.required],
          BillingOption: [this.inspectionMetaData.BillingOption, Validators.required],
          NoOfDays:[this.inspectionMetaData.NoOfDays, Validators.required],
          PaymentTerms: [this.inspectionMetaData.PaymentTerms],
          billableRepair:[this.inspectionMetaData.BillableRepair],
          SubmissionType:[this.inspectionMetaData.SubmissionType],
          Reason:[this.inspectionMetaData.Reason, Validators.required],
          Remark:[this.inspectionMetaData.Remark, Validators.required]
        });

        this.inspectionMetaData.SelectedComponentIssue=[]
        if(Array.isArray(this.repa?.DIAG?.DIAGLIST?.DIAGDETAIL))
        {
          for ( var item of this.repa?.DIAG?.DIAGLIST?.DIAGDETAIL)
          {
            this.inspectionMetaData.SelectedComponentIssue.push({
              "DiagnosisDetailGUID":item.DiagnosisDetailGUID,
              "ComponentCode": item.ComponentCode,
              "ComponentDesc": item.ComponentDesc,
              "IssueCode": item.IssueCode,
              "IssueDesc": item.IssueDesc,
              "ReproducibilityCode": item.ReproducibilityCode,
              "ReproducibilityDescription": item.ReproducibilityDescription,
              "IsDeleted": item.IsDeleted
            })
          }
        }
        else
        {
          var lstDiagDetail=[];
          lstDiagDetail.push(this.repa?.DIAG?.DIAGLIST?.DIAGDETAIL);
          this.inspectionMetaData.SelectedComponentIssue.push({
            "DiagnosisDetailGUID":lstDiagDetail[0].DiagnosisDetailGUID,
            "ComponentCode": lstDiagDetail[0].ComponentCode,
            "ComponentDesc": lstDiagDetail[0].ComponentDesc,
            "IssueCode": lstDiagDetail[0].IssueDesc,
            "IssueDesc": lstDiagDetail[0].IssueDesc,
            "ReproducibilityCode":  lstDiagDetail[0].ReproducibilityCode,
            "ReproducibilityDescription":  lstDiagDetail[0].ReproducibilityDescription,
            "IsDeleted": lstDiagDetail[0].IsDeleted
          })
          
        }
        this.ComponentIssueList = this.inspectionMetaData.SelectedComponentIssue 
      }
      if(this.inspectionMetaData.DiagnosisStatus == 'RELEASED' ){
        this.editDiagForm();
        this.isDiagEdit = false;
      }

      }

  removeComponent(item) {
    item.IsDeleted = '1';
    this.updateInspectionXML() 
    console.log("++" , this.inspectionMetaData.SelectedComponentIssue)
  }

  
  updateInspectionXML(){
    let rawData = {
      "rows": []
    }
    for (let item of this.inspectionMetaData.SelectedComponentIssue) {
      rawData.rows.push({
        "row": {
          "DiagnosisDetailGUID":item.DiagnosisDetailGUID,
          "ComponentCode": item.ComponentDesc,
          "ComponentDesc":item.ComponentDesc,
          "IssueCode": item.IssueDesc,
          "IssueDesc":item.IssueDesc,        
          "ReproducibilityCode":item.ReproducibilityDescription,
          "ReproducibilityDescription":item.ReproducibilityDescription,
          "IsDeleted": item.IsDeleted
        }
      })
    }
    console.log("rawData", rawData);
    var builder = new xml2js.Builder();
    var xml = builder.buildObject(rawData);
    xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
    xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
    xml = xml.split(' ').join('')
    console.log("Updated xml", xml);
    return xml;
  }


  GetcomponentIssueObj(event){
    this.inspectionMetaData.SelectedComponentIssue.push(event);
  }

  SaveInspection(){
    let newDiagGuid = uuidv4();
    let RequestInspection=[];
    RequestInspection.push({
      "Key":"APIType",
      "Value":"SaveDiagnosis"
    })
    RequestInspection.push({
      "Key":"CompanyCode",
      "Value":glob.getCompanyCode()
    })
    RequestInspection.push({
      "Key":"DiagnosisGUID",
      "Value": this.repa.DiagGUID ==  '00000000-0000-0000-0000-000000000000' || this.repa.DiagGUID == undefined || this.repa.DiagGUID == null  ? newDiagGuid : this.repa.DIAG.DiagnosisGUID
    })
    RequestInspection.push({
      "Key":"CaseGUID",
      "Value":this.repa.CaseGUID
    })
    RequestInspection.push({
      "Key": "DiagnosisCode",
      "Value": "New"
    });
    RequestInspection.push({
      "Key":"DiagnosisDate",
      "Value": this.datePipe.transform( new Date() , 'dd-MM-yyyy')
    })
    RequestInspection.push({
      "Key": "DiagnosisStatus",
      "Value": "RELEASED"
    });
    RequestInspection.push({
      "Key":"NoOfDaysToComplete",
      "Value":this.inspectionForm.controls["NoOfDays"].value == null || this.inspectionForm.controls["NoOfDays"].value == undefined ? '': this.inspectionForm.controls["NoOfDays"].value
    })
    RequestInspection.push({
      "Key":"RepairType",
      "Value":this.inspectionForm.controls["RepairType"].value
    })
    RequestInspection.push({
      "Key":"BillingOption",
      "Value":this.inspectionForm.controls["BillingOption"].value == null || this.inspectionForm.controls["BillingOption"].value == undefined ? '' : this.inspectionForm.controls["BillingOption"].value
    })
    RequestInspection.push({
      "Key":"SubmissionType",
      "Value":this.inspectionForm.controls["SubmissionType"].value == null || this.inspectionForm.controls["SubmissionType"].value == undefined ? '' : this.inspectionForm.controls["SubmissionType"].value 
    })
    RequestInspection.push({
      "Key": "PartsCovered",
      "Value": this.repa?.PartCovered == null || this.repa?.PartCovered == undefined ?0 : this.repa?.PartCovered
    });
    RequestInspection.push({
      "Key": "LaborCovered",
      "Value": this.repa?.LaborCovered == null || this.repa?.LaborCovered == undefined ?0 : this.repa?.LaborCovered,
    });
    RequestInspection.push({
      "Key":"Remark",
      "Value": this.inspectionForm.controls["Remark"].value
    })
    RequestInspection.push({
      "Key":"Reason",
      "Value": this.inspectionMetaData.Reason
      // this.inspectionForm.controls["Reason"].value == null || this.inspectionForm.controls["Reason"].value == undefined ? '' : this.inspectionForm.controls["Reason"].value
    })
    RequestInspection.push({
      "Key":"BillableRepair",
      "Value":this.inspectionForm.controls["billableRepair"].value == null || this.inspectionForm.controls["billableRepair"].value == undefined ? '' : this.inspectionForm.controls["billableRepair"].value
    })

    RequestInspection.push({
      "Key":"PaymentTerms",
      "Value":this.inspectionForm.controls["PaymentTerms"].value == null || this.inspectionForm.controls["PaymentTerms"].value == undefined ? '' : this.inspectionForm.controls["PaymentTerms"].value
    })
    RequestInspection.push({
      "Key":"DiagnosisDetail",
      "Value":this.inspectionXML()
    })
    console.log("Inspection Array:",RequestInspection)
    let RequestIns= JSON.stringify(RequestInspection)
    let requestContent={
      "content":RequestIns
    }
    this.dynamicService.getDynamicDetaildata(requestContent).subscribe({
      next:(value)=>{
        let response = JSON.parse(value.toString())
        if(response.ReturnCode == '0'){
          this.toastrService.success("Inspection Added/Edited Successfully")
          var data = JSON.parse(response.ExtraData)
          this.InspUpdated.emit(data)
          this.isDiagEdit = false
        }
        if(response.ReturnCode == '1'){
            console.log("Messages : " ,response.ErrorMessage)
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(response.ErrorMessage, 'text/xml');
            const eachErrorMessagesList = xmlDoc.getElementsByTagName('errorMessage');
        
            for (let i = 0; i < eachErrorMessagesList.length; i++) {
              console.log("Error List ", eachErrorMessagesList[i].getElementsByTagName('ErrorMessage'))
              const eachErrorMessages = eachErrorMessagesList[i].getElementsByTagName('ErrorMessage')[0];
              this.toastrService.error(eachErrorMessages.textContent);
            }
        }
      },
      error: err =>{
        console.log("Error Message:- ", err)
        const errors = err.split("Error Code:").slice(1); // Split the error string into separate error segments
        errors.forEach(error => {
          const messageIndex = error.indexOf("Message: ");
          if (messageIndex !== -1) {
            const messageSubstring = error.substring(messageIndex + 9).trim();
            const message = JSON.parse(messageSubstring).message;
            this.toastrService.error("Error:- " + message);
          } else {
            this.toastrService.error("Error parsing the error message.");
          }
        });
      }
    })
  }

  inspectionXML(){
      let rawData = {
        "rows": []
      }
      for (let item of this.inspectionMetaData.SelectedComponentIssue) {
        console.log("All Component Name:",item)
        rawData.rows.push({
          "row": {
            "DiagnosisDetailGUID":item.DiagnosisDetailGUID,
            "ComponentCode": item.ComponentDesc,
            "ComponentDesc":item.ComponentDesc,
            "IssueCode": item.IssueDesc,
            "IssueDesc":item.IssueDesc,        
            "ReproducibilityCode":item.ReproducibilityDescription,
            "ReproducibilityDescription":item.ReproducibilityDescription,
            "IsDeleted": item.IsDeleted
          }
        })
      }
      console.log("rawData", rawData);
      var builder = new xml2js.Builder();
      var xml = builder.buildObject(rawData);
      xml = xml.toString().replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', "");
      xml = xml.toString().replace(/(\r\n|\n|\r|\t)/gm, "");
      xml = xml.split(' ').join('')
      console.log("xml", xml);
      return xml;
  }

  InspectionValidation(){
    if(this.inspectionForm.controls["RepairType"].value == null||
    this.inspectionForm.controls["RepairType"].value == undefined||
    this.inspectionForm.controls["RepairType"].value == ""){
    this.toastrService.error("Please Select Repair Type");
    return false;
    }

    if(this.inspectionForm.controls["Remark"].value == null||
    this.inspectionForm.controls["Remark"].value == undefined||
    this.inspectionForm.controls["Remark"].value == ""){
    this.toastrService.error("Please Enter Remark");
    return false;
    }
    // if(this.inspectionForm.controls["RepairType"].value == 'SVNR' ){
    //   if(this.inspectionForm.controls["Reason"].value == null||
    //   this.inspectionForm.controls["Reason"].value == undefined||
    //   this.inspectionForm.controls["Reason"].value == ""){
    //   this.toastrService.error("Please Select Reason");
    //   return false;
    //   }
    // }

    // if(this.inspectionForm.controls["BillingOption"].value == null||
    // this.inspectionForm.controls["BillingOption"].value == undefined||
    // this.inspectionForm.controls["BillingOption"].value == ""){
    // this.toastrService.error("Please Select Billing Option");
    // return false;
    // }
    // if(this.inspectionForm.controls["SubmissionType"].value == null||
    // this.inspectionForm.controls["SubmissionType"].value == undefined||
    // this.inspectionForm.controls["SubmissionType"].value == ""){
    // this.toastrService.error("Please Select Submission Type");
    // return false;
    // }
    // if(this.inspectionForm.controls["NoOfDays"].value == null||
    // this.inspectionForm.controls["NoOfDays"].value == undefined||
    // this.inspectionForm.controls["NoOfDays"].value == ""){
    // this.toastrService.error("Please Select No Of Days");
    // return false;
    // }
    // if(this.inspectionForm.controls["billableRepair"].value == null||
    // this.inspectionForm.controls["billableRepair"].value == undefined||
    // this.inspectionForm.controls["billableRepair"].value == ""){
    // this.toastrService.error("Please select Billable Repair");
    // return false;
    // }
    // if(this.inspectionForm.controls["PaymentTerms"].value == null||
    // this.inspectionForm.controls["PaymentTerms"].value == undefined||
    // this.inspectionForm.controls["PaymentTerms"].value == ""){
    // this.toastrService.error("Please select Payment Terms");
    // return false;
    // }
    if(this.inspectionMetaData.SelectedComponentIssue.length === 0){
      this.toastrService.error("Please select Component And Issue");
    }
    else{
      this.SaveInspection()
    }
  }


  isCheckBoxFunc(){
      if (this.isCheckBox == true) {
        this.isCheckBox = false;
        this.inspectionForm.controls["PaymentTerms"].setValue("");
        this.BillableRepair = '0';
      } else {
        this.isCheckBox = true;
        this.BillableRepair = '1';
      }
    }
    


    RepairChangeEvent(event){
      let repairtype = this.inspectionForm.controls["RepairType"].value
    if(repairtype == 'CIN'){
      this.inspectionMetaData.RepairType = repairtype
    }
    if(repairtype == 'SVNR'){
      this.inspectionMetaData.RepairType = repairtype
    }
    }

    ReasonChageEvent(event){
      console.log("Test Reason:",this.inspectionMetaData.Reason)
    }
   }
