export class Notes {                                                                    
    NotesGuid:  String
    NotesType:  String
    Notes:     String
    CreatedBy:  String
    CreatedDate: String
    CaseID:     String
    notesviewlist: any[] = []
}