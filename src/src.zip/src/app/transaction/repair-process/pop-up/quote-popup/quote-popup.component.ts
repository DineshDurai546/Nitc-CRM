import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { DropDownValue, DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { CaseDetail } from '../../repair-process.metadata';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-quote-popup',
  templateUrl: './quote-popup.component.html',
  styleUrls: ['./quote-popup.component.sass']
})
export class QuotePopupComponent implements OnInit {
  typeSelected = 'ball-clip-rotate';
  toastr: any;
  validateAllFormFields: any;
  partList: any[]= [];
  resourceData: any[]=[]
  SelectedPartList: any[] = []; 
  SelectedPartCount:Number=0;
  NormalPartList:any[]=[];
  TierPartList:any[]=[];
  AcPlusPartList:any=[];
  PartSelectionMode:String="Normal"
  searchText: String = "";
  showonlyselected:boolean=false;
  errorMessage : string = "";
@Output() closePartSelectionEvent = new EventEmitter<any>();
  @Input() repa: CaseDetail;
@Output() QuotePartListData = new EventEmitter<any>()
@Output() GetQuoteList = new EventEmitter<any>()
  ngOnChanges(changes: SimpleChanges): void{
    
    if(changes['objcasedetail'])
    {
      
      // this.getPartSummaryData();      
    }
  }

  constructor(
    private formBuilder: FormBuilder,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private toast: ToastrService,
    private ngxSpinnerService:NgxSpinnerService,
  )
  { }

  ngOnInit() {
    this.ngxSpinnerService.show();
    setTimeout(() => {
    }, 1000)
    this.ngxSpinnerService.hide();
      // this.getPartSummaryData();
     this.GetResourceList()
      console.log("in Quote component");

  }


  // ======================Save Selected Data======================

   onSubmit() {
    this.SelectedPartList=[];
    for(let item of this.partList) {
      if(item.selected == true) {
        let retvalue = this.partList.filter(number=>number.toString() == item.number.toString());
        this.SelectedPartList.push(item);
        console.log("Store Selectd Data:",this.SelectedPartList);
        this.QuotePartListData.emit(this.SelectedPartList)
        this.closePartSelectionEvent.emit(this.SelectedPartList); 
      }
    }
}

 
UpdateSelectedCount(){
  this.SelectedPartCount= this.partList.filter(x => x.selected == true).length;
}
  onSearchChange(text) {
    console.log(text);
    for(let item of this.partList) {
      if(text.length > 1){
        item.inSearch = (item.description.toLowerCase().includes(text.toLowerCase()) || item.number.toLowerCase().includes(text.toLowerCase()));
      }else{
        item.inSearch = false;
      }
    }
  }


  sortArrayOfObjects = <T>(
    data: T[],
    keyToSort: keyof T,
    direction: 'ascending' | 'descending' | 'none',
  ) => {
    if (direction === 'none') {
      return data
    }
    const compare = (objectA: T, objectB: T) => {
      const valueA = objectA[keyToSort]
      const valueB = objectB[keyToSort]
      
      if (valueA === valueB) {
        
        return 0
      }
  
      if (valueA > valueB) {
        return direction === 'ascending' ? 1 : -1
      } else {
        return direction === 'ascending' ? -1 : 1
      }
    }
  
    return data.slice().sort(compare)
  }

  isToShowTr(item): Boolean {
    if(this.showonlyselected==false)
    {
        if(this.searchText.length <= 1){
          return true;
        }else if(item.selected == true){
          return true;
        } else if (item.inSearch) {
          return true;
        } else{
          return false;
        }
    }
    else
    {
      if(item.selected == true)
      {
        return true;
      } else{
        return false;
      }

    }
  }


  GetResourceList() {
    this.ngxSpinnerService.show()
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetResourcePriceList4Quote"
    });
    requestData.push({
      "Key": "ProductCategory",
      "Value": ""
    });
    console.log("Array Data:",requestData)
    console.log()
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          try {
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              let data = JSON.parse(response?.ExtraData);
              if(Array.isArray(data?.Resource.Resource))
             {
            for ( var item of data?.Resource.Resource)
          {
            this.partList.push({
              "number":item.MaterialCode,
                  "description":item.MaterialName,
                  "typeDescription":item.ItemType,
            })
            this.GetQuoteList.emit(this.partList)
            this.ngxSpinnerService.hide();
          }
        }
        else
        {
          var results=[];
          results.push(data?.Resource.Resource);
          this.partList.push({
            "number":results[0].MaterialCode,
            "description":results[0].MaterialName,
            "typeDescription":results[0].ItemType,
          })
        }
            }
          } catch (ext) {
            console.log(ext);
          }
        },
        error: err => {
          console.log(err);
        }
      }
    );
  }

  ClosePOpUp(){
    this.closePartSelectionEvent.emit('close PopUp')
  }
}
