import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { GsxService } from 'src/app/common/Services/gsxService/gsx.service';
import { CaseDetail } from '../../repair-process.metadata';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as glob from 'src/app/config/global'
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-repair-pop',
  templateUrl: './repair-pop.component.html',
  styleUrls: ['./repair-pop.component.css']
})
export class RepairPopComponent implements OnInit {
  typeSelected = 'ball-clip-rotate';
  toastr: any;
  validateAllFormFields: any;
  partList: any[] = [];
  resourceData: any[] = []
  SelectedPartList: any[] = [];
  SelectedPartCount: Number = 0;
  NormalPartList: any[] = [];
  TierPartList: any[] = [];
  AcPlusPartList: any = [];
  PartSelectionMode: String = "Normal"
  SearchField: String = "";
  showonlyselected: boolean = false;
  errorMessage: string = "";
  detail: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  ValidToDate: Date

  @Output() repairPartEvent = new EventEmitter<any>();
  @Output() closePartSelector = new EventEmitter<any>();
  @Input() selectedParts : any[] =[]
  @Input() repa: CaseDetail;

  ngOnChanges(changes: SimpleChanges): void {

    if (changes['objcasedetail']) {
      this.GetBOMList('');
    }
  }

  constructor(
    private formBuilder: FormBuilder,
    private dropdownDataService: DropdownDataService,
    private dynamicService: DynamicService,
    private toast: ToastrService,
    private ngxSpinnerService: NgxSpinnerService,
  ) { }

  ngOnInit() {
    this.GetBOMList('');
    console.log("in Quote component");

  }


  onSubmit() {
    let partsToSend  = this.partList.filter(x => x.selected == true)
    this.repairPartEvent.emit(partsToSend);
    this.closePartSelector.emit(false);  
  }


  UpdateSelectedCount() {
    this.SelectedPartCount = this.partList.filter(x => x.selected == true).length;
  }

  GetBOMList(eventDetail) {
    this.ngxSpinnerService.show();
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetBomObject"
    });
    requestData.push({
      "Key": "MaterialCode",
      "Value": this.repa.MaterialCode
    });
    requestData.push({
      "Key": "RepairType",
      "Value": this.repa.DIAG.RepairType
    });
    // requestData.push({
    //   "Key":"PageNo",
    //   "Value": eventDetail.pageIndex == null || eventDetail.pageIndex == undefined? "1": eventDetail.pageIndex + 1 
    // });
    // requestData.push({
    //   "Key":"PageSize",
    //   "Value": eventDetail.pageSize== null || eventDetail.pageSize == undefined? "10": eventDetail.pageSize
    // });

    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    console.log("Before SP:", requestData)
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
      {
        next: (Value) => {
          this.ngxSpinnerService.hide()
          try {
            let response = JSON.parse(Value.toString());
            if (response.ReturnCode == '0') {
              let data = JSON.parse(response?.ExtraData)
              console.log("Data is ", data)
              if (data.Totalrecords == "0"){
                this.toast.error("No Data Found")
                this.detail.next({ totalRecord: data?.Totalrecords, Data: '' })
                return
              }
              let ExtraData =[]
              this.ValidToDate = data?.BomObject?.ValidTo
              if( Array.isArray(data.BomObject?.BomDetail) ) {
                this.partList = data.BomObject?.BomDetail;
              }
              else{
                this.partList.push(data.BomObject?.BomDetail)
              }
              console.log("Bom Rows are:- ",this.partList)
              this.detail.next({ totalRecord: data?.Totalrecords, Data: ExtraData })
            }
          } catch (ext) {
          }
        },
        error: err => {
          this.ngxSpinnerService.hide()
          console.log(err)
        }

      }
    );
  }



  onSearchChange(text) {
    console.log(text);

    for (let item of this.partList) {
      if (text.length > 1) {
        item.inSearch = (item.MaterialDescription.toLowerCase().includes(text.toLowerCase()) || item.MaterialCode.toLowerCase().includes(text.toLowerCase()));
      } else {
        item.inSearch = false;
      }
    }
  }


  sortArrayOfObjects = <T>(
    data: T[],
    keyToSort: keyof T,
    direction: 'ascending' | 'descending' | 'none',
  ) => {
    if (direction === 'none') {
      return data
    }
    const compare = (objectA: T, objectB: T) => {
      const valueA = objectA[keyToSort]
      const valueB = objectB[keyToSort]

      if (valueA === valueB) {

        return 0
      }

      if (valueA > valueB) {
        return direction === 'ascending' ? 1 : -1
      } else {
        return direction === 'ascending' ? -1 : 1
      }
    }

    return data.slice().sort(compare)
  }



  isToShowTr(item): Boolean {
    if (this.showonlyselected == false) {
      if (this.SearchField.length <= 1) {
        return true;
      } else if (item.selected == true) {
        return true;
      } else if (item.inSearch) {
        return true;
      } else {
        return false;
      }
    }
    else {
      if (item.selected == true) {
        return true;
      } else {
        return false;
      }

    }
  }


  setdataInPartList() {
    for (let item of this.resourceData) {
      this.partList.push({
        "currency": 'INR',
        "description": item.ResourceName,
        "imageUrl": '',
        "number": item.ResourceCode,
        "type": item.ResourceType,
        "typeDescription": item.ResourceDescription,
        "stockPrice": item.ResourceType,
        "exchangePrice": 0,
      })
    }
  }

}
