import { Component, OnInit, ViewChild , ElementRef , Input, Output, EventEmitter} from '@angular/core';
import SignaturePad from "signature_pad";
import { v4 as uuidv4 } from 'uuid';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { CaseDetail } from '../../repair-process.metadata';
import { ToastrService } from 'ngx-toastr';
import xml2js from 'xml2js';
import { lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-signature',
  templateUrl: './signature.component.html',
  styleUrls: ['./signature.component.css']
})
export class SignatureComponent implements OnInit {

  @Input() signatureCheck:string;
  isAuthorization:Boolean;
  isCustomer:boolean;
  checkSignature:boolean;


  SignatureFileName:String ;
  jobCloseFileName:String ;
  authorSigFileName:String;
  sig: SignaturePad;
  SignatureType: any = ['JOBCLOSESIGNATURE', 'AUTHORISED PERSON'] 
  SignatureTypeValue
  @Output() signatureValidate = new EventEmitter<any>();
  @Output() authorisedSignature = new EventEmitter<any>();
  @Output() CancelBtn = new EventEmitter<any>();
  @Output() authorizationValidate = new EventEmitter<any>();

  @ViewChild("jobCloseSign", { static: true }) jobCloseSignature: ElementRef;
  jobCloseSignPad: SignaturePad;

  @ViewChild("authorizationSign", { static: true }) authorizationSignature: ElementRef;
  authorizationSignPad:SignaturePad;

  @ViewChild("canvas", { static: true }) canvas: ElementRef;
  @Input() repa: CaseDetail;
  errorMessage: any;


  constructor(
    private  dynamicService: DynamicService,
    private toaster: ToastrService
  ) {
   
   }

   dataURLtoBlob(dataurl) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
}

async SaveSignature(event)
  {


    if(event == 'customer')
    { 

      if(this.jobCloseSignPad.isEmpty() )
      {
        this.toaster.error('Please add Customer Signature');
        return
      }

    //set boolen value for save terinary operator
    this.checkSignature =true;

    const jobCloseSig = new FormData();
    var filename = uuidv4() + "_signature.png" ;
    
    jobCloseSig.append('file', this.dataURLtoBlob(this.jobCloseSignPad.toDataURL()),filename);
       
    const response = await lastValueFrom (this.dynamicService.uploadimagefile(jobCloseSig))
     
          let uploadedimage: any;
          uploadedimage = response;
          this.jobCloseFileName =  uploadedimage?.dbPath;

          this.signatureValidate.emit(this.jobCloseFileName);
          
          this.onSubmit();
    }

    if(event == 'authorization')
    { 
      if(this.authorizationSignPad.isEmpty() )
      {
        this.toaster.error('Please add Authorization Signature');
        return
      }
  
      this.authSaveSignature()
    }



  }



  async  authSaveSignature()
  {
    const authorSig = new FormData();
    var filename = uuidv4() + "_signature.png" ;
    
    authorSig.append('file', this.dataURLtoBlob(this.authorizationSignPad.toDataURL()),filename);
       
    const response = await lastValueFrom (this.dynamicService.uploadimagefile(authorSig))
     
          let uploadedimage: any;
          uploadedimage = response;
          this.authorSigFileName =  uploadedimage?.dbPath;
          this.authorisedSignature.emit(this.authorSigFileName)

          this.onSubmit();
        
   

     
  }



//RESET customer sign
jobCloseClearSignature()
{
  this.jobCloseSignPad.clear();
  this.jobCloseFileName = "";
   
}

//RESET authorization sign
authorizationClearSignature()
{
  this.authorizationSignPad.clear();
  this.authorSigFileName = "";
   
}



 
ngOnInit(): void {
 

  if(this.signatureCheck == 'Authorization')
  {

    this.isAuthorization=true;
    this.isCustomer=false;

    this.authorizationSignPad = new SignaturePad(this.authorizationSignature.nativeElement);
    this.authorSigFileName = '';
  }

  if(this.signatureCheck == 'Customer')
  {
    this.isAuthorization=false;
    this.isCustomer=true;

    this.jobCloseSignPad = new SignaturePad(this.jobCloseSignature.nativeElement);
    this.jobCloseFileName="";
  }

  // this.jobCloseSignPad = new SignaturePad(this.jobCloseSignature.nativeElement);
  // this.authorizationSignPad = new SignaturePad(this.authorizationSignature.nativeElement);

  // this.sig = new SignaturePad(this.canvas.nativeElement);
  // this.jobCloseFileName="";
  // this.authorSigFileName="";
}




async onSubmit()
{ 
    let requestData = [];
    let count =0 
    this.CancelBtn1();

    requestData.push({
      Key: "ApiType",
      Value: "SaveJobAttachment"
    });
    requestData.push({
      Key: "AttachmentGUID",
      Value: uuidv4()
    });
    requestData.push({
      Key: "CaseId",
      Value: this.repa.CaseId
    });
    requestData.push({
      Key: "CaseGuid",
      Value: this.repa.CaseGUID
    });
    requestData.push({
      Key: "AttachmentOriginType",
      Value:'JOBCLOSE'
    });
    requestData.push({
      Key: "AttachmentFile",
      Value:  this.checkSignature ? this.jobCloseFileName : this.authorSigFileName
    });
    requestData.push({
      Key: "AttachmentType",
      Value: this.checkSignature ? 'SIGNATURE' : 'AUTHSIGNATURE'
    });

    let strRequestData = JSON.stringify(requestData);
    console.log(strRequestData);
    let contentRequest = {
      "content": strRequestData
    };
 

    const response = await lastValueFrom(this.dynamicService.getDynamicDetaildata(contentRequest));

    let parsedResponse = JSON.parse(response.toString());
   // 
    if (parsedResponse.ReturnCode == '0') {
    
      count ++
      var getval = JSON.parse(parsedResponse.ExtraData);
       
    } else {

      this.errorMessage = parsedResponse.ReturnMessage;
      const parser = new xml2js.Parser({ strict: false, trim: true });
      parser.parseString(parsedResponse.ErrorMessage, (err, result) => {
        parsedResponse['errorMessageJson'] = result;
      });
      return
    }
    
  
}

async onSubmitTest() {

if(this.jobCloseSignPad.isEmpty() )
{
  this.toaster.error('Please add Customer Signature');
  return 
}
if(this.authorizationSignPad.isEmpty() )
{
  this.toaster.error('Please add Authorization Signature');
  return
}

if(this.authorizationSignPad.isEmpty() == false &&  this.jobCloseSignPad.isEmpty() == false)
{
  // Define an array of arrays with the different values for each iteration

  const attachmentData = [
    ["JOBCLOSE", this.jobCloseFileName, "SIGNATURE"],
    ["JOBCLOSE", this.authorSigFileName, "AUTHSIGNATURE"],
  ];
  let count =0 
  // Iterate through the attachmentData array in a for loop
  for (let i = 0; i < attachmentData.length; i++) {
    const array = attachmentData[i];
    let requestData = [];

    requestData.push({
      Key: "ApiType",
      Value: "SaveJobAttachment"
    });
    requestData.push({
      Key: "AttachmentGUID",
      Value: uuidv4()
    });
    requestData.push({
      Key: "CaseId",
      Value: this.repa.CaseId
    });
    requestData.push({
      Key: "CaseGuid",
      Value: this.repa.CaseGUID
    });
    requestData.push({
      Key: "AttachmentOriginType",
      Value: attachmentData[i][0]
    });
    requestData.push({
      Key: "AttachmentFile",
      Value: attachmentData[i][1]
    });
    requestData.push({
      Key: "AttachmentType",
      Value: attachmentData[i][2]
    });

    let strRequestData = JSON.stringify(requestData);
    console.log(strRequestData);
    let contentRequest = {
      "content": strRequestData
    };

    console.log("Before Submitting", requestData , i);

    const response = await lastValueFrom(this.dynamicService.getDynamicDetaildata(contentRequest));

    let parsedResponse = JSON.parse(response.toString());

    if (parsedResponse.ReturnCode == '0') {
     
      count ++
      var getval = JSON.parse(parsedResponse.ExtraData);

    } else {

      this.errorMessage = parsedResponse.ReturnMessage;
      const parser = new xml2js.Parser({ strict: false, trim: true });
      parser.parseString(parsedResponse.ErrorMessage, (err, result) => {
        parsedResponse['errorMessageJson'] = result;
      });
      return
    }
    
  }
  if (count ==attachmentData.length ){
    console.log("Success");
    this.toaster.success('Submitted Successfully');
    this.signatureValidate.emit(this.jobCloseFileName);
    this.authorisedSignature.emit(this.authorSigFileName);
    this.CancelBtn1();
    
    
  }
  else{
    this.toaster.error('Try Again');
  }

}

}



cancle: boolean;
CancelBtn1(){
  this.cancle = true; 
  this.CancelBtn.emit(this.cancle)  
}

}

 

