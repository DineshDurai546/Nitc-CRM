import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-quote-view',
  templateUrl: './quote-view.component.html',
  styleUrls: ['./quote-view.component.sass']
})
export class QuoteViewComponent implements OnInit {

  constructor() { }
  @Input() partlist

  ngOnInit(): void {
   console.log('Hello')

    
  }
  quoteviewList:any=[]
  GetQuotePart(){
    for(let item of this.partlist){
      console.log("Total PartList",item)
      this.quoteviewList.push(item)
      console.log("quoteviewList",this.quoteviewList)
    }  
  }


 


  // TestData(){
  //   console.log("Emite Qoute Data:",this.partlist)
  // }
}
