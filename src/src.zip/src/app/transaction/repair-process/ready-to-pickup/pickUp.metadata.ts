export class PickUp{
    PickUpCode: String;
    PickUpDate: Date;
    PickUpRemark: String;

  }