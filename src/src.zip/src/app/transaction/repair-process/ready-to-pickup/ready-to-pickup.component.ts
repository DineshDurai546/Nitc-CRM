import { Component, OnInit , Output, Input, EventEmitter,SimpleChanges} from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import * as glob from "../../../config/global";
import { v4 as uuidv4 } from 'uuid';
import { CaseDetail } from '../repair-process.metadata';
import xml2js from 'xml2js';
import { PickUp } from './pickUp.metadata';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';



@Component({
  selector: 'app-ready-to-pickup',
  templateUrl: './ready-to-pickup.component.html',
  styleUrls: ['./ready-to-pickup.component.css'],
})
export class ReadyToPickupComponent implements OnInit {
  selectcurremtdate:any=[]
  @Input() repa: CaseDetail;
  isreadytopickup:boolean=false;
  selectedStatus:any=['Release']
  pickup: PickUp
  @Output() RPFUpdated = new EventEmitter<any>();
  constructor(
    private formBuilder:FormBuilder,
    private toastrService:ToastrService,
    private dynamicService:DynamicService,
    private ngxSpinner:NgxSpinnerService,
    private DatePipe:DatePipe,
  ) {
    this.currentDate = new Date();
   }
  currentDate: Date;

  ngOnInit(): void {
    const formatedate = this.DatePipe.transform(this.currentDate, 'yyyy-MM-dd');
    this.selectcurremtdate.push(formatedate);
    this.pickup = new PickUp();
  }

  addreadytopickupForm = this.formBuilder.group({
    readytopickupstatus:[],
    readytopickupdate:[],
    readytopickupremark:[],
  })
  

  addRPFList() {
    if (this.isreadytopickup == true) {
      this.isreadytopickup = false;
    } else {
      this.isreadytopickup = true;
    }
  }

  addReadyToPickUp() {
    if (this.isreadytopickup == true) {
      this.isreadytopickup = false;
    } else {
      this.isreadytopickup = true;
    }
  }


  SaveReadyTopickup(){
    let newRFPGuid = uuidv4();
    if(this.addreadytopickupForm.controls["readytopickupstatus"].value ==  null ||
      this.addreadytopickupForm.controls["readytopickupstatus"].value ==  undefined ||
      this.addreadytopickupForm.controls["readytopickupstatus"].value ==  ""){
      this.toastrService.error("Plase Select Ready To Pickup Status");
      return false;
      }
      if(this.addreadytopickupForm.controls["readytopickupdate"].value ==  null ||
      this.addreadytopickupForm.controls["readytopickupdate"].value ==  undefined ||
      this.addreadytopickupForm.controls["readytopickupdate"].value ==  ""){
      this.toastrService.error("Plase Select Ready To Pickup Date");
      return false;
      }
      if(this.addreadytopickupForm.controls["readytopickupremark"].value ==  null ||
      this.addreadytopickupForm.controls["readytopickupremark"].value ==  undefined ||
      this.addreadytopickupForm.controls["readytopickupremark"].value ==  ""){
      this.toastrService.error("Plase Enter  Remark");
      return false;
      }
      else{
        this.ngxSpinner.show();
        let requestData = [];
        requestData.push({
          "Key": "ApiType",
          "Value": "SaveRFP"
        });
        requestData.push({
          "Key": "CompanyCode",
          "Value": glob.getCompanyCode()
        });
        requestData.push({
          "Key": "RFPGUID",
          "Value":newRFPGuid
        });
        requestData.push({
          "Key": "CaseGUID",
          "Value": this.repa.CaseGUID
        });
        requestData.push({  
          "Key": "RFPCode",
          "Value": "NEW"
        });
        requestData.push({
          "Key": "RFPStatus",
          "Value": this.addreadytopickupForm.controls["readytopickupstatus"].value
        });
        requestData.push({
          "Key": "RFPDate",
          "Value": this.addreadytopickupForm.controls["readytopickupdate"].value
        });
        requestData.push({
          "Key": "Remark",
          "Value": this.addreadytopickupForm.controls["readytopickupremark"].value
        });
        let strRequestData = JSON.stringify(requestData);
        console.log(strRequestData);
        let contentRequest = {
          "content": strRequestData
        };
        console.log(contentRequest);
        this.dynamicService.getDynamicDetaildata(contentRequest).subscribe(
          {
          next:(value)=>{

            let response = JSON.parse(value.toString());
            if(response.ReturnCode == '0'){
              console.log("*****************Ready To PickUp:************************",response)
              var getval = JSON.parse(response.ExtraData);
              console.log("Ready To getval:",getval)
              this.RPFUpdated.emit(getval);
              this.addReadyToPickUp();
              this.toastrService.success("Added SccessFully");
              this.ngxSpinner.hide();
            }
          
      }
      })
  }
}

ResetData(){
  this.addreadytopickupForm.reset();
}

reloadCurrentPage() {
  
  window.location.reload();
 }

rpfviewlist: any[] = [];
rpf: any[] = [];
productDescription: any
ngOnChanges(changes: SimpleChanges): void{
  if(changes['repa'])
  {
      if(this.repa!= null && this.repa != undefined  ){
        this.rpfviewlist = [];
        this.rpf=[];
        this.rpf.push(this.repa?.RFP)
        this.productDescription = this.repa?.productDescription
        if(Array.isArray(this.rpf))
        {
          for ( var item of this.rpf)
          {
              this.rpfviewlist.push({
                "RFPGUID": item?.RFPGUID,
                "RFPCode":   item?.RFPCode,
                "RFPStatus": item?.RFPStatus,
                "Remark": item?.Remark,
                "CreatedBy": item?.CreatedBy,
                "CreatedDate":item?.CreatedDate,
              })
          }
        }
      }
    }
  }
}    
