import { Component, EventEmitter, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { CommonService } from 'src/app/core/service/common.service';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { DynamicService } from 'src/app/common/Services/dynamicService/dynamic.service';
import { GsxService } from 'src/app/common/Services/gsxService/gsx.service';
import { DropdownDataService } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import { DropDownValue } from 'src/app/common/Services/dropdownService/dropdown-data.service';
import * as glob from "../../config/global";
import { Observable } from 'rxjs/internal/Observable';
import SwiperCore, { Navigation, Pagination, Scrollbar, A11y, SwiperOptions, Autoplay, Thumbs, Virtual, Zoom, Controller, Swiper } from 'swiper';
import { ToastrService } from 'ngx-toastr';
import {trigger, state, style, animate, transition} from '@angular/animations';
import { SwiperComponent } from "swiper/angular";
import { NotesComponent } from './notes/notes.component';
import { HandOverComponent } from './hand-over/hand-over.component';
import { QuoteViewComponent } from './quote-view/quote-view.component';
import { InspectionComponent } from './inspection/inspection.component';
import { CaseDetail } from './repair-process.metadata';
import { RepairViewComponent } from './repair-view/repair-view.component';
import { ReadyToPickupComponent } from './ready-to-pickup/ready-to-pickup.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { ReportService } from 'src/app/common/Services/gsxService/report.service';

SwiperCore.use([
  Navigation,
  Pagination,
  Scrollbar,
  A11y,
  Virtual,
  Zoom,
  Autoplay,
  Thumbs,
Controller
]);

@Component({
   selector: 'app-repair-process',
   templateUrl: './repair-process.component.html',
   styleUrls: ['./repair-process.component.css'],
   animations: [
      trigger('rotatedState', [
      state('default', style({ transform: 'rotate(0)' })),
      state('rotated', style({ transform: 'rotate(-180deg)' })),
      transition('rotated => default', animate('500ms ease-out')),
      transition('default => rotated', animate('500ms ease-in'))
  ])
]  
})

export class RepairProcessComponent implements OnInit {

  //Variable Declare
  [x: string]: any;
  indexNumber = 1;
  
  isQoutePop: boolean = false;
  stepIndex: number = 1;

// ========================Declare Boolean Value=============================

  isNotesListOpen: boolean = false;

  isRepairShow:boolean=false;
  isQuoteShow: boolean = false;
  isNoteShow:boolean=false;
  isInspectionShow:boolean=false;
  isInvoiceShow:boolean=false;
  isPaymentShow:boolean=false;
  isReadyToPickupShow:boolean=false;
  isHandOverShow:boolean=false;
  isVerification:boolean=true;
  customerdetails: boolean;
  

  isOpenPanelDetails:boolean=false;
  isDetails:boolean=true;
  isImageUpload:boolean=false;
  isHandoverButton: boolean = true;
  // isReadyToPickup:boolean = true;
  isRepairPop: boolean = false;

  isAssignTechPop: boolean = false;
  // Inspection Component Issues:- 
  objcomponentissuelist: any[];
  selectedRepairParts: any[] ;



  objCaseDetail: CaseDetail;
  objCaseDetailObServable: Observable<CaseDetail>;
  ngOnChanges(changes: SimpleChanges): void{
    if(changes['objCaseDetail']){
      this.ButtonCheck();

    }
  }
  ButtonCheck(){
    if(this.objCaseDetail?.repairPartList?.length <= 0 || this.objCaseDetail.RepairFlag == 1){
      this.repairButton = false;
    }
    
  }

  checkLaborCover(){
    if(this.objCaseDetail?.LaborCovered == undefined ||  this.objCaseDetail?.LaborCovered == 0){
      this.laborCover = 'Not Eligible'
    }else{
      this.laborCover = 'Eligible'
    }
  }

  checkPartCover(){
    if(this.objCaseDetail?.PartCovered == undefined || this.objCaseDetail?.PartCovered == 0){
      this.partCover = 'Not Eligible'
    }else{
      this.partCover = 'Eligible'
    }
  }

  //ViewChild Declare
  @ViewChild("swiperRef", { static: false }) sliderRef?: SwiperComponent;
  @ViewChild(NotesComponent) notesComponent: NotesComponent;
  @ViewChild(HandOverComponent) handover: HandOverComponent;
  @ViewChild(InspectionComponent ) Inspection: InspectionComponent;
  @ViewChild(ReadyToPickupComponent) readytopickupcompo :ReadyToPickupComponent
  @ViewChild(QuoteViewComponent) callingFunction: QuoteViewComponent
  @ViewChild(RepairViewComponent) repairView: RepairViewComponent;


  //Array
  selectedNotesTemplate:any[] = []

  names = [
    '<i class="fa-duotone fa-screwdriver-wrench"></i> tab 1',
    '<i class="fa-duotone fa-clipboard"></i> tab 2',
    '<i class="fa-solid fa-file-chart-column"></i> tab 3',
    '<i class="fa-solid fa-file-contract"></i> tab 4',
    '<i class="fa-solid fa-file-invoice"></i> tab 5',
    '<i class="fa-duotone fa-chart-area"></i> tab 6',
    '<i class="fa-duotone fa-chart-mixed"></i> tab 7',
    '<i class="fa-duotone fa-chart-mixed"></i> tab 8',
    '<i class="fa-duotone fa-chart-mixed"></i> tab 9',
  ];

  config: SwiperOptions = {
    modules: [Navigation, Pagination, Scrollbar],
    direction: 'horizontal',
    slidesPerView: 'auto',
    spaceBetween: 20,
    freeMode: true,
    loop: false,
    allowTouchMove:false,
    pagination: { clickable: true },
    grabCursor: false,
    keyboard: {
      enabled: true,
    },
  };


  scrollBarOption = {
    el: '.swiper-scrollbar', draggable: false, enabled: false,
  }

  constructor(
    private activatedRoute: ActivatedRoute,
    private dynamicService:DynamicService,
    private toastrService:ToastrService,
    private spinner:NgxSpinnerService,
    private reportService:ReportService) {}

  ngOnInit(): void {
    this.caseGUID = this.activatedRoute.snapshot.queryParams.guid;
    if (this.caseGUID == null || this.caseGUID == undefined) {
    }
    this.getRepair();
    this.checkPartCover()
    this.checkLaborCover()
  }


  authorisedSignature($event){
    this.AuthPersonSignature = $event
    }
  signature: any
    signatureValidate($event){
     this.signature = $event
    }
  
  signatureCheck:any;
  addCustomerSignature()
  { 
        //value pass to repair process 
       this.signatureCheck='Customer'; 
  }
  
  addAuthorisedSignature()
  {  
      //value pass to repair process  
      this.signatureCheck='Authorization'
  }
  
  isOtpCall(event)
  { 
    this.isOtpVerification=event;
  }


  CustomerDetails(){
    // this.toastrService.success('Workig functio')
    if (this.isOpenPanelDetails == true) {
      this.isOpenPanelDetails = false;
      this.isDetails = true;
    } else {
      this.isOpenPanelDetails = true;
      this.isDetails = false;
    }
  }
  //Image Upload popUp close
  Cancel($event){
    this.isImageUpload = $event
    this.isRepairPop = $event
    this.isOtpVerification=$event
  }
    // NotesUpdated($event){
    //   this.objCaseDetail.NOTESLIST={...$event};
    //   this.objCaseDetail = Object.assign({}, this.objCaseDetail);
    // }


 //Hand Over Function
//  addHandOverDevice(){
//     //this.isOtpVerification = false
//     this.handover.TestHand()
//     this.isHandoverButton = false;
//   } 

  // addHandOverDevice1(){
  //   this.handover.TestHand();

  // }

  
HanOverUpdated($event){
  this.isOtpVerification = false
  this.objCaseDetail.HANDOVER={...$event};
  this.objCaseDetail = Object.assign({}, this.objCaseDetail);
}

otpUpdated($event){
   
  this.objCaseDetail.OTPVALUE = {...$event};
  this.objCaseDetail = Object.assign({}, this.objCaseDetail);
}
//cancel btn
closeOtpPopUp(event)
{
  this.isOtpVerification = event 
  //not verifiy otp and click cancel btn show create btn
  if(event == false)
  {
    //this.isHandoverButton = true;
  }
  //once verifiy otp and click cancel btn hide create btn
  if(this.ishandOverCheck==true)
  {
    this.isHandoverButton = false;
  }

}

  // -----------------------

  addSignature(){
    if (this.isSignature == true) {
      this.isSignature = false;
    } else {
      this.isSignature = true;
    }
  }

  AddSignature($event){
    this.isSignature = $event
  }

  // addreadytopickuptab(){
  //   // this.readytopickup.AddReadyToPickUp();
  //   // this.isReadyToPickup = false;
  // }

  quotePartList: any[];
  quoteFormClose(selectedpart) {
    this.quotePartList = selectedpart;
    this.isQoutePop = false;
  }



  assignTechFlagSet($event){
    this.objCaseDetail.AssignTechFlag = 1;
    this.objCaseDetail.AssignTechGUID = $event.AssignTechGUID;
    this.objCaseDetail.ASGTECH=$event;
    this.isAssignTechPop=false;
    this.FlagCheck()
  }



  FlagCheck(){
  if(this.objCaseDetail.AssignTechFlag == 0){
    this.toastrService.warning( "Assign Technician First")
    this.CustomerDetails();}
    if(this.objCaseDetail?.NOTESLIST == null || this.objCaseDetail?.NOTESLIST == undefined){
      this.isNotesButton=true;

    }
    if(this.objCaseDetail?.JobStatusDesc=="Diagnosis"){
      this.readytopickupbtn=false;
      this.handoverbtn=false;
      // this.isDisablenotbtn=false;
    }
    if(this.objCaseDetail?.JobStatusDesc == "Rejected"){
      this.readytopickupbtn = false;
      this.handoverbtn = false;
    }
    if(this.objCaseDetail?.JobStatusDesc == "Ready For Pickup"){
      // this.readytopickupbtn = false;
      this.handoverbtn = false;
    }
    if(this.objCaseDetail?.JobStatusDesc =="Approved"){
      this.handoverbtn=false;

    }
 if(this.objCaseDetail.AssignTechFlag == 1){
    this.isInspectionShow = false;
    this.isAssignTechPop=false;
    this.isQuoteShow=true;
    this.isRepairShow=true;
    this.isQuoteShow=true;
    this.isNoteShow=true;
    this.isInspectionShow = true;
    this.isInvoiceShow=true;
    this.isPaymentShow=true;
    this.isReadyToPickupShow=true;
    this.isHandOverShow=true;
    this.isReadyToPickupShow=true;
  }
  else if(this.objCaseDetail.AssignTechFlag == 1){
    this.isVerification = false;
    this.isRepairShow=true;
    this.isReadyToPickupShow=true;
    this.isQuoteShow=true;
    this.isNoteShow=true;
    this.isInspectionShow = true;
    this.isInvoiceShow=true;
    this.isPaymentShow=true;
    this.isReadyToPickupShow=true;
    this.isHandOverShow=true;
    this.isNotesButton=false;
  }
  else{
    console.log("Else  condition")
    this.isInspectionShow = false;
    this.isRepairShow=false;
    this.isQuoteShow=false;
    this.isRepairShow=false;
    this.isNoteShow=false;
    this.isInvoiceShow=false;
    this.isPaymentShow=false;
    this.isReadyToPickupShow=false;
    this.isHandOverShow=false;
    this.isReadyToPickupShow=false;
  }
  }

  //============================ Get RepairDetails================================================
  getRepair() {
    let requestData = [];
    requestData.push({
      "Key": "APIType",
      "Value": "GetJobObject"
    });
    requestData.push({
      "Key": "CaseGUID",
      "Value": this.caseGUID,
    });
    requestData.push({
      "Key": "CompanyCode", 
      "Value": glob.getCompanyCode()
    });
    let strRequestData = JSON.stringify(requestData);
    let contentRequest =
    {
      "content": strRequestData
    };
    this.dynamicService.getDynamicDetaildata(contentRequest).subscribe({
        next: (Value) => {
          let response = JSON.parse(Value.toString());
          if (response.ReturnCode == '0') {
            response['ExtraDataJSON'] = JSON.parse(response.ExtraData);
            this.objCaseDetailObServable = response['ExtraDataJSON'];
            this.objCaseDetail = response['ExtraDataJSON'];
            console.log("****************************************",this.objCaseDetail)
            this.objCaseDetail = Object.assign({}, this.objCaseDetail);
            this.loadDiag = true;
            this.FlagCheck();
            // if(this.objCaseDetail?.DIAG ?.RepairType != 'CIN'  && this.objCaseDetail?.DiagFlag == '1' && this.objCaseDetail?.RepairFlag =='0'){
            //   this.isRepairShow=false;
            // }
            // if(this.objCaseDetail?.InvoiceFlag == "1"){
            //   this.hideBillToButton = true
            // }
            // else if(this.objCaseDetail?.PAYMENTLIST?.Payment != null || this.objCaseDetail?.PAYMENTLIST?.Payment != undefined){
            //   this.hideBillToButton = true
            // }
          }
        },
        error: err => {
          console.log(err);
        }
      }
    );
  }  
     AllSelectedQoute:any[]=[];
     isQuoteview:boolean=true;
     selectedQuoteList(event){
      this.AllSelectedQoute = event;
      this.isQuoteview=false;
      this.callingFunction.GetQuotePart();
    }


    editDiag() {
      console.log(" Repair Status ", this.objCaseDetail)
      this.objCaseDetail.RepairFlag == 0 ?  this.Inspection.editDiagForm() : ''
    }

    InspectUpdated($event){
      var objDiag = $event;
      let DiagnosisGUID = objDiag.DiagnosisGUID;
      this.objCaseDetail.DiagFlag=1
      this.objCaseDetail.DiagGUID=DiagnosisGUID
      this.objCaseDetail.DIAG={...$event};
      this.objCaseDetail = Object.assign({}, this.objCaseDetail);
      this.FlagCheck()
      this.getRepair();
    
    }

  // ==================== Inspection ==================

  openComponentIssuePopup(event){
    this.isComponentIssuesPop = event;
  }
  ComponentPopUpClose(event){
      this.isComponentIssuesPop = event;
  }
  GetcomponentIssueObj($event){
    this.objcomponentissuelist = $event;
    this.isComponentIssuesPop = false;
  }

  // ==================== Repair Parts ==================

  OpenRepairParts(){
    console.log("Diagnosis ", this.objCaseDetail)
    if ( this.objCaseDetail.DiagFlag = 0 ){
      this.toastrService.error("Please Fill the Inspection Details, first!")
    }
    else{
      this.isRepairPop = true
    }
  }

  addPartsToRepair(selectedpartsList){
    this.selectedRepairParts= selectedpartsList;
    // this.objCaseDetail = Object.assign({}, this.objCaseDetail);
  }

  AddRepairParts(){
    console.log("Reapir ", this.objCaseDetail?.DIAG)
    if( this.objCaseDetail?.DIAG?.RepairType == 'CIN'){
      this.isRepairPop= true
    }
    else{
      this.toastrService.error("Can't Add Parts for Repair Type")
    }
  }
  RepairUpdated($event){
    this.objCaseDetail.REPAIR={...$event};
    this.objCaseDetail = Object.assign({}, this.objCaseDetail);
    this.getRepair();
  }


  // ====================Notes List==================
  openNotesTemplate($event){
    this.isNotesListOpen = $event
  }

  NotesListClose($event){
  this.isNotesListOpen = $event
  }

  selectedNotesList($event){
  this.selectedNotesTemplate = $event
  }

  NotesOpen(){
    if (this.isNotesListOpen == true) {
      this.isNotesListOpen = false;
    } else {
      this.isNotesListOpen = true;
    }
  }
  NotesUpdated($event){
    this.objCaseDetail.NOTESLIST={...$event};
    this.objCaseDetail = Object.assign({}, this.objCaseDetail);
  }



  // Ready To PickUp Component
  isRFPButton: boolean = true;
  // isNotesButton:boolean=false;
  isReadyToPickup(){
    this.addReadyToPick();
    return true
  }

  addReadyToPick(){
    this.readytopickupcompo.addReadyToPickUp()
    this.isRFPButton = false;
    }
    validRFP(){
      this.addReadyToPick();
      return true
    }

    // Notes
    isDisablenotbtn:boolean=true;
    readytopickupbtn:boolean=true;
    handoverbtn:boolean=true;
    isedithidebtn:boolean=true;
    isAddNotes() {
      this.addNotes();
      this.isNotesButton=false;
    }
    addNotes(){
      this.notesComponent.addNotesList();
      // this.isNotesButton=false;
    }

    validNotes(){
      this.addNotes();
      return true
    }


    // ReadyTo pickup
    RPFUpdated($event){
      this.objCaseDetail.RFP={...$event};
      this.objCaseDetail = Object.assign({}, this.objCaseDetail);
    }


    // HandOver
    OpenHandOver(){
      this.handover.addHandOver();
  
      }
      addHandOverDevice(){
        this.OpenHandOver();
        this.isHandoverButton=false
         
      }

// Report Function
downloadServiceReport(reportType:String){
   this.spinner.show()
  let PdfData = [];
  PdfData.push({
    "Key": "ApiType",
    "Value": "GetJobObject4Print",
  });
  PdfData.push({
    "Key": "JobHeaderGUID",
    "Value": this.objCaseDetail.JobHeaderGuid,
  });


  let pdfRequestData = JSON.stringify(PdfData);
  let contentRequest =
  {
    "content": pdfRequestData
  };
  let storepdf = contentRequest; 
  this.reportService.downloadServiceReport(reportType,contentRequest).subscribe(
    {
      next: (value) => {
        let response = JSON.parse(value.toString());
        const byteArray = new Uint8Array(atob(response.FileContents).split('').map(char => char.charCodeAt(0)));
        var blob = new Blob([byteArray], { type: 'application/pdf' });
        var url = URL.createObjectURL(blob);
        window.open(url);
         this.spinner.hide()


      },
      error: err => {
        console.log(err);
        //this.spinner.hide()

      }
    });
}


}


