import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SwiperModule } from "swiper/angular";
import {MatSelectModule} from '@angular/material/select';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatMenuModule} from '@angular/material/menu';
import {MatTooltipModule} from '@angular/material/tooltip';
import { MaterialModule } from '../shared/material.module';
import {MatCardModule} from '@angular/material/card';
import { RouterModule, Route, Routes } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { NitcControlModule } from '../nitc-control/nitc-control.module';
import { MatRadioModule } from '@angular/material/radio';
import { MatBadgeModule } from '@angular/material/badge';
import { SptonSharedModule } from '../shared/spton-shared.module';
import { MatChipsModule } from '@angular/material/chips';
import { MatStepperModule } from '@angular/material/stepper';
//Component Import//
// import { HandOverComponent } from './repair-process/hand-over/hand-over.component';
import { ImageUploadComponent } from './repair-process/image-upload/image-upload.component';
import { NotesComponent } from './repair-process/notes/notes.component';
import { PaymentComponent } from './repair-process/payment/payment.component';
import { InspectionComponent } from './repair-process/inspection/inspection.component';
import { RepairProcessComponent } from './repair-process/repair-process.component';
import { SignatureComponent } from './repair-process/pop-up/signature/signature.component';
// import { ReadyT0PickupComponent } from './repair-process/ready-t0-pickup/ready-t0-pickup.component';
import { ReadyToPickupComponent } from './repair-process/ready-to-pickup/ready-to-pickup.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatNativeDateModule} from '@angular/material/core';
import { BrowserModule } from '@angular/platform-browser';
import { QuotePopupComponent } from './repair-process/pop-up/quote-popup/quote-popup.component';
import { QuoteViewComponent } from './repair-process/quote-view/quote-view.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ComponentIssueComponent } from './repair-process/component-issue/component-issue.component';
import { VerificationComponent } from './repair-process/verification/verification.component';
import { AssignToTechnicianComponent } from './repair-process/assign-to-technician/assign-to-technician.component';
import { NotesListComponent } from './repair-process/pop-up/notes-list/notes-list.component';
import { HttpClientModule } from '@angular/common/http';
import { ScrollingModule } from '@angular/cdk/scrolling';
import {MatExpansionModule} from '@angular/material/expansion';
import { RepairViewComponent } from './repair-process/repair-view/repair-view.component';
import { RepairPopComponent } from './repair-process/pop-up/repair-pop/repair-pop.component';
import { DebounceClickDirective } from '../config/debounce-click.directive';
import { OtpVerificationComponent } from './repair-process/pop-up/otp-verification/otp-verification.component'; 
//  import { CustomComponentModule } from '../custom-components/custom-components.module';
import { HandOverComponent } from './repair-process/hand-over/hand-over.component';
const routes: Routes = [];
@NgModule({
  declarations: [
    RepairProcessComponent,   
    PaymentComponent,
    InspectionComponent,
    NotesComponent,      
    ImageUploadComponent,
    HandOverComponent,
    SignatureComponent,
    QuotePopupComponent,
    ReadyToPickupComponent,
    QuoteViewComponent,
    ComponentIssueComponent,
    VerificationComponent,
    AssignToTechnicianComponent,
    NotesListComponent,
    RepairViewComponent,
    RepairPopComponent,
    OtpVerificationComponent,

  ],
  imports: [

    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    FormsModule,
    MaterialModule,
    Ng2SmartTableModule,
    NitcControlModule,
    NgSelectModule,
    MatRadioModule,
    MatBadgeModule,
    SptonSharedModule,
    MatChipsModule,
    SwiperModule,
    MatStepperModule,
    BrowserModule,
    HttpClientModule,
    ScrollingModule,
    MatTooltipModule,
    MatExpansionModule,
    NgxSpinnerModule,
    // CustomComponentModule
  ],
 exports:[ComponentIssueComponent]
})
export class TransactionModule { }
