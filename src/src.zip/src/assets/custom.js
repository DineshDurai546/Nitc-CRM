function getUrl() {
    var url = {
        SERVER_LINK: "http://crm.nitc.co.in/api/",
        API_LINK: "api/"
    }
    return url;
}
